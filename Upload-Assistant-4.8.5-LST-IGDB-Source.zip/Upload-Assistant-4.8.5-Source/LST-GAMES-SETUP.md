> Current 4.8.5 naming: use `Base Game (year)` or, for two IGDB IDs,
> `Base Game (year) + Add-on Title (DLC)` / `(Expansion)`. The uploader asks which
> type to use. LST, folder, ZIP and torrent share this name (disk names sanitize
> invalid punctuation). See [CONTAINER-SETUP.md](CONTAINER-SETUP.md) for the current
> container and bundle setup. Older bare-year naming examples below are superseded.

# LST.gg game uploads with IGDB

This is an unofficial modification of Upload Assistant by Audionut & wastaken7,
not an official release. Original attribution and license are retained.

This adaptation enables GAME uploads to LST using its bundled catalog: category 4,
Windows type 13, Mac type 12, Linux type 14, and Other type 15 for other platforms.
It reuses the existing game preparation, description, torrent creation,
duplicate review and IGDB client. LST game uploads are skipped if no IGDB ID was
resolved. Other trackers and media categories retain their existing behavior.

## Setup

Use Python 3.14 or newer and install the project's dependencies using the existing
README installation instructions. This ZIP contains source code, not a Windows executable.

In your active config.py, set these existing DEFAULT keys:

```python
"twitch_client_id": "YOUR_TWITCH_CLIENT_ID",
"twitch_client_secret": "YOUR_TWITCH_CLIENT_SECRET",
```

Alternatively set TWITCH_CLIENT_ID and TWITCH_CLIENT_SECRET in your environment.
Register a confidential application in the Twitch Developer Console to obtain them:
https://dev.twitch.tv/console/apps
IGDB authentication documentation: https://api-docs.igdb.com/#getting-started
The assistant obtains and caches the access token automatically. Existing metadata
caching also applies; a valid cached result may avoid a new network request.

Configure your LST API key in the existing TRACKERS -> LST section of config.py.
Do not send credentials to anyone or place them in this documentation.

## Use

Run from the extracted Upload-Assistant-development directory:

```powershell
python upload.py "D:\Games\Example.Game" --category game --trackers LST --platform pc --year 2024
```

The existing metadata flow queries IGDB by title (or by a Steam ID found in an NFO)
and lets you select a match when multiple results are found in interactive mode.
To select a specific IGDB entry, append `--igdb 12345`, replacing 12345 with the
actual numeric IGDB game ID. That option fetches the record from IGDB; it is not
an unchecked ID override. You can also supply `--game-title "Exact Game Title"`.

## Titles, year and platform

LST titles are exactly `<IGDB name> <year>`, preserving the name's spelling,
punctuation and capitalization. No group, version, platform or TRUMP suffix is
added. `--year 2024` overrides the year; otherwise the IGDB release year is used
(with the prepared year as a fallback). A missing year must be supplied.
`--game-title` helps search but cannot override the final IGDB upload title.

Use `--platform pc`, `--platform mac` or `--platform linux` to select the build
being uploaded. Platform affects the upload type, not the title. Other platforms
map to LST's Other type. Follow LST's rules for accepted content.

## Optional folder renaming

Append `--rename-game-folder` to rename the selected input directory before
creating the torrent. Files inside retain their original names. The target is
`<IGDB name> (<year>)` beside the original folder. Windows-invalid punctuation
such as `:` is removed and whitespace is normalized in filesystem names.
Existing destinations are never overwritten. Single-file input and directory
links are rejected. Renaming forces fresh torrent hashing and cannot be combined
with `--nohash`. Without this flag, no source folder is renamed.

```powershell
python upload.py "D:\Games\Example.Game" --category game --trackers LST --platform pc --year 2024 --igdb 12345 --rename-game-folder
```

Replace 12345 with the real game ID. Use an upload copy: renaming data already
used by another torrent breaks that torrent's old path. This changes the folder
before upload review, so the new name remains even if you cancel or upload fails.
Changing title/year later requires rerunning against the current folder path.

For a rehearsal, append `--debug`; review the proposed fields and duplicate results
before a real upload. `--debug` previews folder renaming without changing it. Debug mode may still query metadata and tracker APIs.

## ZIP-only game uploads (deletes original files)

`--zip-game` creates and verifies a ZIP containing every regular file and subfolder
in the selected game directory, then deletes the original files and empty folders.
It also renames the game directory to the IGDB name plus year. The end result is:

```text
/games/C/Cannon Fodder 2 (1994)/
    Cannon Fodder 2 (1994).zip
```

The torrent retains the outer folder, so its name is `Cannon Fodder 2 (1994)`.
`--rename-game-folder` is not required when using `--zip-game`.
Files inside the ZIP retain their relative paths, including empty directories.
ZIP64 is enabled for large archives. Filesystem-invalid title characters are
replaced only in the directory/ZIP filenames; LST's title stays exact.

Example WebUI arguments:

```text
--category game --trackers LST --platform pc --game-subcategory full_game --igdb 11986 --zip-game --qbit-cat "SELF UPLOAD/GAMES/C" --draft
```

`--debug` only previews ZIP replacement: it does not create the ZIP, delete files
or rename the folder. This application's existing debug mode may still add the
original payload's torrent to your client. Without `--zip-game`, files are not
compressed or deleted by this feature.

The archive is read back and verified against SHA-256 hashes before deleting
originals. Changing files, symlinks, destination collisions and empty inputs are
rejected. The run needs enough free space for the ZIP while the originals still
exist. Remove old torrents using these files from qBittorrent without deleting
data before ZIP replacement; their contents and paths will no longer match.

If creation/verification fails, original files remain. If deletion is interrupted,
the verified ZIP is retained with any remaining originals, and upload preparation
stops. Do not delete that ZIP; it contains the recoverable originals. Review the
mixed folder before retrying. A successful run can be retried against the renamed
folder; the generated ZIP is verified and reused rather than zipped again.
Replacement happens only after you confirm the game metadata and approve the LST
upload. Declining either leaves the original files untouched. ZIP mode requires
attended confirmation; disable unattended/auto mode. After approval, the ZIP is
created and verified, originals are removed, and the torrent is built from the ZIP.
A later upload failure does not restore the original files; retain the verified ZIP.

## Validation and limitations

Regression tests cover LST game category and platform mapping, exact IGDB naming plus year, safe directory renaming,
missing-IGDB rejection, and the IGDB preparation-to-upload-payload path with mocked
network responses. No authenticated live upload has been performed. LST API
acceptance and your account permissions must be verified with your own credentials.
The upload uses the existing UNIT3D `igdb` field and LST's bundled catalog IDs.

Validation result: 127 targeted tests passed on Python 3.14.10.

TMDB validation fix (2026-10-29): Explicit --category game jobs no longer require
a TMDB API key. Shared preparation can initialize with an empty TMDB key.
Movie/TV and unspecified categories retain the key requirement.
35 focused regression tests passed after this fix.

IGDB selection fix: numbered choices now carry their game record directly,
preserve provider/platform ranking, display IGDB IDs, and handle blank/Skip.
61 targeted tests plus the Castles 1991/2015 regression passed.

ZIP update validation: 86 targeted tests passed, including verified replacement,
corruption, changing sources, partial cleanup failure, collisions, cancellation,
argument parsing and the final torrent root/ZIP layout.

Folder naming update: IGDB `Warcraft I: Remastered` yields the folder
`Warcraft I Remastered (2024)` containing `Warcraft I Remastered (2024).zip`.
ZIP mode keeps this folder without the misleading keep-folder prompt. Previously
generated sole ZIPs are verified and renamed, not repacked. 55 targeted tests passed.


## Change the IGDB match without restarting

When a search finds no games, attended mode prompts for an IGDB ID. When matches
are listed, choose "Enter a different IGDB ID". Enter a numeric ID or `--igdb ID`.
Invalid or missing IDs can be retried; blank input skips. Even a single search
result offers this choice. The normal game and LST confirmations still precede ZIP creation.
