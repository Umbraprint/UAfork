"""IGDB titles, opt-in game folder renaming and verified ZIP replacement."""

import asyncio
import contextlib
import hashlib
import os
import re
import tempfile
import threading
import zipfile
from pathlib import Path

from src.console import logger
from src.meta import Meta


def game_upload_name(meta: Meta) -> str:
    """Preserve the IGDB title verbatim; append only the selected release year."""
    if meta.igdb_id <= 0 or not meta.igdb_name.strip():
        raise ValueError(
            "Games require an IGDB name and ID. Configure twitch_client_id and "
            "twitch_client_secret (or TWITCH_CLIENT_ID and TWITCH_CLIENT_SECRET), "
            "then select a match or use --igdb ID."
        )
    year = str(meta.manual_year or meta.igdb_year or meta.year or "")
    if not re.fullmatch(r"[1-9][0-9]{3}", year):
        raise ValueError("A four-digit release year is required; use --year YYYY.")
    return f"{meta.igdb_name} {year}"


def game_filesystem_name(meta: Meta) -> str:
    """Format disk names as IGDB title (year), omitting invalid punctuation."""
    upload_name = game_upload_name(meta)
    title, year = upload_name.rsplit(" ", 1)
    title = re.sub(r'[<>:"/\\|?*\x00-\x1f]', " ", title)
    title = " ".join(title.split()).rstrip(" .")
    if not title:
        raise ValueError("The IGDB title cannot form a valid folder name.")
    return f"{title} ({year})"


def rename_game_folder(meta: Meta, videopath: str, video: str) -> tuple[str, str]:
    """Rename only the selected directory before tracker lookup or torrent hashing."""
    if not meta.rename_game_folder:
        return videopath, video
    if meta.category != "GAME":
        raise ValueError("--rename-game-folder requires --category game.")
    source_input = Path(str(meta.path or ""))
    if not meta.path or source_input.is_symlink() or source_input.is_junction() or not source_input.is_dir():
        raise ValueError("--rename-game-folder requires a real game directory, not a file or directory link.")
    source = source_input.resolve()
    if source == source.parent:
        raise ValueError("Cannot rename a filesystem root.")
    if meta.nohash:
        raise ValueError("--rename-game-folder cannot be combined with --nohash; the renamed torrent must be hashed.")
    folder_name = game_filesystem_name(meta)
    if not folder_name or len(folder_name.encode("utf-16-le")) // 2 > 255:
        raise ValueError("The IGDB title is too long for a folder name.")
    destination = source.parent / folder_name
    # Both absolute paths must remain in the same parent directory.
    if destination.parent.resolve() != source.parent:
        raise ValueError("The renamed directory must remain beside the source directory.")
    if source.name == folder_name:
        return videopath, video
    if destination.exists() or destination.is_symlink():
        raise FileExistsError(f"Refusing to overwrite existing path: {destination}")

    def remap(value: str) -> str:
        if not value:
            return value
        path = Path(value).absolute()
        try:
            relative = path.relative_to(source)
        except ValueError:
            return value
        return str(destination / relative)

    new_filelist = [remap(str(path)) for path in meta.filelist]
    new_videopath, new_video = remap(videopath), remap(video)
    if meta.debug:
        logger.info(f"GAME folder rename preview: {source} -> {destination}")
        return videopath, video
    source.rename(destination)
    meta.path = str(destination)
    meta.filelist = new_filelist
    meta.video = remap(meta.video)
    meta.basename_no_ext = destination.name
    meta.rehash = True
    # Never reuse a torrent whose root name refers to the old directory.
    meta.base_reuse_torrent_path = None
    meta.reuse_torrent_path = None
    meta.reuse_torrent_infohash = None
    meta.ext_torrenthash = None
    logger.info(f"Renamed GAME folder: {source} -> {destination}")
    return new_videopath, new_video


_ZIP_MARKER = b"igdb-game-archive-v1"


class GameZipCancelled(Exception):
    """Stop a packaging worker without deleting unarchived data."""


def _check_zip_cancel(cancel: threading.Event) -> None:
    if cancel.is_set():
        raise GameZipCancelled("Game ZIP creation cancelled.")


def _file_stamp(path: Path) -> tuple[int, int, int, int]:
    stat = path.stat()
    return stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns


def _game_inventory(source: Path, ignored: Path | None = None) -> dict[str, tuple[bool, tuple[int, int, int, int]]]:
    entries = {}
    for path in sorted(source.rglob("*")):
        if path == ignored:
            continue
        if path.is_symlink() or path.is_junction() or not path.resolve().is_relative_to(source):
            raise ValueError(f"Cannot package directory links or symlinks: {path}")
        directory = path.is_dir()
        if not directory and not path.is_file():
            raise ValueError(f"Cannot package special file: {path}")
        entries[path.relative_to(source).as_posix()] = (directory, _file_stamp(path))
    return entries


def _verify_game_zip(archive_path: Path, hashes: dict[str, str], cancel: threading.Event) -> None:
    """Read every archived byte, checking both ZIP CRCs and original SHA-256s."""
    with zipfile.ZipFile(archive_path) as archive:
        names = [info.filename for info in archive.infolist() if not info.is_dir()]
        if len(names) != len(hashes) or set(names) != set(hashes):
            raise ValueError("ZIP file list does not match the original files.")
        for name in names:
            digest = hashlib.sha256()
            with archive.open(name) as stream:
                while block := stream.read(1024 * 1024):
                    _check_zip_cancel(cancel)
                    digest.update(block)
            if digest.hexdigest() != hashes[name]:
                raise ValueError(f"ZIP verification failed for {name}; originals have been kept.")


def _replace_game_with_zip(meta: Meta, cancel: threading.Event) -> Path:
    """Commit a verified ZIP before removing only the inventoried originals."""
    source_input = Path(str(meta.path or ""))
    if meta.category != "GAME" or not meta.path or not source_input.is_dir():
        raise ValueError("--zip-game requires a game directory and --category game.")
    if source_input.is_symlink() or source_input.is_junction():
        raise ValueError("--zip-game does not accept directory links.")
    source = source_input.resolve()
    if source == source.parent:
        raise ValueError("Cannot package a filesystem root.")
    if meta.nohash:
        raise ValueError("--zip-game cannot be combined with --nohash.")
    name = game_filesystem_name(meta)
    if not name or len((name + ".zip").encode("utf-16-le")) // 2 > 255:
        raise ValueError("The IGDB title is too long for a ZIP filename.")
    destination = source.parent / name
    if destination.parent.resolve() != source.parent:
        raise ValueError("The renamed game must remain beside the original folder.")
    if source.name != name and (destination.exists() or destination.is_symlink()):
        raise FileExistsError(f"Refusing to overwrite existing folder: {destination}")
    final_zip = source / f"{name}.zip"
    entries = _game_inventory(source)
    if not any(not directory for directory, _stamp in entries.values()):
        raise ValueError("The game folder contains no files to archive.")
    if meta.debug:
        logger.info(f"ZIP preview: {source} -> {destination / final_zip.name}; originals would be deleted only after verification.")
        return final_zip

    # A completed archive can be reused after a cancelled upload, never nested
    # inside another ZIP. Mixed original/ZIP folders require explicit review.
    existing_zip = final_zip if final_zip.exists() else None
    if existing_zip is None and len(entries) == 1:
        candidate = source / next(iter(entries))
        if candidate.is_file() and candidate.suffix.lower() == ".zip":
            with contextlib.suppress(zipfile.BadZipFile):
                with zipfile.ZipFile(candidate) as archive:
                    if archive.comment == _ZIP_MARKER:
                        existing_zip = candidate
    if existing_zip is not None:
        if set(entries) != {existing_zip.name}:
            raise FileExistsError(f"ZIP already exists alongside other files: {final_zip}. Review these files before retrying.")
        with zipfile.ZipFile(existing_zip) as archive:
            if archive.comment != _ZIP_MARKER:
                raise FileExistsError(f"Refusing to replace an existing ZIP: {final_zip}")
            for info in archive.infolist():
                with archive.open(info) as stream:
                    while stream.read(1024 * 1024):
                        _check_zip_cancel(cancel)
        _check_zip_cancel(cancel)
        if existing_zip != final_zip:
            if final_zip.exists():
                raise FileExistsError(f"Refusing to overwrite ZIP: {final_zip}")
            existing_zip.rename(final_zip)
        if source.name != name:
            source.rename(destination)
        return destination / final_zip.name

    logger.info(f"Creating game ZIP from {len(entries)} entries: {source}")
    with tempfile.NamedTemporaryFile(prefix=".game-zip-", suffix=".partial", dir=source, delete=False) as temporary:
        staging = Path(temporary.name)
    hashes: dict[str, str] = {}
    try:
        with zipfile.ZipFile(staging, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True, strict_timestamps=False) as archive:
            archive.comment = _ZIP_MARKER
            for relative, (directory, _stamp) in entries.items():
                _check_zip_cancel(cancel)
                path = source / relative
                if path.is_symlink() or path.is_junction() or not path.resolve().is_relative_to(source):
                    raise ValueError(f"Source changed while packaging: {path}")
                info = zipfile.ZipInfo.from_file(path, arcname=relative, strict_timestamps=False)
                info.compress_type = zipfile.ZIP_DEFLATED
                if directory:
                    archive.writestr(info, b"")
                    continue
                digest = hashlib.sha256()
                with path.open("rb") as original, archive.open(info, "w", force_zip64=True) as packed:
                    while block := original.read(1024 * 1024):
                        _check_zip_cancel(cancel)
                        packed.write(block)
                        digest.update(block)
                hashes[relative] = digest.hexdigest()
        logger.info("Verifying game ZIP before deleting originals...")
        _verify_game_zip(staging, hashes, cancel)
        if _game_inventory(source, ignored=staging) != entries:
            raise ValueError("Game files changed during ZIP creation; originals have been kept.")
        _check_zip_cancel(cancel)
        if final_zip.exists():
            raise FileExistsError(f"Refusing to overwrite ZIP: {final_zip}")
        staging.chmod(0o644)
        with staging.open("r+b") as verified:
            os.fsync(verified.fileno())
        staging.rename(final_zip)
        if os.name != "nt":
            directory_fd = os.open(source, os.O_RDONLY | os.O_DIRECTORY)
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
        # From this point onwards, any error leaves the verified archive in
        # place. Never delete it, even if original-file cleanup only partly succeeds.
        for relative, (directory, stamp) in entries.items():
            if directory:
                continue
            _check_zip_cancel(cancel)
            path = source / relative
            if path.is_symlink() or not path.resolve().is_relative_to(source) or _file_stamp(path) != stamp:
                raise ValueError(f"Original file changed; stopping cleanup. Verified ZIP retained at {final_zip}")
            path.unlink()
        directories = [source / relative for relative, (directory, _stamp) in entries.items() if directory]
        for directory in sorted(directories, key=lambda item: len(item.parts), reverse=True):
            _check_zip_cancel(cancel)
            if directory.is_symlink() or directory.is_junction() or not directory.resolve().is_relative_to(source):
                raise ValueError(f"Directory changed; verified ZIP retained at {final_zip}")
            directory.rmdir()  # Only empty directories; never recursive deletion.
        if set(source.iterdir()) != {final_zip}:
            raise ValueError(f"New files appeared during cleanup; verified ZIP retained at {final_zip}")
        if source.name != name:
            source.rename(destination)
        return destination / final_zip.name
    except BaseException:
        if final_zip.is_file():
            logger.warning(f"ZIP processing stopped. Keep the verified archive at {final_zip}; some original files may remain.")
        raise
    finally:
        staging.unlink(missing_ok=True)


async def prepare_game_upload(meta: Meta, videopath: str, video: str) -> tuple[str, str]:
    """Prepare payload before torrent lookup/hashing; --zip-game includes renaming."""
    if not meta.zip_game:
        return rename_game_folder(meta, videopath, video)
    original_path = str(meta.path or "")
    cancel = threading.Event()
    task = asyncio.create_task(asyncio.to_thread(_replace_game_with_zip, meta, cancel))
    try:
        archive_path = await asyncio.shield(task)
    except asyncio.CancelledError:
        cancel.set()
        with contextlib.suppress(GameZipCancelled):
            await task
        raise
    if meta.debug:
        return videopath, video
    meta.game_zip_source = meta.game_zip_source or original_path
    meta.game_zip_path = str(archive_path)
    meta.path = str(archive_path.parent)
    meta.filelist = [str(archive_path)]
    meta.video = str(archive_path)
    meta.basename_no_ext = archive_path.parent.name
    meta.isdir = True
    meta.keep_folder = True  # Torrent name is the title/year, not title/year.zip.
    meta.container = "zip"
    meta.rehash = True
    meta.base_reuse_torrent_path = None
    meta.reuse_torrent_path = None
    meta.reuse_torrent_infohash = None
    meta.ext_torrenthash = None
    meta.subtitle_files = []
    logger.info(f"Verified game ZIP ready; original files removed: {archive_path}")
    return str(archive_path), str(archive_path)


async def zip_game_after_confirmation(meta: Meta, *, metadata_confirmed: bool) -> bool:
    """The destructive ZIP step is gated on both metadata and LST approval."""
    if not meta.zip_game:
        return True
    if meta.site_check or not metadata_confirmed:
        logger.info("ZIP skipped: game metadata has not been confirmed for upload.")
        return False
    if meta.unattended and not meta.debug:
        logger.warning("ZIP replacement needs an attended game confirmation and LST Upload? approval. Turn off unattended/auto mode.")
        return False
    selected = meta.trackers.split(",") if isinstance(meta.trackers, str) else meta.trackers
    if "LST" not in {str(tracker).strip().upper() for tracker in selected} or meta.tracker_status.get("LST", {}).get("upload") is not True:
        logger.info("ZIP skipped: upload to LST was not approved. Original files are untouched.")
        return False
    video = str(meta.filelist[0]) if meta.filelist else str(meta.path or "")
    await prepare_game_upload(meta, video, video)
    return True
