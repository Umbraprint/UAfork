"""Tests for opt-in folder renaming and exact IGDB titles."""
import pytest

from src.args import Args
from src.game_upload import game_upload_name, rename_game_folder
from src.meta import Meta


def game_meta(tmp_path, **kwargs):
    source = tmp_path / "Original.Release-GROUP"
    source.mkdir()
    payload = source / "setup.bin"
    payload.write_bytes(b"game data")
    return Meta(category="GAME", path=str(source), filelist=[str(payload)], video=str(payload),
                igdb_id=42, igdb_name="Game: The Sequel", igdb_year=2020, **kwargs), payload


def test_rename_remaps_paths_preserves_files_and_forces_new_hash(tmp_path):
    meta, payload = game_meta(tmp_path, rename_game_folder=True, manual_year=2024)
    meta.base_reuse_torrent_path = "old.torrent"
    video, other = rename_game_folder(meta, str(payload), str(payload))
    target = tmp_path / "Game_ The Sequel 2024"
    assert meta.path == str(target)
    assert (target / "setup.bin").read_bytes() == b"game data"
    assert not payload.parent.exists()
    assert meta.filelist == [video] == [other] == [str(target / "setup.bin")]
    assert meta.video == video
    assert meta.rehash and meta.base_reuse_torrent_path is None
    assert game_upload_name(meta) == "Game: The Sequel 2024"
    assert rename_game_folder(meta, video, other) == (video, other)


@pytest.mark.parametrize("enabled,debug", [(False, False), (True, True)])
def test_rename_opt_in_and_debug_leave_source_untouched(tmp_path, enabled, debug):
    meta, payload = game_meta(tmp_path, rename_game_folder=enabled, debug=debug)
    assert rename_game_folder(meta, str(payload), str(payload)) == (str(payload), str(payload))
    assert payload.exists()
    assert meta.path == str(payload.parent)
    assert not meta.rehash


def test_rename_refuses_existing_destination(tmp_path):
    meta, payload = game_meta(tmp_path, rename_game_folder=True)
    destination = tmp_path / "Game_ The Sequel 2020"
    destination.mkdir()
    with pytest.raises(FileExistsError):
        rename_game_folder(meta, str(payload), str(payload))
    assert payload.exists() and destination.is_dir()


def test_rename_refuses_single_file_and_nohash(tmp_path):
    meta, payload = game_meta(tmp_path, rename_game_folder=True, nohash=True)
    with pytest.raises(ValueError, match="nohash"):
        rename_game_folder(meta, str(payload), str(payload))
    meta.nohash = False
    meta.path = str(payload)
    with pytest.raises(ValueError, match="directory"):
        rename_game_folder(meta, str(payload), str(payload))
    assert payload.exists()


@pytest.mark.parametrize("field,value", [("igdb_id", 0), ("igdb_name", ""), ("igdb_year", 0)])
def test_missing_igdb_or_year_cannot_rename(tmp_path, field, value):
    meta, payload = game_meta(tmp_path, rename_game_folder=True)
    setattr(meta, field, value)
    with pytest.raises(ValueError):
        rename_game_folder(meta, str(payload), str(payload))
    assert payload.exists()


def test_title_preserves_unicode_punctuation_and_ignores_manual_title():
    meta = Meta(igdb_id=1, igdb_name="Ōkami HD: Collector's Edition", igdb_year=2017,
                title="Override", name="Release-GROUP", platform="LINUX", game_version="1.2")
    assert game_upload_name(meta) == "Ōkami HD: Collector's Edition 2017"
    meta.manual_year = 2018
    assert game_upload_name(meta).endswith(" 2018")


def test_game_arguments_are_parsed(tmp_path):
    meta, _, _ = Args({"DEFAULT": {"screens": 1}}).parse(
        [str(tmp_path), "--category", "game", "--platform", "linux", "--year", "2024", "--rename-game-folder"], Meta())
    assert meta.platform == "LINUX"
    assert meta.manual_year == 2024
    assert meta.rename_game_folder is True
