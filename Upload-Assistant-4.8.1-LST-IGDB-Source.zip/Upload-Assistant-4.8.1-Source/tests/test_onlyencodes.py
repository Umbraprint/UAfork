# ruff: noqa: S101
import asyncio

import pytest

from src.get_desc import DescriptionBuilder
from src.meta import Meta
from src.trackers.UNIT3D.onlyencodes import OnlyEncodes


def _name(meta: Meta) -> str:
    config = {"DEFAULT": {}, "TRACKERS": {"ONLYENCODES": {}}}
    return asyncio.run(OnlyEncodes(config).get_name(meta))["name"]


def _config() -> dict:
    return {
        "DEFAULT": {
            "add_logo": True,
            "multiScreens": 4,
            "thumbnail_size": 500,
            "pack_thumb_size": 500,
        },
        "TRACKERS": {"ONLYENCODES": {}},
    }


@pytest.mark.parametrize("category,episode", [("MOVIE", ""), ("TV", " S01E02")])
@pytest.mark.parametrize("aka", ["", "AKA Alternate Moon"])
@pytest.mark.parametrize("no_aka", [False, True])
def test_onlyencodes_keeps_tmdb_title_and_year(category: str, episode: str, aka: str, no_aka: bool) -> None:
    name_aka = f" {aka}" if aka and not no_aka else ""
    name = f"Silver Moon{name_aka} 2025{episode} 1080p WEB-DL DDP 5.1 H.264-FictionalGroup"
    meta = Meta(
        category=category,
        type="WEBDL",
        title="Silver Moon",
        year=2025,
        aka=aka,
        no_aka=no_aka,
        name=name,
        imdb_info={"title": "IMDb Moon", "aka": "Original Moon", "year": 2024},
        resolution="1080p",
        source="WEB",
        audio="DDP 5.1",
        video_encode="H.264",
        season="S01" if episode else "",
        episode="E02" if episode else "",
        search_year="2025",
        tag="-FictionalGroup",
        audio_languages=["English"],
        language_checked=True,
    )

    assert _name(meta) == name
    assert meta.name == name
    assert meta.title == "Silver Moon"
    assert meta.year == 2025
    assert meta.aka == aka


def _screens(count: int = 3) -> list[dict[str, str]]:
    return [
        {
            "web_url": f"https://onlyimage.org/view/{index}",
            "raw_url": f"https://onlyimage.org/image/{index}.png",
            "img_url": f"https://onlyimage.org/image/{index}.png",
        }
        for index in range(count)
    ]


@pytest.mark.parametrize("screens", [None, 0, 1, 2])
def test_onlyencodes_requires_three_screenshots(monkeypatch: pytest.MonkeyPatch, screens: int | None) -> None:
    tracker = OnlyEncodes(_config())
    monkeypatch.setattr(tracker.common, "check_and_confirm_adult_media_upload", lambda *_args: True)
    meta = Meta(screens=screens, is_disc="", audio_languages=["English"])

    assert asyncio.run(tracker.get_additional_checks(meta)) is False


def test_onlyencodes_accepts_three_screenshots(monkeypatch: pytest.MonkeyPatch) -> None:
    tracker = OnlyEncodes(_config())
    monkeypatch.setattr(tracker.common, "check_and_confirm_adult_media_upload", lambda *_args: True)

    async def language_check(*_args, **_kwargs) -> bool:
        return True

    monkeypatch.setattr(tracker.common, "check_language_requirements", language_check)
    meta = Meta(screens=3, is_disc="", audio_languages=["English"])

    assert asyncio.run(tracker.get_additional_checks(meta)) is True


def test_onlyencodes_description_uses_first_title_screens_and_linked_medium_format(monkeypatch: pytest.MonkeyPatch) -> None:
    config = _config()
    tracker = OnlyEncodes(config)
    captured: dict = {}

    async def description(builder: DescriptionBuilder, _meta: Meta, **kwargs) -> str:
        captured["tracker_config"] = dict(builder.tracker_config)
        captured["kwargs"] = kwargs
        return "description"

    monkeypatch.setattr(DescriptionBuilder, "general_description_generator", description)

    result = asyncio.run(tracker.get_description(Meta(category="TV", tv_pack=True, screens=3, image_list=_screens())))

    assert result == {"description": "description"}
    assert captured["tracker_config"] == {
        "add_logo": False,
        "multiScreens": 0,
        "thumbnail_size": 350,
        "pack_thumb_size": 350,
    }
    assert captured["kwargs"]["logo"] is False
    assert captured["kwargs"]["mediainfo"] is False
    assert captured["kwargs"]["nfo"] is False
    assert captured["kwargs"]["approved_image_hosts"] == list(tracker.approved_image_hosts)
    assert config["DEFAULT"] == {
        "add_logo": True,
        "multiScreens": 4,
        "thumbnail_size": 500,
        "pack_thumb_size": 500,
    }


def test_onlyencodes_disallows_banned_image_hosts() -> None:
    assert {"imgur", "postimg", "pixhost"}.isdisjoint(OnlyEncodes.approved_image_hosts)


@pytest.mark.parametrize("screenshots", [[], _screens(2), [{"web_url": "https://onlyimage.org/view/1"}]])
def test_onlyencodes_description_requires_three_hosted_linked_screenshots(screenshots: list[dict[str, str]]) -> None:
    tracker = OnlyEncodes(_config())

    with pytest.raises(ValueError, match="At least 3 hosted, linked screenshots"):
        asyncio.run(tracker.get_description(Meta(category="MOVIE", screens=3, image_list=screenshots)))


def test_onlyencodes_medium_screenshot_bbcode_links_to_full_image() -> None:
    builder = DescriptionBuilder("ONLYENCODES", _config())
    builder.tracker_config = {"thumbnail_size": 350}

    assert builder.format_screenshot("https://onlyimage.org/view/123", "https://onlyimage.org/image/123.png") == (
        "[url=https://onlyimage.org/view/123][img=350]https://onlyimage.org/image/123.png[/img][/url] "
    )


def _movie(**overrides: object) -> Meta:
    fields: dict[str, object] = {
        "category": "MOVIE",
        "type": "WEBRIP",
        "title": "Movie Title",
        "year": 2025,
        "resolution": "1080p",
        "source": "WEB",
        "audio": "DDP 5.1",
        "video_codec": "HEVC",
        "video_encode": "x265",
        "tag": "-RlsGrp",
        "basename_no_ext": "Movie.Title.2025.1080p.WEBRip.DDP5.1.x265-RlsGrp",
        "audio_languages": ["English"],
        "original_language": "en",
        "language_checked": True,
    }
    fields.update(overrides)
    return Meta(**fields)


def test_onlyencodes_adds_ds4k_after_resolution() -> None:
    meta = _movie(basename_no_ext="Movie.Title.2025.1080p.DS4K.WEBRip.DDP5.1.x265-RlsGrp")

    assert _name(meta) == "Movie Title 2025 1080p DS4K WEBRip DDP 5.1 x265-RlsGrp"


def test_onlyencodes_adds_rm4k_after_resolution() -> None:
    meta = _movie(type="ENCODE", source="BluRay", audio="", basename_no_ext="Movie.Title.2025.1080p.RM4K.BluRay.x264-RlsGrp", video_encode="x264")

    assert _name(meta) == "Movie Title 2025 1080p RM4K BluRay x264-RlsGrp"


def test_onlyencodes_normal_name_without_scale_tag() -> None:
    assert _name(_movie()) == "Movie Title 2025 1080p WEBRip DDP 5.1 x265-RlsGrp"


def test_onlyencodes_foreign_language_with_ds4k() -> None:
    meta = _movie(basename_no_ext="Movie.Title.2025.1080p.DS4K.WEBRip.DDP5.1.x265-RlsGrp", audio_languages=["French"], original_language="fr")

    assert _name(meta) == "Movie Title 2025 FRENCH 1080p DS4K WEBRip DDP 5.1 x265-RlsGrp"


def test_onlyencodes_places_language_after_episode_and_before_cut() -> None:
    meta = _movie(
        category="TV",
        title="Show Title",
        season="S01",
        episode="E02",
        search_year="",
        edition="Extended",
        audio_languages=["Spanish"],
        original_language="es",
    )

    assert _name(meta) == "Show Title S01E02 SPANISH Extended 1080p WEBRip DDP 5.1 x265-RlsGrp"


@pytest.mark.parametrize("tag", ["", "-NOGROUP", "-Unknown"])
def test_onlyencodes_uses_nogrp_without_a_release_group(tag: str) -> None:
    assert _name(_movie(tag=tag)) == "Movie Title 2025 1080p WEBRip DDP 5.1 x265-NOGRP"


def test_onlyencodes_formats_dvdrip_without_resolution() -> None:
    meta = _movie(type="DVDRIP", source="NTSC", resolution="480p", audio="DD 2.0", video_encode="x264")

    assert _name(meta) == "Movie Title 2025 DVDRip DD 2.0 x264-RlsGrp"


def test_onlyencodes_omits_resolution_and_codec_for_dvd_remux() -> None:
    meta = _movie(type="REMUX", source="NTSC DVD", resolution="480i", audio="DD 2.0", video_codec="MPEG-2")

    assert _name(meta) == "Movie Title 2025 NTSC DVD REMUX DD 2.0-RlsGrp"


def test_onlyencodes_moves_edition_out_of_title() -> None:
    meta = _movie(type="ENCODE", source="BluRay", edition="Special Edition 4K Remaster")

    assert _name(meta) == "Movie Title 2025 Special Edition 1080p BluRay DDP 5.1 x265-RlsGrp"


def test_onlyencodes_keeps_dual_audio_only_with_english_dub() -> None:
    meta = _movie(audio="MULTI DDP 5.1", original_language="ja", audio_languages=["Japanese", "English", "French"])

    assert _name(meta) == "Movie Title 2025 1080p WEBRip Dual-Audio DDP 5.1 x265-RlsGrp"
