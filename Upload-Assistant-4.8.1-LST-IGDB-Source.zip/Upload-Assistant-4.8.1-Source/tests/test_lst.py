"""Regression tests for LST-specific upload payloads."""

import asyncio

from src.meta import Meta
from src.trackers.UNIT3D.lst import LST


def test_lst_music_payload_includes_discogs_release_and_master_ids():
    meta = Meta(
        category="MUSIC",
        music_release={"external_ids": {"discogs_release": "https://www.discogs.com/release/12345-example", "discogs_master": "master/67890"}},
    )

    data = asyncio.run(LST({"DEFAULT": {}, "TRACKERS": {"LST": {}}}).get_additional_data(meta))

    assert data["release_exists_on_discogs"] == "1"
    assert data["discogs"] == "12345"
    assert data["discogs_master_id"] == "67890"
    assert data["extra_discogs_ids"] == ""
    assert data["extra_discogs_master_ids"] == ""


def test_lst_music_payload_omits_discogs_existence_flag_for_invalid_ids():
    meta = Meta(category="MUSIC", music_release={"external_ids": {"discogs_release": "not-an-id"}})

    data = asyncio.run(LST({"DEFAULT": {}, "TRACKERS": {"LST": {}}}).get_additional_data(meta))

    assert "release_exists_on_discogs" not in data


def test_lst_music_name_uses_technical_fields_for_lossless_releases():
    meta = Meta(
        category="MUSIC",
        tag="-FiVE0",
        music_release={
            "fields": {
                "artist": {"value": "Example Artist"},
                "album": {"value": "Sample Album"},
                "release_year": {"value": "2012"},
                "media": {"value": "WEB"},
            },
            "tracks": [{"codec": "FLAC", "bit_depth": 16, "sample_rate": 44100}],
        },
    )

    name = asyncio.run(LST({"DEFAULT": {}, "TRACKERS": {"LST": {}}}).get_name(meta))["name"]

    assert name == "Example Artist - Sample Album 2012 WEB FLAC 16-bit 44.1 kHz-FiVE0"


def test_lst_music_name_ignores_invalid_sample_rate():
    meta = Meta(
        category="MUSIC",
        music_release={
            "fields": {
                "artist": {"value": "Artist"},
                "album": {"value": "Album"},
                "release_year": {"value": "2000"},
                "media": {"value": "CD"},
                "nfo_sample_rate": {"value": "unknown"},
            },
            "tracks": [{"codec": "FLAC", "bit_depth": 16}],
        },
    )

    name = asyncio.run(LST({"DEFAULT": {}, "TRACKERS": {"LST": {}}}).get_name(meta))["name"]

    assert name == "Artist - Album 2000 CD FLAC 16-bit"


def test_lst_audiobook_name_omits_lossy_technical_fields():
    meta = Meta(category="BOOK", audiobook=True, author="Sample Author", title="Invented Audiobook", year=2011, source="WEB", type="M4B", tag="zeno")

    name = asyncio.run(LST({"DEFAULT": {}, "TRACKERS": {"LST": {}}}).get_name(meta))["name"]

    assert name == "Sample Author - Invented Audiobook 2011 WEB M4B-zeno"


def test_lst_ebook_name_includes_edition_type_and_isbn():
    meta = Meta(
        category="BOOK",
        author="Example Author",
        title="Fictional Book",
        edition="Revised Edition",
        year=2008,
        type="PDF",
        ocr=True,
        isbn="978-0123456472",
        tag="-GROUP",
    )

    name = asyncio.run(LST({"DEFAULT": {}, "TRACKERS": {"LST": {}}}).get_name(meta))["name"]

    assert name == "Example Author - Fictional Book Revised Edition 2008 PDF OCR 9780123456472-GROUP"


def test_lst_games_are_supported_and_use_catalog_category():
    tracker = LST({"DEFAULT": {}, "TRACKERS": {"LST": {}}})
    assert "GAME" in tracker.supported_categories
    assert asyncio.run(tracker.get_category_id(Meta(category="GAME"))) == {"category_id": "4"}
    assert asyncio.run(tracker.get_category_id(Meta(), reverse=True))["4"] == "GAME"


def test_lst_game_platform_types():
    tracker = LST({"DEFAULT": {}, "TRACKERS": {"LST": {}}})
    for platform, expected in [("PC", "13"), ("PC (Microsoft Windows)", "13"), ("Windows", "13"),
                               ("Mac", "12"), ("macOS", "12"), ("Linux", "14"), ("PS5", "15"), ("", "15")]:
        meta = Meta(category="GAME", type="GAME", platform=platform)
        assert asyncio.run(tracker.get_type_id(meta)) == {"type_id": expected}
    meta = Meta(category="GAME", platform="PC", manual_platform="Linux")
    assert asyncio.run(tracker.get_type_id(meta)) == {"type_id": "14"}
    assert asyncio.run(tracker.get_type_id(meta, media_type="MAC")) == {"type_id": "12"}


def test_lst_game_uses_exact_igdb_name_plus_year_and_checks_igdb():
    tracker = LST({"DEFAULT": {}, "TRACKERS": {"LST": {}}})
    meta = Meta(category="GAME", name="Example v1.2 2024 LINUX-GROUP", igdb_id=42, igdb_name="Example: Original Title", igdb_year=2023, valid_mi_settings=False)
    assert asyncio.run(tracker.get_name(meta)) == {"name": "Example: Original Title (2023)"}
    meta.manual_year = 2024
    meta.trump_reason = "exact_match"
    assert asyncio.run(tracker.get_name(meta)) == {"name": "Example: Original Title (2024)"}
    assert asyncio.run(tracker.get_additional_checks(meta)) is True
    assert asyncio.run(tracker.get_igdb(meta)) == {"igdb": "42"}
    assert asyncio.run(tracker.get_mediainfo(meta)) == {"mediainfo": ""}
    meta.igdb_id = 0
    assert asyncio.run(tracker.get_additional_checks(meta)) is False


def test_lst_game_igdb_lookup_reaches_upload_payload(tmp_path, monkeypatch):
    from unittest.mock import AsyncMock

    from src.prep_game import gather_game_prep

    game = {"id": 42, "name": "Example Game", "summary": "Example overview", "platforms": [{"name": "Linux"}]}
    api = AsyncMock()
    api.fetch_game_by_id.return_value = game
    api.fetch_time_to_beat.return_value = {}
    monkeypatch.setattr("src.prep_game.IGDBAPI", lambda *_args: api)
    config = {"DEFAULT": {"twitch_client_id": "test-id", "twitch_client_secret": "test-secret"}, "TRACKERS": {"LST": {}}}
    meta = Meta(category="GAME", igdb_manual="42", manual_platform="LINUX", platform="LINUX",
                manual_year=2024, game_title="Manual override", path=str(tmp_path / "Example.Game"), base_dir=str(tmp_path), uuid="game", unattended=True)
    asyncio.run(gather_game_prep(meta, str(meta.path), str(tmp_path), config))
    api.fetch_game_by_id.assert_awaited_once_with("42")
    tracker = LST(config)
    monkeypatch.setattr(tracker, "get_description", AsyncMock(return_value={"description": meta.overview}))
    data = asyncio.run(tracker.get_data(meta))
    assert data["name"] == "Example Game (2024)"
    assert data["igdb"] == "42"
    assert data["category_id"] == "4"
    assert data["type_id"] == "14"
    assert data["resolution_id"] == "10"
    assert data["mediainfo"] == ""
    assert data["description"] == "Example overview"
