# ruff: noqa: S101

import asyncio
import json
import sys
from collections import Counter
from pathlib import Path
from random import Random
from unittest.mock import AsyncMock, patch

import pytest
from PIL import Image

from src import prep_helpers, takescreens
from src.meta import Meta
from src.prep import Prep, populate_hdr_for_early_capture
from src.screenshot_manifest import capture_timestamps, register
from src.takescreens import screenshots
from src.uploadscreens import _upload_screens


class _TakeScreens:
    def __init__(self) -> None:
        self.calls: list[tuple[tuple[object, ...], dict[str, object]]] = []

    async def screenshots(self, *_args: object, **_kwargs: object) -> None:
        self.calls.append((_args, _kwargs))

    async def disc_screenshots(self, *_args: object, **_kwargs: object) -> None:
        self.calls.append((_args, _kwargs))


def _prep_with_screenshot_spy() -> tuple[Prep, _TakeScreens]:
    prep = Prep.__new__(Prep)
    screenshot_spy = _TakeScreens()
    prep.takescreens_manager = screenshot_spy
    prep.config = {"DEFAULT": {"multiScreens": 2}}
    return prep, screenshot_spy


def test_early_screenshots_wait_for_description_images() -> None:
    prep, screenshot_spy = _prep_with_screenshot_spy()
    meta = Meta(category="MOVIE", keep_images=True, screens=6)

    asyncio.run(prep._capture_early_screenshots(meta, "Release", "C:/media/Release.mkv", {}))

    assert screenshot_spy.calls == []


def test_early_screenshots_remain_enabled_without_description_images() -> None:
    prep, screenshot_spy = _prep_with_screenshot_spy()
    meta = Meta(category="MOVIE", keep_images=False, screens=6)

    asyncio.run(prep._capture_early_screenshots(meta, "Release", "C:/media/Release.mkv", {}))

    assert len(screenshot_spy.calls) == 1
    assert screenshot_spy.calls[0][1]["capture_group"] == "main"


def test_early_capture_populates_hdr_before_category_detection(monkeypatch) -> None:
    meta = Meta(category="")

    async def hdr_stub(mi, bdinfo):
        assert mi == {"media": {"track": []}}
        assert bdinfo == {}
        return "HDR"

    monkeypatch.setattr("src.prep.prep_helpers.video_manager.get_hdr", hdr_stub)

    asyncio.run(populate_hdr_for_early_capture(meta, {"media": {"track": []}}, {}))

    assert meta.hdr == "HDR"


def test_early_capture_skips_hdr_probe_without_video_metadata() -> None:
    meta = Meta(category="BOOK")

    asyncio.run(populate_hdr_for_early_capture(meta, None, None))

    assert meta.hdr == ""


def test_personal_release_config_skips_auto_torrent_before_client_search(tmp_path: Path) -> None:
    prep = Prep.__new__(Prep)
    prep.config = {"DEFAULT": {"skip_auto_torrent_personalrelease": True}}
    meta = Meta(base_dir=str(tmp_path), path=str(tmp_path), personalrelease=True)

    prep_helpers.init_meta(prep, meta, "cli")

    assert meta.skip_auto_torrent


def test_frame_overlay_config_is_set_before_early_capture(tmp_path: Path) -> None:
    prep = Prep.__new__(Prep)
    prep.config = {"DEFAULT": {"frame_overlay": True}}
    meta = Meta(base_dir=str(tmp_path), path=str(tmp_path))

    prep_helpers.init_meta(prep, meta, "cli")

    assert meta.frame_overlay is True


def test_forbidden_tracker_defers_frame_overlay_capture() -> None:
    prep, screenshot_spy = _prep_with_screenshot_spy()
    prep.config["TRACKERS"] = {"default_trackers": "AVISTAZ"}
    meta = Meta(category="MOVIE", keep_images=False, screens=6, frame_overlay=True)

    asyncio.run(prep._capture_early_screenshots(meta, "Release", "C:/media/Release.mkv", {}))

    assert screenshot_spy.calls == []


def test_registered_main_screenshots_are_reused_when_title_changes(tmp_path: Path) -> None:
    release_id = "release"
    screenshot_dir = tmp_path / "tmp" / release_id / "screenshots"
    screenshot_dir.mkdir(parents=True)
    original_paths = []
    for index in range(2):
        image = screenshot_dir / f"unpunctuated-title-{index}.png"
        image.write_bytes(b"image")
        original_paths.append(image)
    registered = register(tmp_path, release_id, original_paths, "main")
    meta = Meta(category="MOVIE", base_dir=str(tmp_path), uuid=release_id, screens=6, imghost="imgbb")

    with patch("src.takescreens.get_image_host", new=AsyncMock(return_value="imgbb")):
        result = asyncio.run(screenshots("unused.mkv", "Punctuated, Title", release_id, str(tmp_path), meta, manual_frames=[100, 200]))

    assert set(result or []) == {str(path) for path in registered}


def test_pack_capture_ignores_uploaded_images_from_main_group(tmp_path: Path) -> None:
    release_id = "release"
    release_dir = tmp_path / "tmp" / release_id
    release_dir.mkdir(parents=True)
    (release_dir / "MediaInfo.json").write_text(
        '{"media": {"track": [{"Duration": "100"}, {"Duration": "100", "Width": "1920", "Height": "1080", "PixelAspectRatio": "1", "DisplayAspectRatio": "1.777", "FrameRate": "24"}]}}',
        encoding="utf-8",
    )
    meta = Meta(
        category="MOVIE",
        base_dir=str(tmp_path),
        uuid=release_id,
        screens=2,
        imghost="imgbb",
        image_list=[{"img_url": "https://images.example/main.png"}],
    )
    capture_calls: list[object] = []

    async def capture_stub(args: tuple[object, ...]):
        capture_calls.append(args)
        output = Path(str(args[3]))
        output.write_bytes(b"image")
        return args[0], str(output)

    with (
        patch("src.takescreens.get_image_host", new=AsyncMock(return_value="imgbb")),
        patch("src.takescreens.capture_screenshot", new=capture_stub),
    ):
        result = asyncio.run(
            screenshots(
                "unused.mkv",
                "FILE_1",
                release_id,
                str(tmp_path),
                meta,
                manual_frames=[100, 200],
                capture_group="FILE_1",
            )
        )

    assert len(capture_calls) == 2
    assert len(result or []) == 2


def test_partial_registered_group_captures_only_missing_screenshots(tmp_path: Path) -> None:
    release_id = "release"
    release_dir = tmp_path / "tmp" / release_id
    screenshot_dir = release_dir / "screenshots"
    screenshot_dir.mkdir(parents=True)
    (release_dir / "MediaInfo.json").write_text(
        '{"media": {"track": [{"Duration": "100"}, {"Duration": "100", "Width": "1920", "Height": "1080", "PixelAspectRatio": "1", "DisplayAspectRatio": "1.777", "FrameRate": "24"}]}}',
        encoding="utf-8",
    )
    existing = []
    for index in range(2):
        image = screenshot_dir / f"existing-{index}.png"
        image.write_bytes(b"image")
        existing.append(image)
    register(tmp_path, release_id, existing, "main")
    meta = Meta(category="MOVIE", base_dir=str(tmp_path), uuid=release_id, screens=3, imghost="imgbb")
    capture_calls: list[object] = []

    async def capture_stub(args: tuple[object, ...]):
        capture_calls.append(args)
        output = Path(str(args[3]))
        output.write_bytes(b"image")
        return args[0], str(output)

    with (
        patch("src.takescreens.get_image_host", new=AsyncMock(return_value="imgbb")),
        patch("src.takescreens.capture_screenshot", new=capture_stub),
    ):
        result = asyncio.run(screenshots("unused.mkv", "Punctuated, Title", release_id, str(tmp_path), meta, manual_frames=[100, 200, 300]))

    assert len(capture_calls) == 1
    assert len(result or []) == 3


@pytest.mark.parametrize("failed_indices", [{0, 3}, {2, 5}, {4, 5}])
@pytest.mark.parametrize(
    ("manual_frames", "duration", "unique_frames", "retake"),
    [("", 100, 6, False), ("120,240,360,480,600,720", 100, 6, False), ("120,120,240,240,360,360", 100, 3, False), ("", 0.1, 1, False), ("", 100, 6, True)],
)
def test_partial_capture_completes_missing_frame_slots(tmp_path: Path, failed_indices: set[int], manual_frames: str, duration: float, unique_frames: int, retake: bool) -> None:
    release_id = "fictional-release"
    release_dir = tmp_path / "tmp" / release_id
    release_dir.mkdir(parents=True)
    (release_dir / "MediaInfo.json").write_text(
        json.dumps(
            {
                "media": {
                    "track": [
                        {"Duration": duration},
                        {"Duration": duration, "Width": 1920, "Height": 1080, "PixelAspectRatio": 1, "DisplayAspectRatio": 1.777, "FrameRate": 24},
                    ]
                }
            }
        ),
        encoding="utf-8",
    )
    meta = Meta(category="MOVIE", base_dir=str(tmp_path), uuid=release_id, screens=6, imghost="imgbb")
    phase = 0
    captured: list[list[float]] = [[], []]
    initial_times: dict[int, float] = {}

    async def capture_stub(args):
        output = Path(args[3])
        is_retry = output.stem.endswith("-retry")
        if phase == 0 and not is_retry:
            initial_times[args[0]] = args[2]
        if phase == 0 and args[0] in failed_indices:
            return args[0], None
        if phase == 0 and retake and args[0] == 0 and not is_retry:
            output.write_bytes(b"image" * 10000)
            return args[0], str(output)
        captured[phase].append(args[2])
        output.write_bytes(b"image" * 20000)
        return args[0], str(output)

    with (
        patch.object(takescreens, "get_image_host", new=AsyncMock(return_value="imgbb")),
        patch.object(takescreens, "capture_screenshot", new=capture_stub),
        patch.object(takescreens, "determine_tonemapping", new=AsyncMock(return_value=False)),
        patch.object(takescreens, "record_event_async", new=AsyncMock()),
    ):
        first = asyncio.run(screenshots("unused.mkv", "Fictional Movie", release_id, str(tmp_path), meta, manual_frames=manual_frames, cleanup_after_capture=False))
        assert len(first or []) == 4
        phase = 1
        # Recreate metadata as a resumed run would, and change the display title.
        meta = Meta(category="MOVIE", base_dir=str(tmp_path), uuid=release_id, screens=6, imghost="imgbb")
        result = asyncio.run(screenshots("unused.mkv", "Fictional, Movie", release_id, str(tmp_path), meta, manual_frames=manual_frames, cleanup_after_capture=False))
        assert len(result or []) == 6
        assert len(captured[1]) == 2
        assert Counter(captured[1]) == Counter(initial_times[index] for index in failed_indices)
        timestamps = capture_timestamps(tmp_path, release_id, "main")
        assert len(timestamps) == 6
        assert len(set(timestamps)) == unique_frames
        assert Counter(capture_timestamps(tmp_path, release_id, "main", original_slots=True)) == Counter(initial_times.values())
        if retake and 0 not in failed_indices:
            assert initial_times[0] + 5 in timestamps
            assert initial_times[0] not in timestamps
        if unique_frames == 6:
            assert set(captured[0]).isdisjoint(captured[1])
        if manual_frames:
            assert Counter(timestamps) == Counter(int(frame) / 24 for frame in manual_frames.split(","))
        captured[1].clear()
        asyncio.run(screenshots("unused.mkv", "Fictional Movie", release_id, str(tmp_path), meta, manual_frames=manual_frames, cleanup_after_capture=False))
        assert captured[1] == []


@pytest.mark.asyncio
async def test_successful_screenshot_capture_preserves_unrelated_child(tmp_path: Path) -> None:
    release_id = "release"
    release_dir = tmp_path / "tmp" / release_id
    release_dir.mkdir(parents=True)
    (release_dir / "MediaInfo.json").write_text(
        '{"media": {"track": [{"Duration": "100"}, {"Duration": "100", "Width": "1920", "Height": "1080", "PixelAspectRatio": "1", "DisplayAspectRatio": "1.777", "FrameRate": "24"}]}}',
        encoding="utf-8",
    )
    meta = Meta(category="MOVIE", base_dir=str(tmp_path), uuid=release_id, screens=1, imghost="imgbb")

    async def capture_stub(args: tuple[object, ...]):
        output = Path(str(args[3]))
        output.write_bytes(b"image" * 20000)
        return args[0], str(output)

    unrelated = await asyncio.create_subprocess_exec(sys.executable, "-c", "import time; time.sleep(60)")
    try:
        with (
            patch("src.takescreens.get_image_host", new=AsyncMock(return_value="imgbb")),
            patch("src.takescreens.capture_screenshot", new=capture_stub),
        ):
            result = await screenshots("unused.mkv", "Release", release_id, str(tmp_path), meta, manual_frames=[100], cleanup_after_capture=False)

        assert len(result or []) == 1
        await asyncio.sleep(0.05)
        assert unrelated.returncode is None, "successful screenshot capture terminated an unrelated child process"
    finally:
        if unrelated.returncode is None:
            unrelated.terminate()
        try:
            await asyncio.wait_for(unrelated.wait(), timeout=3)
        except TimeoutError:
            unrelated.kill()
            await unrelated.wait()


def test_upload_uses_only_registered_main_screenshots(tmp_path: Path, monkeypatch) -> None:
    release_id = "release"
    screenshot_dir = tmp_path / "tmp" / release_id / "screenshots"
    screenshot_dir.mkdir(parents=True)
    main_source = screenshot_dir / "main.png"
    file_source = screenshot_dir / "file.png"
    main_source.write_bytes(b"main")
    file_source.write_bytes(b"file")
    main_screen = register(tmp_path, release_id, [main_source], "main")[0]
    register(tmp_path, release_id, [file_source], "FILE_1")
    meta = Meta(base_dir=str(tmp_path), uuid=release_id, imghost="imgbb", image_list=[])
    calls: list[str] = []

    async def upload_stub(args: list[object]) -> dict[str, str]:
        calls.append(str(args[0]))
        return {"status": "success", "img_url": "https://images.example/main.png", "raw_url": "https://images.example/main.png", "web_url": "https://images.example/main.png"}

    config = {"DEFAULT": {"img_host_1": "imgbb"}, "TRACKERS": {}}
    monkeypatch.chdir(screenshot_dir)
    with patch("src.uploadscreens.upload_image_task", new=upload_stub):
        _, uploaded_count = asyncio.run(_upload_screens(config, meta, 1, 1, 0, 1, [], {}))

    assert uploaded_count == 1
    assert calls == [str(main_screen)]


def test_early_bdmv_capture_includes_alternate_playlists() -> None:
    prep, screenshot_spy = _prep_with_screenshot_spy()
    meta = Meta(
        category="MOVIE",
        keep_images=False,
        screens=6,
        is_disc="BDMV",
        discs=[{"bdinfo": {}, "bdinfo_1": {}}],
    )

    asyncio.run(prep._capture_early_screenshots(meta, "Release", "", {}))

    assert len(screenshot_spy.calls) == 2
    assert screenshot_spy.calls[0][1]["capture_group"] == "main"
    assert screenshot_spy.calls[1][0][-1] == "PLAYLIST_1"


def test_early_bdmv_capture_includes_extra_discs() -> None:
    prep, screenshot_spy = _prep_with_screenshot_spy()
    meta = Meta(
        category="MOVIE",
        keep_images=False,
        screens=6,
        is_disc="BDMV",
        discs=[{"bdinfo": {}}, {"type": "BDMV", "bdinfo": {}}],
    )

    asyncio.run(prep._capture_early_screenshots(meta, "Release", "", {}))

    assert len(screenshot_spy.calls) == 2
    assert screenshot_spy.calls[1][0][-1] == "FILE_1"


def test_early_capture_returns_meta_with_tonemapping() -> None:
    prep = Prep.__new__(Prep)

    class _TonemappingTakeScreens:
        async def screenshots(self, *_args: object, **kwargs: object) -> None:
            meta_arg = _args[4] if len(_args) > 4 else kwargs.get("meta")
            if isinstance(meta_arg, Meta):
                meta_arg.tonemapped = True
                meta_arg.libplacebo = True

    prep.takescreens_manager = _TonemappingTakeScreens()
    prep.config = {"DEFAULT": {"multiScreens": 2}}
    meta = Meta(category="MOVIE", keep_images=False, screens=6, hdr="HDR")

    result = asyncio.run(prep._capture_early_screenshots(meta, "Release", "C:/media/Release.mkv", {}))

    assert result is not None
    assert result.tonemapped is True
    assert result.libplacebo is True


def test_screenshots_sets_tonemapped_when_reusing_existing_screenshots(tmp_path: Path) -> None:
    release_id = "release_tonemap"
    release_dir = tmp_path / "tmp" / release_id
    screenshot_dir = release_dir / "screenshots"
    screenshot_dir.mkdir(parents=True)
    (release_dir / "MediaInfo.json").write_text(
        '{"media": {"track": [{"Duration": "100"}, {"Duration": "100", "Width": "1920", "Height": "1080", "PixelAspectRatio": "1", "DisplayAspectRatio": "1.777", "FrameRate": "24"}]}}',
        encoding="utf-8",
    )
    for index in range(2):
        image = screenshot_dir / f"title-{index}.png"
        Image.frombytes("RGB", (256, 256), Random(index).randbytes(256 * 256 * 3)).save(image)
    meta = Meta(category="MOVIE", base_dir=str(tmp_path), uuid=release_id, screens=2, hdr="HDR10", imghost="imgbb")

    with (
        patch("src.takescreens.tone_map", True),
        patch("src.takescreens.get_image_host", new=AsyncMock(return_value="imgbb")),
    ):
        result = asyncio.run(screenshots("unused.mkv", "title", release_id, str(tmp_path), meta, num_screens=2))

    assert len(result or []) == 2
    assert meta.tonemapped is True
