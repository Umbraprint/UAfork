# Upload Assistant © 2025 Audionut & wastaken7 — Licensed under UAPL v1.0
import re
from pathlib import Path
from typing import Any, cast

from src.console import logger
from src.meta import Meta
from src.trackers.common import Common
from src.trackers.UNIT3D import UNIT3D

Config = dict[str, Any]


class Portugas(UNIT3D):
    """
    Portugas is a PORTUGUESE Private Torrent Tracker for 0DAY / GENERAL
    """

    tracker = "PORTUGAS"
    display_name = "Portugas"
    base_url = "https://portugas.org"
    banned_groups = ()
    id_url = f"{base_url}/api/torrents/"
    upload_url = f"{base_url}/api/torrents/upload"
    search_url = f"{base_url}/api/torrents/filter"
    torrent_url = f"{base_url}/torrents/"
    supported_categories = ("TV", "MOVIE")
    tracker_urls = ("https://portugas.org",)
    allowed_bloated_audio_languages = ("pt",)

    def __init__(self, config: Config) -> None:
        super().__init__(config, tracker_name="PORTUGAS")
        self.config: Config = config
        self.common = Common(config)

    async def get_type_id(self, meta: Meta, type: str | None = None, reverse: bool = False, mapping_only: bool = False) -> dict[str, str]:
        _ = (type, reverse, mapping_only)
        type_id = {"DISC": "1", "REMUX": "2", "WEBDL": "4", "WEBRIP": "39", "HDTV": "6", "ENCODE": "3"}.get(str(meta.type), "0")
        return {"type_id": type_id}

    async def get_resolution_id(self, meta: Meta, resolution: str | None = None, reverse: bool = False, mapping_only: bool = False) -> dict[str, str]:
        _ = (resolution, reverse, mapping_only)
        resolution_id = {
            "4320p": "1",
            "2160p": "2",
            "1440p": "13",
            "1080p": "3",
            "1080i": "4",
            "720p": "5",
            "576p": "6",
            "576i": "7",
            "540p": "11",
            "480p": "8",
            "480i": "9",
        }.get(meta.resolution, "10")
        return {"resolution_id": resolution_id}

    async def get_name(self, meta: Meta) -> dict[str, str]:
        if meta.manual_name is not None:
            return {"name": meta.manual_name.strip()}

        name = meta.name.replace(" ", ".")

        pt_name = name
        tag_value = meta.tag or ""
        tag_lower = tag_value.lower()
        invalid_tags = ["nogrp", "nogroup", "unknown", "-unk-"]

        if tag_value == "" or any(invalid_tag in tag_lower for invalid_tag in invalid_tags):
            for invalid_tag in invalid_tags:
                pt_name = re.sub(f"-{invalid_tag}", "", pt_name, flags=re.IGNORECASE)
            pt_name = f"{pt_name}-NOGROUP"

        return {"name": pt_name}

    def get_audio(self, meta: Meta) -> int:
        found_portuguese_audio = False

        if meta.is_disc == "BDMV":
            bdinfo = meta.bdinfo
            audio_tracks = cast(list[dict[str, Any]], bdinfo.get("audio", []))
            if audio_tracks:
                for track in audio_tracks:
                    lang = str(track.get("language", ""))
                    if lang and lang.lower() == "portuguese":
                        found_portuguese_audio = True
                        break

        needs_mediainfo_check = (meta.is_disc != "BDMV") or (meta.is_disc == "BDMV" and not found_portuguese_audio)

        if needs_mediainfo_check:
            base_dir = meta.base_dir if meta.base_dir is not None else "."
            uuid = meta.uuid if meta.uuid is not None else "default_uuid"
            media_info_path = Path(base_dir) / "tmp" / uuid / "MEDIAINFO.txt"

            try:
                if Path(media_info_path).exists():
                    with Path(media_info_path).open(encoding="utf-8") as f:
                        media_info_text = f.read()

                    if not found_portuguese_audio:
                        audio_sections = re.findall(r"Audio(?: #\d+)?\s*\n(.*?)(?=\n\n(?:Audio|Video|Text|Other|Image|Menu)|$)", media_info_text, re.DOTALL | re.IGNORECASE)
                        for section in audio_sections:
                            language_match = re.search(r"Language\s*:\s*(.+)", section, re.IGNORECASE)
                            title_match = re.search(r"Title\s*:\s*(.+)", section, re.IGNORECASE)

                            lang_raw = language_match.group(1).strip() if language_match else ""
                            title_raw = title_match.group(1).strip() if title_match else ""

                            text = f"{lang_raw} {title_raw}".lower()

                            if "portuguese" in text and not any(keyword in text for keyword in ["(br)", "brazilian"]):
                                found_portuguese_audio = True
                                break

            except FileNotFoundError:
                pass
            except Exception as e:
                logger.info(f"ERRO: Falha ao processar MediaInfo para verificar áudio Português: {e}", extra={"markup": False})

        return 1 if found_portuguese_audio else 0

    def get_subtitles(self, meta: Meta) -> int:
        found_portuguese_subtitle = False

        if meta.is_disc == "BDMV":
            bdinfo = meta.bdinfo
            subtitle_tracks = cast(list[Any], bdinfo.get("subtitles", []))
            if subtitle_tracks:
                found_portuguese_subtitle = False
                for track in subtitle_tracks:
                    if isinstance(track, str) and track.lower() == "portuguese":
                        found_portuguese_subtitle = True
                        break

        needs_mediainfo_check = (meta.is_disc != "BDMV") or (meta.is_disc == "BDMV" and not found_portuguese_subtitle)

        if needs_mediainfo_check:
            base_dir = meta.base_dir if meta.base_dir is not None else "."
            uuid = meta.uuid if meta.uuid is not None else "default_uuid"
            media_info_path = Path(base_dir) / "tmp" / uuid / "MEDIAINFO.txt"

            try:
                if Path(media_info_path).exists():
                    with Path(media_info_path).open(encoding="utf-8") as f:
                        media_info_text = f.read()

                    if not found_portuguese_subtitle:
                        text_sections = re.findall(r"Text(?: #\d+)?\s*\n(.*?)(?=\n\n(?:Audio|Video|Text|Other|Image|Menu)|$)", media_info_text, re.DOTALL | re.IGNORECASE)
                        if not text_sections:
                            text_sections = re.findall(
                                r"Subtitle(?: #\d+)?\s*\n(.*?)(?=\n\n(?:Audio|Video|Text|Other|Image|Menu)|$)", media_info_text, re.DOTALL | re.IGNORECASE
                            )

                        for section in text_sections:
                            language_match = re.search(r"Language\s*:\s*(.+)", section, re.IGNORECASE)
                            title_match = re.search(r"Title\s*:\s*(.+)", section, re.IGNORECASE)

                            lang_raw = language_match.group(1).strip() if language_match else ""
                            title_raw = title_match.group(1).strip() if title_match else ""

                            text = f"{lang_raw} {title_raw}".lower()

                            if "portuguese" in text and not any(keyword in text for keyword in ["(br)", "brazilian"]):
                                found_portuguese_subtitle = True
                                break

            except FileNotFoundError:
                pass
            except Exception as e:
                logger.info(f"ERRO: Falha ao processar MediaInfo para verificar legenda Português: {e}", extra={"markup": False})

        return 1 if found_portuguese_subtitle else 0

    async def get_distributor_ids(self, _meta: Meta) -> dict[str, str]:
        return {}

    async def get_region_id(self, meta: Meta) -> dict[str, str]:
        _ = meta
        return {}

    async def get_additional_data(self, meta: Meta) -> dict[str, str]:
        audio_flag = self.get_audio(meta)
        subtitle_flag = self.get_subtitles(meta)

        data: dict[str, str] = {
            "audio_pt": str(audio_flag),
            "legenda_pt": str(subtitle_flag),
        }

        return data
