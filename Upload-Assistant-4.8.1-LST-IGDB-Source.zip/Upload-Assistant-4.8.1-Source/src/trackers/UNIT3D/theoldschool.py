# Upload Assistant © 2025 Audionut & wastaken7 — Licensed under UAPL v1.0
import asyncio
from typing import Any

from src.console import logger
from src.meta import Meta
from src.torrentcreate import TorrentCreator
from src.trackers.common import Common
from src.trackers.UNIT3D import UNIT3D


class TheOldSchool(UNIT3D):
    """
    The Old School (TOS) is a FRENCH Private Torrent Tracker for MOVIES / TV / GENERAL
    """

    tracker = "THEOLDSCHOOL"
    display_name = "The Old School"
    source_flag = "TheOldSchool"
    base_url = "https://theoldschool.cc"
    banned_groups = (
        "FL3ER",
        "SUNS3T",
        "WoLFHD",
        "EXTREME",
        "Slay3R",
        "3T3AM",
        "BARBiE",
    )
    id_url = f"{base_url}/api/torrents/"
    upload_url = f"{base_url}/api/torrents/upload"
    search_url = f"{base_url}/api/torrents/filter"
    torrent_url = f"{base_url}/torrents/"
    supported_categories = ("TV", "MOVIE")
    tracker_urls = ("https://theoldschool.cc",)
    allows_bloated_audio = True

    def __init__(self, config: dict[str, Any]):
        super().__init__(config, tracker_name="THEOLDSCHOOL")
        self.config = config
        self.common = Common(config)

    async def get_category_id(
        self,
        meta: Meta,
        category: str | None = None,
        reverse: bool = False,
        mapping_only: bool = False,
    ) -> dict[str, str]:
        _ = (category, reverse, mapping_only)
        tags_lower = meta.tag.lower() if meta.tag else ""
        if "vostfr" in tags_lower or "subfrench" in tags_lower:
            category_id = "9" if meta.category == "TV" and meta.tv_pack else {"MOVIE": "6", "TV": "7"}.get(meta.category, "0")
        else:
            category_id = "8" if meta.category == "TV" and meta.tv_pack else {"MOVIE": "1", "TV": "2"}.get(meta.category, "0")
        return {"category_id": category_id}

    async def get_type_id(
        self,
        meta: Meta,
        type: str | None = None,
        reverse: bool = False,
        mapping_only: bool = False,
    ) -> dict[str, str]:
        _ = (type, reverse, mapping_only)
        if meta.is_disc == "DVD":
            type_id = "7"
        elif meta.three_d == "3D":
            type_id = "8"
        else:
            type_id = {
                "DISC": "1",
                "REMUX": "2",
                "ENCODE": "3",
                "WEBDL": "4",
                "WEBRIP": "5",
                "HDTV": "6",
            }.get(meta.type or "", "0")
        return {"type_id": type_id}

    async def get_name(self, meta: Meta) -> dict[str, str]:
        is_scene = meta.scene
        base_name: str = meta.scene_name if is_scene else meta.basename_no_ext

        if is_scene is False:
            replacements = {
                ".mkv": "",
                ".mp4": "",
                ".torrent": "",
                " ": ".",
            }

            for old, new in replacements.items():
                base_name = base_name.replace(old, new)

        # Hook into this function for torrent file recreation if needed
        if meta.keep_nfo:
            tracker_config = self.config["TRACKERS"].get(self.tracker, {})
            tracker_url = str(tracker_config.get("announce_url", "https://fake.tracker")).strip()
            torrent_create = f"[{self.tracker}]"
            try:
                cooldown = int(self.config.get("DEFAULT", {}).get("rehash_cooldown", 0) or 0)
            except ValueError, TypeError:
                cooldown = 0
            if cooldown > 0:
                await asyncio.sleep(cooldown)  # Small cooldown before rehashing

            await TorrentCreator.create_torrent(meta, str(meta.path), torrent_create, tracker_url=tracker_url)

        return {"name": base_name}

    async def get_additional_checks(self, meta: Meta) -> bool:
        # Check language requirements: must be French audio OR original audio with French subtitles
        french_languages = ["french", "fre", "fra", "fr", "français", "francais"]
        if not await self.common.check_language_requirements(
            meta,
            self.tracker,
            languages_to_check=french_languages,
            check_audio=True,
            check_subtitle=True,
            require_both=False,
            original_language=True,
        ):
            logger.info(f"{self.tracker}: [bold red]Language requirements not met for {self.tracker}.[/bold red]")
            return False

        # Check if it's a Scene release without NFO - TheOldSchool requires NFO for Scene releases
        is_scene = meta.scene
        has_nfo = meta.nfo or meta.auto_nfo

        if is_scene and not has_nfo:
            logger.info(f"{self.tracker}: [red]Scene release detected but no NFO file found. {self.tracker} requires NFO files for Scene releases.[/red]")
            return False
        return True
