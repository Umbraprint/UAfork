# Upload Assistant © 2025 Audionut & wastaken7 — Licensed under UAPL v1.0
from typing import Any, cast

import pycountry

from src.console import logger
from src.languages import languages_manager
from src.meta import Meta
from src.trackers.common import Common
from src.trackers.naming import TmdbTvNaming
from src.trackers.UNIT3D import UNIT3D

Config = dict[str, Any]


class InfinityHD(TmdbTvNaming, UNIT3D):
    """
    INFINITYHD is a Private Torrent Tracker for MOVIES / TV / ANIME
    """

    tracker = "INFINITYHD"
    display_name = "InfinityHD"
    allows_bloated_audio = True
    base_url = "https://infinityhd.net"
    banned_groups = (
        "1000",
        "24xHD",
        "41RGB",
        "4K4U",
        "AG",
        "AOC",
        "AROMA",
        "aXXo",
        "AZAZE",
        "BARC0DE",
        "BAUCKLEY",
        "BdC",
        "beAst",
        "BONE",
        "BRiNK",
        "BRrip",
        "BTM",
        "C1NEM4",
        "C4K",
        "CDDHD",
        "CHAOS",
        "CHD",
        "CHX",
        "CiNE",
        "COLLECTiVE",
        "CREATiVE24",
        "CrEwSaDe",
        "CTFOH",
        "d3g",
        "DDR",
        "DepraveD",
        "DNL",
        "DRX",
        "EDITH",
        "EPiC",
        "EuReKA",
        "EVO",
        "FaNGDiNG0",
        "Feranki1980",
        "FGT",
        "FiSTER",
        "FMD",
        "FRDS",
        "FZHD",
        "GalaxyRG",
        "GalaxyTV",
        "GHD",
        "GHOSTS",
        "GPTHD",
        "GRACE",
        "HDHUB4U",
        "HDS",
        "HDT",
        "HDTime",
        "HDWinG",
        "HiQVE",
        "iHYTECH",
        "in",
        "iNTENSO",
        "ION10",
        "iPlanet",
        "iVy",
        "jennaortegaUHD",
        "JFF",
        "KC",
        "KiNGDOM",
        "KIRA",
        "L0SERNIGHT",
        "LAMA",
        "Leffe",
        "Liber8",
        "LiGaS",
        "LT",
        "LUCY",
        "MarkII",
        "MeGusta",
        "Mesc",
        "mHD",
        "mSD",
        "MT",
        "MTeam",
        "MySiLU",
        "NaNi",
        "nhanc3",
        "NhaNc3",
        "nHD",
        "nikt0",
        "nSD",
        "OFT",
        "Paheph",
        "PATOMiEL",
        "POKE",
        "PRODJi",
        "PSA",
        "PTNK",
        "RARBG",
        "RDN",
        "Rifftrax",
        "RU4HD",
        "SANTi",
        "SasukeducK",
        "Scene",
        "SHD",
        "ShieldBearer",
        "SM737",
        "STUTTERSHIT",
        "SUNSCREEN",
        "TBS",
        "TEKNO3D",
        "TG",
        "TGx",
        "Tigole",
        "TIKO",
        "TORRENTGALAXY",
        "UNiON",
        "VIDEOHOLE",
        "VISIONPLUSHDR-X",
        "VXT",
        "WAF",
        "WiKi",
        "WKS",
        "worldmkv",
        "x0r",
        "XLF",
        "YIFY",
        "YTSMX",
        "Zero00",
        "Zeus",
    )
    banned_url = f"{base_url}/api/banned-groups"
    id_url = f"{base_url}/api/torrents/"
    upload_url = f"{base_url}/api/torrents/upload"
    search_url = f"{base_url}/api/torrents/filter"
    requests_url = f"{base_url}/api/requests/filter"
    torrent_url = f"{base_url}/torrents/"
    supported_categories = ("TV", "MOVIE")
    tracker_urls = ("https://infinityhd.net",)

    def __init__(self, config: Config) -> None:
        super().__init__(config, tracker_name="INFINITYHD")
        self.config: Config = config
        self.common = Common(config)

    async def get_category_id(self, meta: Meta, category: str | None = None, reverse: bool = False, mapping_only: bool = False) -> dict[str, str]:
        category_name = meta.category
        anime = meta.anime
        category_id = {
            "MOVIE": "1",
            "TV": "2",
            "ANIME": "3",
            "ANIME MOVIE": "4",
        }

        is_anime_movie = False
        is_anime = False

        if category_name == "MOVIE" and anime is True:
            is_anime_movie = True

        if category_name == "TV" and anime is True:
            is_anime = True

        if is_anime:
            return {"category_id": "3"}
        if is_anime_movie:
            return {"category_id": "4"}

        if mapping_only:
            return category_id
        if reverse:
            return {v: k for k, v in category_id.items()}
        if category is not None:
            return {"category_id": category_id.get(category, "0")}
        meta_category = meta.category
        resolved_id = category_id.get(meta_category, "0")
        return {"category_id": resolved_id}

    async def get_resolution_id(self, meta: Meta, resolution: str | None = None, reverse: bool = False, mapping_only: bool = False) -> dict[str, str]:
        resolution_id = {"4320p": "1", "2160p": "2", "1440p": "3", "1080p": "3", "1080i": "4"}
        if mapping_only:
            return resolution_id
        if reverse:
            return {v: k for k, v in resolution_id.items()}
        if resolution is not None:
            return {"resolution_id": resolution_id.get(resolution, "10")}
        meta_resolution = meta.resolution
        resolved_id = resolution_id.get(meta_resolution, "10")
        return {"resolution_id": resolved_id}

    def _get_language_code(self, track_or_string: Any) -> str:
        """Extract and normalize language to ISO alpha-2 code"""
        if isinstance(track_or_string, dict):
            track_map = cast(dict[str, Any], track_or_string)
            lang_value = track_map.get("Language", "")
            if isinstance(lang_value, dict):
                lang_map = cast(dict[str, Any], lang_value)
                lang = str(lang_map.get("String", ""))
            else:
                lang = str(lang_value)
        else:
            lang = str(track_or_string)
        if not lang:
            return ""
        lang_str = lang.lower()

        # Strip country code if present (e.g., "en-US" → "en")
        if "-" in lang_str:
            lang_str = lang_str.split("-")[0]

        if len(lang_str) == 2:
            return lang_str
        try:
            lang_obj = pycountry.languages.get(name=lang_str.title()) or pycountry.languages.get(alpha_2=lang_str) or pycountry.languages.get(alpha_3=lang_str)
            return lang_obj.alpha_2.lower() if lang_obj else lang_str
        except AttributeError, KeyError, LookupError:
            return lang_str

    def original_language_check(self, meta: Meta) -> bool:
        if "mediainfo" not in meta:
            return False

        # TMDB stores original_language as a single ISO string; iterating it would yield characters.
        raw_original = meta.original_language
        raw_list: list[Any] = [raw_original] if isinstance(raw_original, str) else list(raw_original or [])
        original_languages = {self._get_language_code(lang) for lang in raw_list if isinstance(lang, str) and lang.strip()}
        if not original_languages:
            return False

        tracks_value = meta.mediainfo.get("media", {}).get("track", [])
        tracks_list = cast(list[Any], tracks_value) if isinstance(tracks_value, list) else []
        for track in tracks_list:
            if not isinstance(track, dict):
                continue
            track_map = cast(dict[str, Any], track)
            if track_map.get("@type") != "Audio":
                continue
            if "commentary" in str(track_map.get("Title", "")).lower():
                continue
            lang_code = self._get_language_code(track_map)
            if lang_code and lang_code.lower() in original_languages:
                return True
        return False

    async def get_name(self, meta: Meta) -> dict[str, str]:
        if meta.manual_name is not None:
            return {"name": meta.manual_name.strip()}

        ihd_name = meta.name
        resolution = meta.resolution

        if meta.category == "TV":
            ihd_name = await self._rebuild_tv_name(meta, ihd_name) or " ".join(ihd_name.split())

        if not meta.language_checked:
            await languages_manager.process_desc_language(meta, tracker=self.tracker)
        audio_languages_value = meta.audio_languages
        audio_languages: list[str] = []
        if isinstance(audio_languages_value, list):
            audio_languages_list = audio_languages_value
            audio_languages = [str(item) for item in audio_languages_list]
        if audio_languages and not await languages_manager.has_english_language(audio_languages):
            foreign_lang = audio_languages[0].upper()
            ihd_name = ihd_name.replace(resolution, f"{foreign_lang} {resolution}", 1)

        return {"name": ihd_name}

    async def get_additional_checks(self, meta: Meta) -> bool:
        if meta.resolution not in ["4320p", "2160p", "1440p", "1080p", "1080i"]:
            if not meta.unattended or meta.debug:
                logger.info(f"{self.tracker}: [bold red]Uploads must be at least 1080 resolution for {self.tracker}.[/bold red]")
            return False

        if not meta.valid_mi_settings:
            if not meta.unattended or meta.debug:
                logger.info(f"{self.tracker}: [bold red]No encoding settings in mediainfo, skipping {self.tracker} upload.[/bold red]")
            return False

        if meta.is_disc != "BDMV":
            if not meta.language_checked:
                await languages_manager.process_desc_language(meta, tracker=self.tracker)
            original_language = self.original_language_check(meta)
            audio_languages_value = meta.audio_languages
            subtitle_languages_value = meta.subtitle_languages
            audio_languages: list[str] = []
            subtitle_languages: list[str] = []
            if isinstance(audio_languages_value, list):
                audio_languages_list = audio_languages_value
                audio_languages = [str(item) for item in audio_languages_list]
            else:
                audio_languages = []
            if isinstance(subtitle_languages_value, list):
                subtitle_languages_list = subtitle_languages_value
                subtitle_languages = [str(item) for item in subtitle_languages_list]
            else:
                subtitle_languages = []
            has_eng_audio = await languages_manager.has_english_language(audio_languages if audio_languages else "")
            has_eng_subs = await languages_manager.has_english_language(subtitle_languages if subtitle_languages else "")
            # Require at least one English audio/subtitle track or an original language audio track
            if not (original_language or has_eng_audio or has_eng_subs):
                if not meta.unattended or meta.debug:
                    logger.info(f"{self.tracker}: [bold red]requires at least one English audio or subtitle track or an original language audio track.")
                return False

        return self.common.check_and_confirm_adult_media_upload(meta, self.tracker)
