# Upload Assistant © 2025 Audionut & wastaken7 — Licensed under UAPL v1.0
import asyncio
import json
import re
import sys
import unicodedata
from collections.abc import Callable, Mapping
from datetime import UTC, datetime
from difflib import SequenceMatcher
from typing import Any, cast

import anitopy
import cli_ui
import guessit
import httpx

from src import webui_events
from src.cleanup import cleanup_manager
from src.console import logger, prompt_in_thread
from src.metadata_cache import cache_for, is_cache_miss

anitopy_parse_fn: Any = cast(Any, anitopy).parse
guessit_module: Any = cast(Any, guessit)
GuessitFn = Callable[[str, dict[str, Any] | None], dict[str, Any]]
IMDB_GRAPHQL_HEADERS = {"Content-Type": "application/json", "Referer": "https://www.imdb.com/"}


def _normalized_title(value: str) -> str:
    value = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii").lower()
    return " ".join(re.findall(r"[a-z0-9]+", value))


def imdb_match_rejection(category: str, year: int | str | None, titles: list[str], imdb_info: dict[str, Any], tmdb_imdb_id: int = 0) -> str | None:
    """Explain why an automatically found IMDb title cannot identify this work."""
    title_type = re.sub(r"[^a-z]", "", str(imdb_info.get("type") or "").lower())
    valid_types = {
        "MOVIE": {"movie", "short", "shortfilm", "featurefilm", "tvmovie", "video", "tvspecial", "tvshort"},
        "TV": {"tvseries", "tvminiseries", "tvshow"},
    }
    if category in valid_types and title_type not in valid_types[category]:
        return f"incompatible or missing IMDb type: {imdb_info.get('type') or 'unknown'}"

    try:
        imdb_year = int(imdb_info.get("year") or 0)
        expected_year = int(year or 0)
    except TypeError, ValueError:
        imdb_year = expected_year = 0
    if not imdb_year or not expected_year or abs(imdb_year - expected_year) > 2:
        return f"IMDb year {imdb_year or 'unknown'} does not match {expected_year or 'unknown'}"

    imdb_id = str(imdb_info.get("imdbID") or imdb_info.get("id") or "").removeprefix("tt")
    if tmdb_imdb_id and imdb_id.isdigit() and int(imdb_id) == tmdb_imdb_id:
        return None

    imdb_titles = [imdb_info.get("title"), imdb_info.get("aka")]
    imdb_titles.extend(aka.get("title") for aka in imdb_info.get("akas", []) if isinstance(aka, dict))
    normalized_expected = [_normalized_title(title) for title in titles if isinstance(title, str) and title.strip()]
    normalized_imdb = [_normalized_title(title) for title in imdb_titles if isinstance(title, str) and title.strip()]
    if (
        not normalized_expected
        or not normalized_imdb
        or not any(SequenceMatcher(None, expected, candidate).ratio() >= 0.8 for expected in normalized_expected for candidate in normalized_imdb)
    ):
        return "IMDb title does not match the release or TMDb titles"
    return None


def guessit_fn(value: str, options: dict[str, Any] | None = None) -> dict[str, Any]:
    return cast(dict[str, Any], guessit_module.guessit(value, options))


class ImdbManager:
    def safe_get(self, data: Any, path: list[str], default: Any = None) -> Any:
        for key in path:
            if isinstance(data, dict):
                data_dict = cast(Mapping[str, Any], data)
                data = data_dict.get(key, default)
            else:
                return default
        return data

    async def get_imdb_info_api(
        self,
        imdb_id: int | str | None,
        manual_language: str | dict[str, Any] | None = None,
        base_dir: str = "",
        config: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        imdb_info: dict[str, Any] = {}

        if not imdb_id or imdb_id == 0:
            imdb_info["type"] = None
            return imdb_info

        try:
            imdb_id_str = f"tt{imdb_id:07d}" if not str(imdb_id).startswith("tt") else str(imdb_id)
        except Exception as e:
            logger.error(f"[red]Error:[/red] {e}")
            return imdb_info

        cache = cache_for(base_dir, config)
        cache_key = f"{imdb_id_str}|{manual_language!s}"
        cached_info = await cache.get("imdb", "title", cache_key)
        if not is_cache_miss(cached_info) and isinstance(cached_info, dict):
            return cached_info

        query = {
            "query": f"""
            query GetTitleInfo {{
                title(id: "{imdb_id_str}") {{
                id
                titleText {{
                    text
                    isOriginalTitle
                    country {{
                        text
                    }}
                }}
                originalTitleText {{
                    text
                }}
                releaseYear {{
                    year
                    endYear
                }}
                titleType {{
                    id
                }}
                plot {{
                    plotText {{
                    plainText
                    }}
                }}
                ratingsSummary {{
                    aggregateRating
                    voteCount
                }}
                primaryImage {{
                    url
                }}
                runtime {{
                    displayableProperty {{
                    value {{
                        plainText
                    }}
                    }}
                    seconds
                }}
                titleGenres {{
                    genres {{
                    genre {{
                        text
                    }}
                    }}
                }}
                principalCredits {{
                    category {{
                    text
                    id
                    }}
                    credits {{
                    name {{
                        id
                        nameText {{
                        text
                        }}
                    }}
                    }}
                }}
                episodes {{
                    episodes(first: 500) {{
                        edges {{
                            node {{
                                id
                                series {{
                                    displayableEpisodeNumber {{
                                        displayableSeason {{
                                            season
                                        }}
                                        episodeNumber {{
                                            text
                                        }}
                                    }}
                                }}
                                titleText {{
                                    text
                                }}
                                releaseYear {{
                                    year
                                }}
                                releaseDate {{
                                    year
                                    month
                                    day
                                }}
                            }}
                        }}
                        pageInfo {{
                            hasNextPage
                            hasPreviousPage
                        }}
                        total
                    }}
                }}
                runtimes(first: 10) {{
                    edges {{
                        node {{
                            id
                            seconds
                            displayableProperty {{
                                value {{
                                    plainText
                                }}
                            }}
                            attributes {{
                                text
                            }}
                        }}
                    }}
                }}
                technicalSpecifications {{
                    aspectRatios {{
                        items {{
                            aspectRatio
                            attributes {{
                                text
                            }}
                        }}
                    }}
                    cameras {{
                        items {{
                            camera
                            attributes {{
                                text
                            }}
                        }}
                    }}
                    colorations {{
                        items {{
                            text
                            attributes {{
                                text
                            }}
                        }}
                    }}
                    laboratories {{
                        items {{
                            laboratory
                            attributes {{
                                text
                            }}
                        }}
                    }}
                    negativeFormats {{
                        items {{
                            negativeFormat
                            attributes {{
                                text
                            }}
                        }}
                    }}
                    printedFormats {{
                        items {{
                            printedFormat
                            attributes {{
                                text
                            }}
                        }}
                    }}
                    processes {{
                        items {{
                            process
                            attributes {{
                                text
                            }}
                        }}
                    }}
                    soundMixes {{
                        items {{
                            text
                            attributes {{
                                text
                            }}
                        }}
                    }}
                    filmLengths {{
                        items {{
                            filmLength
                            countries {{
                                text
                            }}
                            numReels
                        }}
                    }}
                }}
                akas(first: 100) {{
                edges {{
                    node {{
                    text
                    country {{
                        text
                    }}
                    language {{
                        text
                    }}
                    attributes {{
                        text
                    }}
                    }}
                }}
                }}
                countriesOfOrigin {{
                    countries {{
                        text
                        }}
                    }}
                }}
            }}
            """
        }

        async with httpx.AsyncClient() as client:
            try:
                response = await client.post(
                    "https://api.graphql.imdb.com/",
                    json=query,
                    headers=IMDB_GRAPHQL_HEADERS,
                    timeout=10,
                )
                response.raise_for_status()
                data = cast(dict[str, Any], response.json())
            except httpx.HTTPStatusError as e:
                logger.info(f"[red]IMDb API error: {e.response.status_code}[/red]")
                return imdb_info
            except httpx.RequestError as e:
                logger.info(f"[red]IMDb API Network error: {e}[/red]")
                return imdb_info

        title_data = self.safe_get(data, ["data", "title"], {})
        if not title_data:
            if not data.get("errors"):
                await cache.set("imdb", "title", cache_key, imdb_info, negative=True)
            return imdb_info  # Return empty if no data found

        imdb_info["imdbID"] = imdb_id_str
        imdb_info["imdb_url"] = f"https://www.imdb.com/title/{imdb_id_str}"
        imdb_info["title"] = self.safe_get(title_data, ["titleText", "text"])
        countries_list = cast(list[Mapping[str, Any]], self.safe_get(title_data, ["countriesOfOrigin", "countries"], []))
        if countries_list:
            # First country for 'country'
            imdb_info["country"] = countries_list[0].get("text", "")
            # All countries joined for 'country_list'
            imdb_info["country_list"] = ", ".join([c.get("text", "") for c in countries_list if isinstance(c, dict) and "text" in c])
        else:
            imdb_info["country"] = ""
            imdb_info["country_list"] = ""
        imdb_info["year"] = self.safe_get(title_data, ["releaseYear", "year"])
        imdb_info["end_year"] = self.safe_get(title_data, ["releaseYear", "endYear"])
        original_title = self.safe_get(title_data, ["originalTitleText", "text"], "")
        imdb_info["aka"] = original_title if original_title and original_title != imdb_info["title"] else imdb_info["title"]
        imdb_info["type"] = self.safe_get(title_data, ["titleType", "id"], None)
        runtime_seconds = self.safe_get(title_data, ["runtime", "seconds"], 0)
        imdb_info["runtime"] = str(runtime_seconds // 60 if runtime_seconds else 60)
        imdb_info["cover"] = self.safe_get(title_data, ["primaryImage", "url"])
        imdb_info["plot"] = self.safe_get(title_data, ["plot", "plotText", "plainText"], "No plot available")

        genres = cast(list[Mapping[str, Any]], self.safe_get(title_data, ["titleGenres", "genres"], []))
        genre_list = [self.safe_get(g, ["genre", "text"], "") for g in genres]
        imdb_info["genres"] = ", ".join(filter(None, genre_list))

        imdb_info["rating"] = self.safe_get(title_data, ["ratingsSummary", "aggregateRating"], "N/A")
        imdb_info["votes"] = self.safe_get(title_data, ["ratingsSummary", "voteCount"], 0)

        def get_credits(title_data: dict[str, Any], category_keyword: str) -> tuple[list[str], list[str]]:
            people_list: list[str] = []
            people_id_list: list[str] = []
            principal_credits = cast(list[Mapping[str, Any]], self.safe_get(title_data, ["principalCredits"], []))

            for pc in principal_credits:
                category_text = self.safe_get(pc, ["category", "text"], "")

                if category_keyword in category_text:
                    credits = cast(list[Mapping[str, Any]], self.safe_get(pc, ["credits"], []))
                    for c in credits:
                        name_obj = self.safe_get(c, ["name"], {})
                        person_id = self.safe_get(name_obj, ["id"], "")
                        person_name = self.safe_get(name_obj, ["nameText", "text"], "")

                        if person_id and person_name:
                            people_list.append(person_name)
                            people_id_list.append(person_id)
                    break

            return people_list, people_id_list

        imdb_info["directors"], imdb_info["directors_id"] = get_credits(title_data, "Direct")
        imdb_info["creators"], imdb_info["creators_id"] = get_credits(title_data, "Creat")
        imdb_info["writers"], imdb_info["writers_id"] = get_credits(title_data, "Writ")
        imdb_info["stars"], imdb_info["stars_id"] = get_credits(title_data, "Star")

        editions = cast(list[Mapping[str, Any]], self.safe_get(title_data, ["runtimes", "edges"], []))
        if editions:
            edition_list: list[str] = []
            imdb_info["edition_details"] = {}

            for edge in editions:
                node = self.safe_get(edge, ["node"], {})
                seconds = self.safe_get(node, ["seconds"], 0)
                minutes = seconds // 60 if seconds else 0
                displayable_property = self.safe_get(node, ["displayableProperty", "value", "plainText"], "")
                attributes = cast(list[Mapping[str, Any]], self.safe_get(node, ["attributes"], []))
                attribute_texts: list[str] = []
                for attr in attributes:
                    text = attr.get("text")
                    if isinstance(text, str) and text:
                        attribute_texts.append(text)

                edition_display = f"{displayable_property} ({minutes} min)"
                if attribute_texts:
                    edition_display += f" [{', '.join(attribute_texts)}]"

                if seconds and displayable_property:
                    edition_list.append(edition_display)

                    runtime_key = str(minutes)
                    imdb_info["edition_details"][runtime_key] = {"display_name": displayable_property, "seconds": seconds, "minutes": minutes, "attributes": attribute_texts}

            imdb_info["edition_count"] = len(edition_list)
            imdb_info["editions"] = ", ".join(edition_list)

        akas_edges = cast(list[Mapping[str, Any]], self.safe_get(title_data, ["akas", "edges"], default=[]))
        imdb_info["akas"] = [
            {
                "title": self.safe_get(edge, ["node", "text"]),
                "country": self.safe_get(edge, ["node", "country", "text"]),
                "language": self.safe_get(edge, ["node", "language", "text"]),
                "attributes": self.safe_get(edge, ["node", "attributes"], []),
            }
            for edge in akas_edges
        ]

        if manual_language:
            imdb_info["original_language"] = manual_language

        episodes_list: list[dict[str, Any]] = []
        imdb_info["episodes"] = episodes_list
        episodes_data = self.safe_get(title_data, ["episodes", "episodes"], None)
        if episodes_data:
            edges = cast(list[Mapping[str, Any]], self.safe_get(episodes_data, ["edges"], []))
            for edge in edges:
                node = self.safe_get(edge, ["node"], {})

                series_info = self.safe_get(node, ["series", "displayableEpisodeNumber"], {})
                season_info = self.safe_get(series_info, ["displayableSeason"], {})
                episode_number_info = self.safe_get(series_info, ["episodeNumber"], {})

                episode_info = {
                    "id": self.safe_get(node, ["id"], ""),
                    "title": self.safe_get(node, ["titleText", "text"], "Unknown Title"),
                    "release_year": self.safe_get(node, ["releaseYear", "year"], "Unknown Year"),
                    "release_date": {
                        "year": self.safe_get(node, ["releaseDate", "year"], None),
                        "month": self.safe_get(node, ["releaseDate", "month"], None),
                        "day": self.safe_get(node, ["releaseDate", "day"], None),
                    },
                    "season": self.safe_get(season_info, ["season"], "unknown"),
                    "episode_number": self.safe_get(episode_number_info, ["text"], ""),
                }
                episodes_list.append(episode_info)

        if imdb_info["episodes"]:
            seasons_data: dict[int, set[int]] = {}

            episodes = cast(list[dict[str, Any]], imdb_info.get("episodes", []))
            for episode in episodes:
                season_str = episode.get("season", "unknown")
                release_year = episode.get("release_year")

                try:
                    season_int = int(season_str) if season_str != "unknown" and season_str else None
                except ValueError, TypeError:
                    season_int = None

                if season_int is not None and release_year and isinstance(release_year, int):
                    if season_int not in seasons_data:
                        seasons_data[season_int] = set()
                    seasons_data[season_int].add(release_year)

            seasons_summary: list[dict[str, Any]] = []
            for season_num in sorted(seasons_data.keys()):
                years = sorted(seasons_data[season_num])
                season_entry = {"season": season_num, "year": years[0], "year_range": f"{years[0]}" if len(years) == 1 else f"{years[0]}-{years[-1]}"}
                seasons_summary.append(season_entry)

            imdb_info["seasons_summary"] = seasons_summary
        else:
            imdb_info["seasons_summary"] = []

        sound_mixes = cast(list[Mapping[str, Any]], self.safe_get(title_data, ["technicalSpecifications", "soundMixes", "items"], []))
        imdb_info["sound_mixes"] = [sm.get("text", "") for sm in sound_mixes if "text" in sm]

        episodes = cast(list[dict[str, Any]], imdb_info.get("episodes", []))
        current_year = datetime.now(UTC).year
        release_years = [episode["release_year"] for episode in episodes if "release_year" in episode and isinstance(episode["release_year"], int)]
        if imdb_info["end_year"]:
            imdb_info["tv_year"] = imdb_info["end_year"]
        elif release_years:
            closest_year = min(release_years, key=lambda year: abs(year - current_year))
            imdb_info["tv_year"] = closest_year
        else:
            imdb_info["tv_year"] = None

        logger.debug(f"[yellow]IMDb Response: {json.dumps(imdb_info, indent=2)[:1000]}...[/yellow]")
        await cache.set("imdb", "title", cache_key, imdb_info)
        return imdb_info

    async def search_imdb(
        self,
        filename: str,
        search_year: str | int | None,
        quickie: bool = False,
        category: str | None = None,
        secondary_title: str | None = None,
        _path: str | None = None,
        untouched_filename: str | None = None,
        attempted: int | None = 0,
        duration: str | int | None = None,
        unattended: bool = False,
        on_manual_selection: Callable[[int], None] | None = None,
    ) -> int:
        search_results: list[dict[str, Any]] = []
        imdb_id_result = imdb_id = 0
        if attempted is None:
            attempted = 0
        logger.debug(f"[yellow]Searching IMDb for {filename} and year {search_year}...[/yellow]")
        if attempted:
            await asyncio.sleep(1)  # Whoa baby, slow down

        async def run_imdb_search(
            filename: str,
            search_year: str | int | None,
            category: str | None = None,
            attempted: int | None = 0,
            duration: str | int | None = None,
            wide_search: bool = False,
        ) -> list[dict[str, Any]]:
            search_results: list[dict[str, Any]] = []
            if secondary_title is not None:
                filename = secondary_title
            if attempted is None:
                attempted = 0
            if attempted:
                await asyncio.sleep(1)  # Whoa baby, slow down
            url = "https://api.graphql.imdb.com/"
            if category == "MOVIE":
                filename = filename.replace("and", "&").replace("And", "&").replace("AND", "&").strip()

            constraints_parts = [f"titleTextConstraint: {{searchTerm: {json.dumps(filename)}}}"]

            # Add release date constraint if search_year is provided
            if not wide_search and search_year:
                search_year_int = int(search_year)
                start_year = search_year_int - 1
                end_year = search_year_int + 1
                constraints_parts.append(f'releaseDateConstraint: {{releaseDateRange: {{start: "{start_year}-01-01", end: "{end_year}-12-31"}}}}')

            if not wide_search and duration and isinstance(duration, int):
                duration = str(duration)
                start_duration = int(duration) - 10
                end_duration = int(duration) + 10
                constraints_parts.append(f"runtimeConstraint: {{runtimeRangeMinutes: {{min: {start_duration}, max: {end_duration}}}}}")

            constraints_string = ", ".join(constraints_parts)

            query = {
                "query": f"""
                    {{
                        advancedTitleSearch(
                            first: 10,
                            constraints: {{{constraints_string}}}
                        ) {{
                            total
                            edges {{
                                node {{
                                    title {{
                                        id
                                        titleText {{
                                            text
                                        }}
                                        titleType {{
                                            text
                                        }}
                                        releaseYear {{
                                            year
                                        }}
                                        plot {{
                                            plotText {{
                                            plainText
                                            }}
                                        }}
                                        primaryImage {{
                                            url
                                        }}
                                    }}
                                }}
                            }}
                        }}
                    }}
                """
            }

            try:
                async with httpx.AsyncClient() as client:
                    response = await client.post(url, json=query, headers=IMDB_GRAPHQL_HEADERS, timeout=10)
                    response.raise_for_status()
                    data = response.json()
            except Exception as e:
                logger.info(f"[red]IMDb GraphQL API error: {e}[/red]")
                return []

            results = cast(list[dict[str, Any]], self.safe_get(data, ["data", "advancedTitleSearch", "edges"], []))
            search_results = results

            logger.debug(f"[yellow]Found {len(results)} results...[/yellow]")
            logger.debug(f"quickie: {quickie}, category: {category}, search_year: {search_year}")
            return search_results

        if not search_results:
            result = await run_imdb_search(filename, search_year, category, attempted, duration, wide_search=False)
            if result and len(result) > 0:
                search_results = result

        if not search_results and secondary_title:
            logger.debug(f"[yellow]Trying IMDb with secondary title: {secondary_title}[/yellow]")
            result = await run_imdb_search(secondary_title, search_year, category, attempted, duration, wide_search=True)
            if result and len(result) > 0:
                search_results = result

        # remove 'the' from the beginning of the title if it exists
        if not search_results:
            try:
                words = filename.split()
                bad_words = ["the"]
                words_lower = [word.lower() for word in words]

                if words_lower and words_lower[0] in bad_words:
                    words.pop(0)
                    words_lower.pop(0)
                    title = " ".join(words)
                    logger.debug(f"[bold yellow]Trying IMDb with the prefix removed: {title}[/bold yellow]")
                    result = await run_imdb_search(title, search_year, category, attempted + 1, wide_search=False)
                    if result and len(result) > 0:
                        search_results = result
            except Exception as e:
                logger.info(f"[bold red]Reduced name search error:[/bold red] {e}")
                search_results = []

        # relax the constraints
        if not search_results:
            logger.debug("[yellow]No results found, trying with a wider search...[/yellow]")
            try:
                result = await run_imdb_search(filename, search_year, category, attempted + 1, wide_search=True)
                if result and len(result) > 0:
                    search_results = result
            except Exception as e:
                logger.error(f"[red]Error during wide search: {e}[/red]")

        # Try parsed title (anitopy + guessit)
        if not search_results:
            try:
                parsed = guessit_fn(untouched_filename or "", {"excludes": ["country", "language"]})
                parsed_title_data = cast(dict[str, Any], anitopy_parse_fn(parsed.get("title", "")) or {})
                parsed_title = str(parsed_title_data.get("anime_title", ""))
                logger.debug(f"[bold yellow]Trying IMDB with parsed title: {parsed_title}[/bold yellow]")
                result = await run_imdb_search(parsed_title, search_year, category, attempted + 1, wide_search=True)
                if result and len(result) > 0:
                    search_results = result
            except Exception:
                logger.info("[bold red]Guessit failed parsing title, trying another method[/bold red]")

        # Try with less words in the title
        if not search_results:
            try:
                words = filename.split()
                extensions = ["mp4", "mkv", "avi", "webm", "mov", "wmv"]
                words_lower = [word.lower() for word in words]

                for ext in extensions:
                    if ext in words_lower:
                        ext_index = words_lower.index(ext)
                        words.pop(ext_index)
                        words_lower.pop(ext_index)
                        break

                if len(words) > 1:
                    reduced_title = " ".join(words[:-1])
                    logger.debug(f"[bold yellow]Trying IMDB with reduced name: {reduced_title}[/bold yellow]")
                    result = await run_imdb_search(reduced_title, search_year, category, attempted + 1, wide_search=True)
                    if result and len(result) > 0:
                        search_results = result
            except Exception as e:
                logger.info(f"[bold red]Reduced name search error:[/bold red] {e}")

        # Try with even fewer words
        if not search_results:
            try:
                words = filename.split()
                extensions = ["mp4", "mkv", "avi", "webm", "mov", "wmv"]
                words_lower = [word.lower() for word in words]

                for ext in extensions:
                    if ext in words_lower:
                        ext_index = words_lower.index(ext)
                        words.pop(ext_index)
                        words_lower.pop(ext_index)
                        break

                if len(words) > 2:
                    further_reduced_title = " ".join(words[:-2])
                    logger.debug(f"[bold yellow]Trying IMDB with further reduced name: {further_reduced_title}[/bold yellow]")
                    result = await run_imdb_search(further_reduced_title, search_year, category, attempted + 1, wide_search=True)
                    if result and len(result) > 0:
                        search_results = result
            except Exception as e:
                logger.info(f"[bold red]Further reduced name search error:[/bold red] {e}")

        if quickie:
            for result in search_results:
                title = self.safe_get(result, ["node", "title"], {})
                imdb_id = title.get("id", "")
                candidate = {
                    "id": imdb_id,
                    "title": self.safe_get(title, ["titleText", "text"], ""),
                    "type": self.safe_get(title, ["titleType", "text"], ""),
                    "year": self.safe_get(title, ["releaseYear", "year"], None),
                }
                reason = imdb_match_rejection(category or "", search_year, [filename, secondary_title or ""], candidate)
                if reason:
                    logger.debug(f"[yellow]Skipping IMDb candidate {imdb_id}: {reason}[/yellow]")
                    continue
                if imdb_id and str(imdb_id).removeprefix("tt").isdigit():
                    return int(str(imdb_id).removeprefix("tt"))
            return 0

        if len(search_results) == 1:
            title = self.safe_get(search_results[0], ["node", "title"], {})
            candidate = {
                "id": title.get("id", ""),
                "title": self.safe_get(title, ["titleText", "text"], ""),
                "type": self.safe_get(title, ["titleType", "text"], ""),
                "year": self.safe_get(title, ["releaseYear", "year"], None),
            }
            reason = imdb_match_rejection(category or "", search_year, [filename, secondary_title or ""], candidate)
            if reason:
                logger.info(f"[yellow]IMDb candidate {candidate['id']} requires review: {reason}[/yellow]")
                if unattended:
                    return 0
            elif candidate["id"]:
                return int(str(candidate["id"]).removeprefix("tt"))
        if search_results:
            # Calculate similarity for all results
            results_with_similarity: list[tuple[dict[str, Any], float]] = []
            filename_norm = filename.lower().strip()
            search_year_int = int(search_year) if search_year else 0

            for r in search_results:
                node = self.safe_get(r, ["node"], {})
                title = self.safe_get(node, ["title"], {})
                title_text = self.safe_get(title, ["titleText", "text"], "")
                result_year = self.safe_get(title, ["releaseYear", "year"], 0)

                similarity = SequenceMatcher(None, filename_norm, title_text.lower().strip()).ratio()

                # Only boost similarity if titles are very similar (>= 0.99) AND years match
                if similarity >= 0.99 and search_year_int > 0 and result_year > 0:
                    if result_year == search_year_int:
                        similarity += 0.1  # Full boost for exact year match
                    elif result_year == search_year_int - 1:
                        similarity += 0.05  # Half boost for -1 year

                results_with_similarity.append((r, similarity))

            valid_results = []
            for result, similarity in results_with_similarity:
                title = self.safe_get(result, ["node", "title"], {})
                candidate = {
                    "id": title.get("id", ""),
                    "title": self.safe_get(title, ["titleText", "text"], ""),
                    "type": self.safe_get(title, ["titleType", "text"], ""),
                    "year": self.safe_get(title, ["releaseYear", "year"], None),
                }
                if not imdb_match_rejection(category or "", search_year, [filename, secondary_title or ""], candidate):
                    valid_results.append((result, similarity))

            # Sort by similarity (highest first)
            results_with_similarity.sort(key=lambda x: x[1], reverse=True)

            # Filter results: if we have high similarity matches (>= 0.90), hide low similarity ones (< 0.75)
            best_similarity = results_with_similarity[0][1]
            if best_similarity >= 0.90:
                filtered_results_with_similarity: list[tuple[dict[str, Any], float]] = [(result, sim) for result, sim in results_with_similarity if sim >= 0.75]
                results_with_similarity = filtered_results_with_similarity

                logger.debug(f"[yellow]Filtered out low similarity results (< 0.70) since best match has {best_similarity:.2f} similarity[/yellow]")

            sorted_results: list[dict[str, Any]] = [r[0] for r in results_with_similarity]

            # Check if the best match is significantly better than others
            best_similarity = results_with_similarity[0][1]
            similarity_threshold = 0.85

            if valid_results and best_similarity >= similarity_threshold and results_with_similarity[0] in valid_results:
                second_best = results_with_similarity[1][1] if len(results_with_similarity) > 1 else 0.0

                if best_similarity - second_best >= 0.10:
                    logger.debug(
                        f"[green]Auto-selecting best match: {self.safe_get(sorted_results[0], ['node', 'title', 'titleText', 'text'], '')} (similarity: {best_similarity:.2f})[/green]"
                    )
                    imdb_id = self.safe_get(sorted_results[0], ["node", "title", "id"], "")
                    if imdb_id:
                        return int(imdb_id.replace("tt", "").strip())

            if unattended:
                valid_results.sort(key=lambda x: x[1], reverse=True)
                imdb_id = self.safe_get(valid_results[0][0], ["node", "title", "id"], "") if valid_results else ""
                if imdb_id:
                    imdb_id_result = int(imdb_id.replace("tt", "").strip())
                    logger.debug(f"[green]Unattended mode: auto-selected IMDb ID {imdb_id_result}[/green]")
                    return imdb_id_result
                logger.info("[yellow]No reliable IMDb candidate found; continuing without IMDb.[/yellow]")
                return 0

            # Show sorted results to user
            logger.info("[bold yellow]Multiple IMDb results found. Please select the correct entry:[/bold yellow]")

            labels: list[str] = []
            posters: list[str] = []
            details: list[dict[str, str]] = []
            for idx, candidate in enumerate(sorted_results):
                node = self.safe_get(candidate, ["node"], {})
                title = self.safe_get(node, ["title"], {})
                title_text = self.safe_get(title, ["titleText", "text"], "")
                year = self.safe_get(title, ["releaseYear", "year"], None)
                imdb_id = self.safe_get(title, ["id"], "")
                title_type = self.safe_get(title, ["titleType", "text"], "")
                plot = self.safe_get(title, ["plot", "plotText", "plainText"], "")
                similarity_score = results_with_similarity[idx][1]

                logger.info(
                    f"[cyan]{idx + 1}.[/cyan] [bold]{title_text}[/bold] ({year}) [yellow]ID:[/yellow] {imdb_id} [yellow]Type:[/yellow] {title_type} [dim](similarity: {similarity_score:.2f})[/dim]"
                )
                if plot:
                    logger.info(f"[green]Plot:[/green] {plot[:200]}{'...' if len(plot) > 200 else ''}")
                logger.info("")
                # The GUI's answer buttons: the plot tells similar titles apart.
                labels.append(f"{title_text} ({year})" if year else str(title_text))
                details.append(
                    {
                        "meta": " · ".join(str(part) for part in (imdb_id, title_type, f"similarity {similarity_score:.2f}") if part),
                        "text": plot,
                        "link": f"https://www.imdb.com/title/{imdb_id}/" if imdb_id else "",
                        "link_label": "IMDb",
                    }
                )
                poster = str(self.safe_get(title, ["primaryImage", "url"], "") or "")
                # IMDb serves the full image; this suffix asks its CDN for a small one.
                posters.append(poster.replace("._V1_.jpg", "._V1_UX120_.jpg") if poster.endswith("._V1_.jpg") else poster)

            if sorted_results:
                selection = None
                while True:
                    try:
                        with webui_events.numbered_options(labels, actions=[("0", "None of these")], images=posters, details=details):
                            selection = await prompt_in_thread(cli_ui.ask_string, "Enter the number of the correct entry, 0 for none, or manual IMDb ID (tt1234567): ") or ""
                    except EOFError, KeyboardInterrupt:
                        logger.info("\n[red]Exiting on user request (Ctrl+C)[/red]")
                        await cleanup_manager.cleanup()
                        cleanup_manager.reset_terminal()
                        sys.exit(1)
                    try:
                        # Check if it's a manual IMDb ID entry
                        if selection.lower().startswith("tt") and len(selection) >= 3:
                            try:
                                manual_imdb_id = selection.lower().replace("tt", "").strip()
                                if manual_imdb_id.isdigit():
                                    logger.info(f"[green]Using manual IMDb ID: {selection}[/green]")
                                    selected_id = int(manual_imdb_id)
                                    if on_manual_selection:
                                        on_manual_selection(selected_id)
                                    return selected_id
                                logger.info("[bold red]Invalid IMDb ID format. Please try again.[/bold red]")
                                continue
                            except Exception as e:
                                logger.info(f"[bold red]Error parsing IMDb ID: {e}. Please try again.[/bold red]")
                                continue

                        # Handle numeric selection
                        selection_int = int(selection)
                        if 1 <= selection_int <= len(sorted_results):
                            selected = sorted_results[selection_int - 1]
                            imdb_id = self.safe_get(selected, ["node", "title", "id"], "")
                            if imdb_id:
                                selected_id = int(imdb_id.replace("tt", "").strip())
                                if on_manual_selection:
                                    on_manual_selection(selected_id)
                                return selected_id
                        elif selection_int == 0:
                            logger.info("[bold red]Skipping IMDb[/bold red]")
                            return 0
                        else:
                            logger.info("[bold red]Selection out of range. Please try again.[/bold red]")
                    except ValueError:
                        logger.info("[bold red]Invalid input. Please enter a number or IMDb ID (tt1234567).[/bold red]")

        else:
            if not unattended:
                try:
                    with webui_events.field_prompt(
                        "IMDb ID",
                        {"Search title": filename, "Year": search_year, "Category": category, "IMDb ID": ""},
                        focus="IMDb ID",
                        hint="No IMDb match was found. Enter the ID as tt1234567, or 0 to skip.",
                        actions=[("0", "Skip")],
                        placeholder="tt1234567",
                    ):
                        selection = await prompt_in_thread(cli_ui.ask_string, "No results found. Please enter a manual IMDb ID (tt1234567) or 0 to skip: ") or ""
                except EOFError, KeyboardInterrupt:
                    logger.info("\n[red]Exiting on user request (Ctrl+C)[/red]")
                    await cleanup_manager.cleanup()
                    cleanup_manager.reset_terminal()
                    sys.exit(1)
                if selection.lower().startswith("tt") and len(selection) >= 3:
                    try:
                        manual_imdb_id = selection.lower().replace("tt", "").strip()
                        if manual_imdb_id.isdigit():
                            logger.info(f"[green]Using manual IMDb ID: {selection}[/green]")
                            selected_id = int(manual_imdb_id)
                            if on_manual_selection:
                                on_manual_selection(selected_id)
                            return selected_id
                        logger.info("[bold red]Invalid IMDb ID format. Please try again.[/bold red]")
                    except Exception as e:
                        logger.info(f"[bold red]Error parsing IMDb ID: {e}. Please try again.[/bold red]")
            else:
                logger.info("[bold red]No IMDb results found in unattended mode. Skipping IMDb.[/bold red]")

        return imdb_id_result if imdb_id_result else 0

    async def get_imdb_from_episode(self, imdb_id: int | str) -> dict[str, Any] | None:
        if not imdb_id or imdb_id == 0:
            return None

        if not str(imdb_id).startswith("tt"):
            try:
                imdb_id_int = int(imdb_id)
                imdb_id = f"tt{imdb_id_int:07d}"
            except Exception:
                imdb_id = f"tt{str(imdb_id).zfill(7)}"

        query = {
            "query": f"""
                {{
                    title(id: "{imdb_id}") {{
                        id
                        titleText {{ text }}
                        series {{
                            displayableEpisodeNumber {{
                                displayableSeason {{
                                    id
                                    season
                                    text
                                }}
                                episodeNumber {{
                                    id
                                    text
                                }}
                            }}
                            nextEpisode {{
                                id
                                titleText {{ text }}
                            }}
                            previousEpisode {{
                                id
                                titleText {{ text }}
                            }}
                            series {{
                                id
                                titleText {{ text }}
                            }}
                        }}
                    }}
                }}
            """
        }

        async with httpx.AsyncClient() as client:
            try:
                response = await client.post("https://api.graphql.imdb.com/", json=query, headers=IMDB_GRAPHQL_HEADERS, timeout=10)
                response.raise_for_status()
                data = response.json()
            except Exception as e:
                logger.debug(f"[red]IMDb API error: {e}[/red]")
                return None

        title_data = self.safe_get(data, ["data", "title"], {})
        if not title_data:
            return None
        result: dict[str, Any] = {
            "id": self.safe_get(title_data, ["id"]),
            "title": self.safe_get(title_data, ["titleText", "text"]),
            "series": {},
            "next_episode": {},
            "previous_episode": {},
        }

        series_info = self.safe_get(title_data, ["series"], {})
        if series_info:
            displayable = self.safe_get(series_info, ["displayableEpisodeNumber"], {})
            season_info = self.safe_get(displayable, ["displayableSeason"], {})
            episode_info = self.safe_get(displayable, ["episodeNumber"], {})
            result["series"]["season_id"] = self.safe_get(season_info, ["id"])
            result["series"]["season"] = self.safe_get(season_info, ["season"])
            result["series"]["season_text"] = self.safe_get(season_info, ["text"])
            result["series"]["episode_id"] = self.safe_get(episode_info, ["id"])
            result["series"]["episode_text"] = self.safe_get(episode_info, ["text"])

            # Next episode
            next_ep = self.safe_get(series_info, ["nextEpisode"], {})
            result["next_episode"]["id"] = self.safe_get(next_ep, ["id"])
            result["next_episode"]["title"] = self.safe_get(next_ep, ["titleText", "text"])

            # Previous episode
            prev_ep = self.safe_get(series_info, ["previousEpisode"], {})
            result["previous_episode"]["id"] = self.safe_get(prev_ep, ["id"])
            result["previous_episode"]["title"] = self.safe_get(prev_ep, ["titleText", "text"])

            # Series info
            series_obj = self.safe_get(series_info, ["series"], {})
            result["series"]["series_id"] = self.safe_get(series_obj, ["id"])
            result["series"]["series_title"] = self.safe_get(series_obj, ["titleText", "text"])

        return result


imdb_manager = ImdbManager()
