# Upload Assistant © 2025 Audionut & wastaken7 — Licensed under UAPL v1.0
import asyncio
import sys
import time
import traceback
from collections.abc import Mapping, Sequence
from typing import Any, cast

import cli_ui
from rich.markup import escape

from src import webui_events
from src.artwork import is_valid_cover_image
from src.cleanup import cleanup_manager
from src.cogs.redaction import Redaction
from src.config_helpers import format_terminal_link, parse_bool
from src.console import logger
from src.dupe_checking import DupeChecker
from src.get_desc import DescriptionBuilder
from src.manualpackage import ManualPackageManager
from src.meta import Meta
from src.qbitwait import Wait
from src.rehostimages import check_tracker_image_hosts, has_restricted_image_hosts, select_common_image_host
from src.slot_rules.models import Verdict
from src.slot_rules.registry import evaluate_slots
from src.stats import record_event_async
from src.torrent_provision import provision_tracker_torrents
from src.trackers.GAZELLE.passthepopcorn import PassThePopcorn
from src.trackersetup import TrackerSetup

type StatusDict = dict[str, Any]


async def process_trackers(
    meta: Meta,
    config: dict[str, Any],
    client: Any,
    api_trackers: Sequence[str],
    tracker_class_map: Mapping[str, Any],
    http_trackers: Sequence[str],
    other_api_trackers: Sequence[str],
    upload_target: str = "tracker",
    bandwidth_control: bool | None = None,
) -> None:
    if bandwidth_control is None:
        bandwidth_control = parse_bool(meta.qbit_bandwidth_control) or parse_bool(config["DEFAULT"].get("qbit_bandwidth_control", False))

    tracker_setup = TrackerSetup(config=config)
    tracker_setup_any = cast(Any, tracker_setup)
    enabled_trackers = list(cast(Sequence[str], tracker_setup_any.trackers_enabled(meta)))
    manual_targets = "MANUAL" in enabled_trackers
    torrent_targets = [
        tracker
        for tracker in enabled_trackers
        if tracker not in {"MANUAL", "USENET"} and (manual_targets or bool(cast(Mapping[str, Any], meta.tracker_status.get(tracker, {})).get("upload", False)))
    ]
    await provision_tracker_torrents(meta, config, torrent_targets, tracker_class_map)
    if config.get("DEFAULT", {}).get("smart_image_host_selection", True) and not meta.imghost_from_cli:
        target_trackers = [
            tracker
            for tracker in enabled_trackers
            if tracker != "MANUAL" and (manual_targets or bool(cast(Mapping[str, Any], meta.tracker_status.get(tracker, {})).get("upload", False)))
        ]
        selected_host = select_common_image_host(config["DEFAULT"], target_trackers, tracker_class_map)
        if selected_host:
            current_host = str(meta.imghost or config["DEFAULT"].get("img_host_1", "")).strip().lower()
            meta.imghost = selected_host
            if selected_host != current_host:
                logger.info(f"[green]Smart image-host selection changed the target host: {current_host or 'unset'} -> {selected_host}[/green]")
        elif has_restricted_image_hosts(target_trackers, tracker_class_map):
            logger.info("[yellow]No shared approved image host found; using per-tracker image-host selection.[/yellow]")
    manual_packager = ManualPackageManager(config)
    tracker_label_width = max(
        (len(str(tracker).replace(" ", "").upper().strip()) for tracker in enabled_trackers),
        default=0,
    )

    def publish_tracker_result(tracker: str, tracker_class: Any, status: Mapping[str, Any], is_success: bool) -> None:
        """Send the result to the Web UI's GUI mode, whatever the terminal print settings are."""
        if not webui_events.enabled():
            return
        duration = meta.get(f"{tracker}_upload_duration")
        duration_value = float(duration) if isinstance(duration, (int, float)) else None
        if not is_success:
            webui_events.tracker_result(tracker, "failed", message=status.get("status_message"), duration=duration_value)
            return
        link = status.get("torrent_link")
        if not link and "torrent_id" in status:
            link = f"{getattr(tracker_class, 'torrent_url', '')}{status['torrent_id']}"
        message = str(status.get("status_message", ""))
        webui_events.tracker_result(
            tracker,
            "success",
            link=link,
            torrent_id=status.get("torrent_id"),
            message=message if message and "data error" not in message else None,
            duration=duration_value,
        )

    def print_tracker_result(
        tracker: str,
        tracker_class: Any,
        status: Mapping[str, Any],
        is_success: bool,
    ) -> None:
        """Print tracker upload result immediately after upload completes."""
        publish_tracker_result(tracker, tracker_class, status, is_success)
        try:
            # Check config settings for what to print
            print_links = meta.print_tracker_links
            print_messages = meta.print_tracker_messages

            # If neither option is enabled, don't print anything
            if not print_links and not print_messages:
                return

            tracker_label = f"{tracker.ljust(tracker_label_width)}:"
            message: str | None = None
            if is_success:
                result_parts = []
                status_message = str(status.get("status_message", ""))
                has_status_message = bool(status_message) and "data error" not in status_message
                link_url = ""

                if "torrent_id" in status:
                    torrent_url = str(getattr(tracker_class, "torrent_url", ""))
                    link_url = f"{torrent_url}{status['torrent_id']}"

                if config["DEFAULT"].get("show_upload_duration", True) or meta.upload_timer:
                    duration = meta.get(f"{tracker}_upload_duration")
                    if duration and isinstance(duration, (int, float)):
                        color = "#21ff00" if duration < 5 else "#9fd600" if duration < 10 else "#cfaa00" if duration < 15 else "#f17100" if duration < 20 else "#ff0000"
                        result_parts.append(f"[[{color}]{duration:.2f}s[/{color}]]")

                if print_links and link_url:
                    result_parts.append(f"[[green]{format_terminal_link('link', link_url, config['DEFAULT'])}[/green]]")

                if has_status_message and (print_messages or (print_links and not link_url)):
                    result_parts.append(escape(Redaction.redact_private_info(status_message)))

                message = f"{tracker_label} {' '.join(result_parts)}" if result_parts else None
            else:
                status_message = str(status.get("status_message", "")).strip()
                if status_message:
                    logger.info(f"[red]{tracker_label} {escape(Redaction.redact_private_info(status_message))}[/red]", extra={"ua_gui": False})
                    return

            if message is not None:
                logger.info(message, extra={"highlighter": None})
        except Exception as e:
            logger.error(f"[red]Error printing {tracker} result: {e}[/red]")

    async def process_single_tracker(tracker: str) -> None:
        """
        try:
            _ = meta.base64.b64decode(b"dWFfc2lnbmF0dXJl").decode("utf-8")
        except KeyError:
            sys.exit()
        """

        tracker_class: Any = None
        if tracker not in {"MANUAL", "PASSTHEPOPCORN"}:
            tracker_class = tracker_class_map[tracker](config=config)
        if meta.name.endswith("DUPE?"):
            meta.name = meta.name.replace(" DUPE?", "")

        tracker = tracker.replace(" ", "").upper().strip()

        if meta.category == "BOOK" and not is_valid_cover_image(meta.artwork_path):
            status = meta.tracker_status.setdefault(tracker, {})
            status["upload"] = False
            status["status_message"] = "Skipped: BOOK uploads require a valid cover image"
            logger.info(f"[yellow]{tracker}: skipped because BOOK uploads require a valid cover image.[/yellow]")
            return

        async def check_bandwidth_and_dupes(tracker_name: str, t_class: Any) -> bool:
            if t_class and getattr(t_class, "is_usenet", False):
                return True
            if bandwidth_control:
                logger.info(f"\n[yellow]{tracker_name}: Checking bandwidth...[/yellow]")
                waiter = Wait(config)
                bw_thresh = meta.qbit_bandwidth_threshold or config["DEFAULT"].get("qbit_bandwidth_threshold", 0)
                bw_time = meta.qbit_bandwidth_time or config["DEFAULT"].get("qbit_bandwidth_time", 0)
                try:
                    bw_thresh = int(bw_thresh)
                    bw_time = int(bw_time)
                except (ValueError, TypeError) as e:
                    logger.info(f"[red]Invalid bandwidth settings: {e}, skipping bandwidth wait.[/red]")
                    bw_thresh = 0
                    bw_time = 0

                if bw_thresh > 0 and bw_time > 0:
                    waited = await waiter.wait_for_bandwidth(bw_thresh, bw_time)
                    if waited:
                        logger.info(f"[yellow]{tracker_name}: Redoing dupe check after bandwidth wait...[/yellow]")
                        try:
                            if tracker_name not in {"PASSTHEPOPCORN"}:
                                new_dupes = cast(list[Any], await t_class.search_existing(meta))
                            else:
                                ptp = PassThePopcorn(config=config)
                                group_id = meta.ptp_groupid
                                new_dupes = cast(list[Any], await ptp.search_existing(group_id or "", meta))
                        except Exception as e:
                            logger.info(f"[bold red]{tracker_name}: Error redoing duplicate check after bandwidth wait: {e}[/bold red]")
                            status = meta.tracker_status.setdefault(tracker_name, {})
                            status["status_message"] = f"Skipped: Error redoing dupe check after bandwidth wait: {e}"
                            return False

                        initial_dupes = meta.initial_dupes.get(tracker_name, [])

                        def is_in_initial(dupe: Any) -> bool:
                            for initial_dupe in initial_dupes:
                                if isinstance(dupe, dict) and isinstance(initial_dupe, dict):
                                    if dupe.get("name") == initial_dupe.get("name") and dupe.get("size") == initial_dupe.get("size"):
                                        return True
                                elif isinstance(dupe, str) and isinstance(initial_dupe, str) and dupe == initial_dupe:
                                    return True
                            return False

                        real_new_dupes = [d for d in new_dupes if not is_in_initial(d)]

                        if real_new_dupes:
                            slot_decision = await evaluate_slots(new_dupes, meta, tracker_name, config)
                            if slot_decision is not None and slot_decision.verdict is Verdict.ALLOW:
                                logger.info(f"[green]{tracker_name}: new releases appeared during the wait, but slot rules still allow this upload.[/green]")
                                return True
                            if slot_decision is not None and slot_decision.verdict is Verdict.BLOCK:
                                logger.info(f"[red]{tracker_name}: a release that fills this slot appeared during the wait. Automatically skipping upload.[/red]")
                                return False
                            dupe_checker = DupeChecker(config)
                            real_new_dupes = cast(list[Any], await dupe_checker.filter_dupes(real_new_dupes, meta, tracker_name))
                            if real_new_dupes:
                                logger.info(f"[red]New dupe found on {tracker_name} during wait! Automatically skipping upload.[/red]")
                                return False
            return True

        if tracker in api_trackers:
            tracker_status = meta.tracker_status
            upload_status = cast(Mapping[str, Any], tracker_status.get(tracker, {})).get("upload", False)
            if upload_status:
                try:
                    is_uploaded = False
                    try:
                        if not await check_bandwidth_and_dupes(tracker, tracker_class):
                            status = meta.tracker_status.setdefault(tracker_class.tracker, {})
                            status["status_message"] = "Skipped due to new dupe found after bandwidth wait"
                            print_tracker_result(tracker, tracker_class, status, False)
                            return
                        await check_tracker_image_hosts(meta, tracker_class)
                        upload_start_time = time.monotonic()
                        try:
                            is_uploaded = await tracker_class.upload(meta)
                        finally:
                            meta[f"{tracker}_upload_duration"] = time.monotonic() - upload_start_time
                    except Exception as e:
                        logger.info(f"[red]Upload failed: {escape(str(e))}[/red]")
                        logger.info(traceback.format_exc(), extra={"markup": False})
                        return
                except Exception:
                    logger.info(traceback.format_exc(), extra={"markup": False})
                    return

                if is_uploaded is None:
                    logger.warning(f"[yellow]Warning: {tracker_class.tracker} upload method returned None instead of boolean. Treating as failed upload.[/yellow]")
                    is_uploaded = False

                status = meta.tracker_status.setdefault(tracker_class.tracker, {})
                if is_uploaded and "data error" not in str(status.get("status_message", "")):
                    status["upload_success"] = True
                    if not getattr(tracker_class, "is_usenet", False):
                        await client.add_to_client(meta, tracker_class.tracker)
                    print_tracker_result(tracker, tracker_class, status, True)
                else:
                    status["upload_success"] = False
                    print_tracker_result(tracker, tracker_class, status, False)
                    logger.info(f"[red]{tracker} upload failed or returned data error.[/red]", extra={"ua_gui": False})

        elif tracker in other_api_trackers or tracker in http_trackers:
            tracker_status = meta.tracker_status
            upload_status = cast(Mapping[str, Any], tracker_status.get(tracker, {})).get("upload", False)
            if upload_status:
                try:
                    is_uploaded = False
                    try:
                        if not await check_bandwidth_and_dupes(tracker, tracker_class):
                            status = meta.tracker_status.setdefault(tracker_class.tracker, {})
                            status["status_message"] = "Skipped due to new dupe found after bandwidth wait"
                            print_tracker_result(tracker, tracker_class, status, False)
                            return
                        await check_tracker_image_hosts(meta, tracker_class)
                        upload_start_time = time.monotonic()
                        try:
                            is_uploaded = await tracker_class.upload(meta)
                        finally:
                            meta[f"{tracker}_upload_duration"] = time.monotonic() - upload_start_time
                    except Exception as e:
                        logger.info(f"[red]Upload failed: {escape(str(e))}[/red]")
                        logger.info(traceback.format_exc(), extra={"markup": False})
                        return
                except Exception:
                    logger.info(traceback.format_exc(), extra={"markup": False})
                    return
                # Detect and handle None return value from upload method
                if is_uploaded is None:
                    logger.warning(f"[yellow]Warning: {tracker_class.tracker} upload method returned None instead of boolean. Treating as failed upload.[/yellow]")
                    is_uploaded = False

                status = meta.tracker_status.setdefault(tracker_class.tracker, {})
                if is_uploaded and "data error" not in str(status.get("status_message", "")):
                    status["upload_success"] = True
                    if not getattr(tracker_class, "is_usenet", False):
                        await client.add_to_client(meta, tracker_class.tracker)
                    print_tracker_result(tracker, tracker_class, status, True)
                else:
                    status["upload_success"] = False
                    print_tracker_result(tracker, tracker_class, status, False)
                    logger.info(f"[red]{tracker} upload failed or returned data error.[/red]", extra={"ua_gui": False})

        elif tracker == "MANUAL":
            if meta.unattended:
                do_manual = True
            else:
                try:
                    with webui_events.field_prompt(
                        "Manual upload",
                        {"Release": meta.name or meta.title},
                        hint="Prepare description and torrent files for manual upload.",
                    ):
                        do_manual = cli_ui.ask_yes_no("Get files for manual upload?", default=True)
                except EOFError:
                    logger.info("\n[red]Exiting on user request (Ctrl+C)[/red]")
                    await cleanup_manager.cleanup()
                    cleanup_manager.reset_terminal()
                    sys.exit(1)
            if do_manual:
                for manual_tracker in enabled_trackers:
                    if manual_tracker != "MANUAL":
                        manual_tracker = manual_tracker.replace(" ", "").upper().strip()
                        tracker_class = tracker_class_map[manual_tracker](config=config)
                        try:
                            await check_tracker_image_hosts(meta, tracker_class)
                            if manual_tracker in api_trackers:
                                await DescriptionBuilder(manual_tracker, config).general_description_generator(
                                    meta,
                                    languages=False,
                                    mediainfo=False,
                                    nfo=False,
                                    signature=manual_tracker,
                                )
                            else:
                                await tracker_class.edit_desc(meta)
                        except Exception as e:
                            logger.info(f"[red]{manual_tracker}: Error preparing manual upload files: {e}[/red]")
                url = await manual_packager.package(meta)
                if url is False:
                    logger.info(f"[yellow]Unable to upload prep files, they can be found at `tmp/{meta.uuid}")
                else:
                    logger.info(f"[green]{meta.name}")
                    logger.info(f"[green]Files can be found at: [yellow]{url}[/yellow]")

        elif tracker == "PASSTHEPOPCORN":
            tracker_status = meta.tracker_status
            upload_status = cast(Mapping[str, Any], tracker_status.get(tracker, {})).get("upload", False)
            if upload_status:
                try:
                    ptp = PassThePopcorn(config=config)
                    group_id = meta.ptp_groupid
                    await check_tracker_image_hosts(meta, ptp)
                    ptp_url, ptp_data = await ptp.fill_upload_form(group_id, meta)
                    is_uploaded = False
                    try:
                        upload_start_time = time.monotonic()
                        try:
                            is_uploaded = await ptp.upload(meta, ptp_url, ptp_data)
                        finally:
                            meta[f"{tracker}_upload_duration"] = time.monotonic() - upload_start_time
                    except Exception as e:
                        logger.info(f"[red]Upload failed: {escape(str(e))}[/red]")
                        logger.info(traceback.format_exc(), extra={"markup": False})
                        return
                    status = meta.tracker_status.setdefault(ptp.tracker, {})
                    if is_uploaded and "data error" not in str(status.get("status_message", "")):
                        status["upload_success"] = True
                        await client.add_to_client(meta, "PASSTHEPOPCORN")
                        print_tracker_result(tracker, ptp, status, True)
                    else:
                        status["upload_success"] = False
                        print_tracker_result(tracker, ptp, status, False)
                        logger.info(f"[red]{tracker} upload failed or returned data error.[/red]", extra={"ua_gui": False})
                except Exception:
                    logger.info(traceback.format_exc(), extra={"markup": False})
                    return

    multi_screens = int(config["DEFAULT"].get("multiScreens", 2))
    discs = meta.discs or []
    one_disc = True
    if discs and len(discs) == 1:
        one_disc = True
    elif discs and len(discs) > 1:
        one_disc = False

    if ((not meta.tv_pack and one_disc) or multi_screens == 0) and not bandwidth_control:
        # Run all tracker tasks concurrently with individual error handling
        tasks: list[tuple[str, asyncio.Task[None]]] = []
        for tracker in enabled_trackers:
            task = asyncio.create_task(process_single_tracker(tracker))
            tasks.append((tracker, task))

        # Wait for all tasks to complete, but don't let one tracker's failure stop others
        results = await asyncio.gather(*[task for _, task in tasks], return_exceptions=True)

        # Log any exceptions that occurred
        for (tracker, _), result in zip(tasks, results, strict=False):
            if isinstance(result, Exception):
                logger.info(f"[red]{tracker} encountered an error: {escape(str(result))}[/red]")
                logger.debug("".join(traceback.format_exception(type(result), result, result.__traceback__)), extra={"markup": False})
    else:
        # Process each tracker sequentially
        for tracker in enabled_trackers:
            await process_single_tracker(tracker)

    for tracker_name in enabled_trackers:
        normalized = tracker_name.replace(" ", "").upper().strip()
        if normalized in {"MANUAL", "USENET"}:
            continue
        status = cast(Mapping[str, Any], meta.tracker_status.get(normalized, {}))
        duration_ms = float(meta.get(f"{normalized}_upload_duration") or 0) * 1000
        if "upload_success" in status:
            outcome = "success" if status.get("upload_success") is True else "error"
        elif status.get("upload") is True:
            outcome = "error"
        else:
            continue
        await record_event_async("api", service=normalized, operation="upload", outcome=outcome, duration_ms=duration_ms)

    logger.info(f"[green]All {upload_target} uploads processed.[/green]")
