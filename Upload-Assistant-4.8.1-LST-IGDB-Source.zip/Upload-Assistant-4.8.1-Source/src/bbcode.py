# Upload Assistant © 2025 Audionut & wastaken7 — Licensed under UAPL v1.0
import html
import re
import urllib.parse
from functools import cache
from pathlib import Path
from typing import Any

from src.console import logger
from src.meta import Meta


@cache
def _css4_colors() -> dict[str, str]:
    # Imported lazily: matplotlib is slow to import and only a few trackers need color conversion.
    from matplotlib.colors import CSS4_COLORS

    return dict(CSS4_COLORS)


@cache
def _css4_colors_by_hex() -> dict[str, str]:
    return {color_hex.lower(): color_name for color_name, color_hex in _css4_colors().items()}


_INLINE_OPEN = r"(?:\[(?:b|i|u|small|size=\d+|color=[^\]]*|font=[^\]]*)\]\s*)*"
_INLINE_CLOSE = r"(?:\s*\[/(?:b|i|u|small|size|color|font)\])*"
# A link's text up to its own [/url], never running into the next link.
_URL_BODY = r"(?:(?!\[/?url\b)[\s\S])*?\[/url\]"


def _block(core: str) -> str:
    """Match a center/right block holding only core and its inline formatting."""
    return rf"\[(center|right)\]\s*{_INLINE_OPEN}(?:{core}){_INLINE_CLOSE}\s*\[/\1\]"


def _signature(core: str) -> str:
    """Match a signature with its inline formatting, and its own center/right block when it fills one."""
    return rf"{_block(core)}|{_INLINE_OPEN}(?:{core}){_INLINE_CLOSE}"


def _image(url: str) -> str:
    """Match an image with that URL, and its own center block."""
    return rf"(?:\[center\]\s*)?\[img[^\]]*\]{url}\[/img\](?:\s*\[/center\])?"


# Boilerplate that release groups add to their descriptions, removed before images
# are extracted so a group banner is not taken as a screenshot. To support another
# group, add its name with regexes (matched case-insensitively) for each piece.
# Prefer _block or _image so a common word is never removed from running text.
RELEASE_GROUP_BOILERPLATE: dict[str, tuple[str, ...]] = {
    "Kitsune": (
        # banner right above the decorated "Screenshots" divider
        r"\[img[^\]]*\][^\[]*\[/img\]\s*(?=•❅─+✧❅✦)",
        r"•❅─+✧❅✦\s*(?:\[color=[^\]]*\])?\s*Screenshots\s*(?:\[/color\])?\s*✦❅✧─+❅•",
        r"Find\s+our\s+uploads\s*\[url=[^\]]*name=Kitsune[^\]]*\]" + _URL_BODY,
    ),
    "AXON": (_image(r"https?://file\.aither\.cc/u/y6nfEPrCxpW57juD\.png"),),
    "Jeditwo": (_image(r"https?://file\.aither\.cc/u/(?:pwkbrhyrBNiIIdeY|l7zi3mymrA1L2Xd1)\.png"),),
    "BiOMA": (_image(r"https?://i\.ibb\.co/N61fR8h3/bioma-v3\.png"),),
    "GRiMM": (
        _block(r"A\s+GRiMM\b[^\[]*?PRESENTS"),
        _image(r"https?://img1\.imgoe\.download/kOv5q\.png"),
        _block(r"Web\s+Source\s*~[^\[]*"),
        _block(r"\[font=Comic\s+Sans\s+MS\]\s*SCREENSHOTS\s*\[/font\]"),
        _block(r"~\s*A\s+GRiMM\b[^\[~]*?RELEASE\s*~"),
        _block(r"GRiMM\s*\|\s*OnlyWeb"),
        _block(r"~\s*An\s+Elegance\s+of\s+Simplicity,\s*Socializing\s*&\s*Sharing\s*~"),
    ),
    "Maghuro": (
        r"\[b\]\s*🖼️\s*Screenshots\s*\[/b\]",
        r"\[note\]\s*\[i\][^\[]*screenshots\s+have\s+been\s+tonemapped\s+to\s+SDR\s+for\s+web\s+preview\.?\s*\[/i\]\s*\[/note\]",
        r"(?:\[hr\]\s*)?" + _image(r"https?://img\.ptscreens\.com/1000203577\.png"),
    ),
}


# Signatures that other upload tools add. To support another tool, add its name with
# the signature's core regex wrapped in _signature (matched case-insensitively).
UPLOAD_TOOL_SIGNATURES: dict[str, tuple[str, ...]] = {
    "Uploadrr": (_signature(r"\[url=https?://codeberg\.org/CvT/Uploadrr/?\]" + _URL_BODY),),
    "upbrr": (_signature(r"\[url=https?://github\.com/autobrr/upbrr/?\]" + _URL_BODY),),
    "NfoForge": (_signature(r"Shared\s+with\s+\[url=https?://github\.com/jesterr0/NfoForge/?\]" + _URL_BODY),),
    "EASY UPLOAD3R": (_signature(r"⚡?\s*Uploaded\s+using\s+EASY\s+UPLOAD3R\s*⚡?"),),
    "upsies": (_signature(r"Shared\s+with\s+\[url=https?://upsies\.readthedocs\.io/?\]" + _URL_BODY),),
    "AK Automated Uploader": (_signature(r"Uploaded\s+with\s+\[url=https?://github\.com/AQTKU/ak-automated-uploader/?\]" + _URL_BODY),),
    "Only-Uploader": (_signature(r"\[url=https?://github\.com/edge20200/Only-Uploader/?\]" + _URL_BODY),),
    "MAGUS": (_signature(r"\[url=https?://dailyusetools\.com/MAGUS/?\]" + _URL_BODY),),
}


# Bold - KEEP
# Italic - KEEP
# Underline - KEEP
# Strikethrough - KEEP
# Color - KEEP
# URL - KEEP
# PARSING - Probably not exist in uploads
# Spoiler - KEEP

# QUOTE - CONVERT to CODE
# PRE - CONVERT to CODE
# Hide - CONVERT to SPOILER
# COMPARISON - CONVERT

# LIST - REMOVE TAGS/REPLACE with * or something

# Size - REMOVE TAGS

# Align - REMOVE (ALL LEFT ALIGNED)
# VIDEO - REMOVE
# HR - REMOVE
# MEDIAINFO - REMOVE
# MOVIE - REMOVE
# PERSON - REMOVE
# USER - REMOVE
# IMG - REMOVE?
# INDENT - Probably not an issue, but maybe just remove tags


class BBCODE:
    def __init__(self) -> None:
        pass

    @staticmethod
    def _is_hdbits_url(url: str) -> bool:
        parsed = urllib.parse.urlparse(url)
        host = (parsed.hostname or "").lower()
        return host == "hdbits.org" or host.endswith(".hdbits.org")

    def clean_hdb_description(self, description: str) -> tuple[str, list[dict[str, Any]]]:
        # Unescape html
        desc = html.unescape(description)
        desc = desc.replace("\r\n", "\n")
        desc = self.remove_known_boilerplate(desc)
        imagelist: list[dict[str, Any]] = []

        # First pass: Remove entire comparison sections
        # Start by finding section headers for comparisons
        comparison_sections = re.finditer(r"\[center\]\s*\[b\].*?(Comparison|vs).*?\[\/b\][\s\S]*?\[\/center\]", desc, flags=re.IGNORECASE)
        for section in comparison_sections:
            section_text = section.group(0)
            # If section contains hdbits.org, remove the entire section
            if re.search(r"hdbits\.org", section_text, flags=re.IGNORECASE):
                desc = desc.replace(section_text, "")

        # Handle individual comparison lines
        comparison_lines = re.finditer(r"(.*comparison.*)\n", desc, flags=re.IGNORECASE)
        for comp_match in comparison_lines:
            comp_pos = comp_match.start()

            # Get the next lines after the comparison line
            next_lines = desc[comp_pos : comp_pos + 500].split("\n", 3)[:3]  # Get comparison line + 2 more lines
            next_lines_text = "\n".join(next_lines)

            # Check if any of these lines contain HDBITS URLs
            if re.search(r"hdbits\.org", next_lines_text, flags=re.IGNORECASE):
                # Replace the entire section (comparison line + next 2 lines)
                line_end_pos = comp_pos + len(next_lines_text)
                to_remove = desc[comp_pos:line_end_pos]
                desc = desc.replace(to_remove, "")

        # Remove all empty URL tags containing hdbits.org
        desc = re.sub(r"\[url=https?:\/\/(img\.|t\.)?hdbits\.org[^\]]*\]\[\/url\]", "", desc, flags=re.IGNORECASE)

        # Remove URL tags with visible content
        hdbits_urls = re.findall(r"(\[url[\=\]]https?:\/\/(img\.|t\.)?hdbits\.org[^\]]+\])(.*?)(\[\/url\])?", desc, flags=re.IGNORECASE)
        for url_parts in hdbits_urls:
            full_url = "".join(url_parts)
            desc = desc.replace(full_url, "")

        # Remove HDBITS image tags
        hdbits_imgs = re.findall(r"\[img\][\s\S]*?(img\.|t\.)?hdbits\.org[\s\S]*?\[\/img\]", desc, flags=re.IGNORECASE)
        for img_tag in hdbits_imgs:
            desc = desc.replace(img_tag, "")

        # Remove any standalone HDBITS URLs
        standalone_urls = re.findall(r"https?:\/\/(img\.|t\.)?hdbits\.org\/[^\s\[\]]+", desc, flags=re.IGNORECASE)
        for url in standalone_urls:
            desc = desc.replace(url, "")

        # Catch any remaining URL tags with hdbits.org in them
        desc = re.sub(r"\[url[^\]]*hdbits\.org[^\]]*\](.*?)\[\/url\]", "", desc, flags=re.IGNORECASE)

        # Double-check for any self-closing URL tags that might have been missed
        desc = re.sub(r"\[url=https?:\/\/[^\]]*hdbits\.org[^\]]*\]\[\/url\]", "", desc, flags=re.IGNORECASE)

        # Remove empty comparison section headers and center tags
        desc = re.sub(r"\[center\]\s*\[b\].*?(Comparison|vs).*?\[\/b\][\s\S]*?\[\/center\]", "", desc, flags=re.IGNORECASE)

        # Remove any empty center tags that might be left
        desc = re.sub(r"\[center\]\s*\[\/center\]", "", desc, flags=re.IGNORECASE)

        # Clean up multiple consecutive newlines
        desc = re.sub(r"\n{3,}", "\n\n", desc)

        # Extract images wrapped in URL tags (e.g., [url=https://imgbox.com/xxx][img]https://thumbs.imgbox.com/xxx[/img][/url])
        url_img_pattern = r"\[url=(https?:\/\/[^\]]+)\]\[img\](https?:\/\/[^\]]+)\[\/img\]\[\/url\]"
        url_img_matches: list[tuple[str, str]] = re.findall(url_img_pattern, desc, flags=re.IGNORECASE)
        for web_url, img_url in url_img_matches:
            # Skip HDBITS images
            if self._is_hdbits_url(web_url) or self._is_hdbits_url(img_url):
                desc = desc.replace(f"[url={web_url}][img]{img_url}[/img][/url]", "")
                continue

            raw_url = img_url
            parsed_img_url = urllib.parse.urlparse(img_url)
            img_host = (parsed_img_url.hostname or "").lower()
            if img_host == "thumbs2.imgbox.com":
                raw_url = img_url.replace("thumbs2.imgbox.com", "images2.imgbox.com")
                raw_url = raw_url.replace("_t.png", "_o.png")

            image_dict = {"img_url": img_url, "raw_url": raw_url, "web_url": web_url}
            imagelist.append(image_dict)
            desc = desc.replace(f"[url={web_url}][img]{img_url}[/img][/url]", "")

        description = desc.strip()
        if self.is_only_bbcode(description):
            return "", imagelist
        return description, imagelist

    def clean_bhd_description(self, description: str, meta: Meta) -> tuple[str, list[dict[str, Any]]]:
        # Unescape html
        desc = html.unescape(description)
        desc = desc.replace("\r\n", "\n")
        imagelist: list[dict[str, Any]] = []

        if "framestor" in meta and meta.framestor:
            framestor_desc = desc
            save_path = Path(meta.base_dir) / "tmp" / meta.uuid
            Path(save_path).mkdir(parents=True, exist_ok=True)
            nfo_file_path = Path(save_path) / "bhd.nfo"
            with Path(nfo_file_path).open("w", encoding="utf-8") as f:
                try:
                    f.write(framestor_desc)
                finally:
                    f.close()
            logger.info(f"[green]FraMeSToR NFO saved to {nfo_file_path}")
            meta.nfo = True
            meta.bhd_nfo = True

        desc = self.remove_known_boilerplate(desc)

        # Remove size tags
        desc = re.sub(r"\[size=.*?\]", "", desc)
        desc = desc.replace("[/size]", "")
        desc = desc.replace("<", "/")
        desc = desc.replace("<", "\\")

        # Remove Images in IMG tags
        desc = re.sub(r"\[img\][\s\S]*?\[\/img\]", "", desc, flags=re.IGNORECASE)
        desc = re.sub(r"\[img=[\s\S]*?\]", "", desc, flags=re.IGNORECASE)

        # Extract loose images and add to imagelist as dictionaries
        loose_images = re.findall(r"(https?:\/\/[^\s\[\]]+\.(?:png|jpg))", desc, flags=re.IGNORECASE)
        for img_url in loose_images:
            image_dict = {"img_url": img_url, "raw_url": img_url, "web_url": img_url}
            imagelist.append(image_dict)
            desc = desc.replace(img_url, "")

        # Now, remove matching URLs from [URL] tags
        for img in imagelist:
            img_url = re.escape(img["img_url"])
            desc = re.sub(rf"\[URL={img_url}\]\[/URL\]", "", desc, flags=re.IGNORECASE)
            desc = re.sub(rf"\[URL={img_url}\]\[img[^\]]*\]{img_url}\[/img\]\[/URL\]", "", desc, flags=re.IGNORECASE)

        # Remove leftover [img] or [URL] tags in the description
        desc = re.sub(r"\[img\][\s\S]*?\[\/img\]", "", desc, flags=re.IGNORECASE)
        desc = re.sub(r"\[img=[\s\S]*?\]", "", desc, flags=re.IGNORECASE)
        desc = re.sub(r"\[URL=[\s\S]*?\]\[\/URL\]", "", desc, flags=re.IGNORECASE)

        if meta.flux:
            # Strip trailing whitespace and newlines:
            desc = desc.rstrip()

            # Strip blank lines:
            desc = desc.strip("\n")
            desc = re.sub("\n\n+", "\n\n", desc)
            while desc.startswith("\n"):
                desc = desc.replace("\n", "", 1)
            desc = desc.strip("\n")

            if desc.replace("\n", "").strip() == "":
                logger.info("[yellow]Description is empty after cleaning.")
                return "", imagelist

            description = f"[code]{desc}[/code]"
        else:
            description = ""

        if self.is_only_bbcode(description):
            return "", imagelist

        return description, imagelist

    def clean_ptp_description(self, desc: str, is_disc: str) -> tuple[str, list[dict[str, Any]]]:
        # console.print("[yellow]Cleaning PASSTHEPOPCORN description...")

        # Convert Bullet Points to -
        desc = desc.replace("&bull;", "-")

        # Unescape html
        desc = html.unescape(desc)
        desc = desc.replace("\r\n", "\n")
        desc = self.remove_known_boilerplate(desc)

        # Remove url tags with PASSTHEPOPCORN/HDBITS links
        url_tags: list[str] = re.findall(
            r"(?:\[url(?:=|\])[^\]]*https?:\/\/passthepopcorn\.m[^\]]*\]|\bhttps?:\/\/passthepopcorn\.m[^\s]+)",
            desc,
            flags=re.IGNORECASE,
        )
        url_tags += [
            "".join(tag)
            for tag in re.findall(
                r"(\[url[\=\]]https?:\/\/hdbits\.o[^\]]+)([^\[]+)(\[\/url\])?",
                desc,
                flags=re.IGNORECASE,
            )
        ]
        if url_tags:
            for url_tag in url_tags:
                url_tag_removed = re.sub(r"(\[url[\=\]]https?:\/\/passthepopcorn\.m[^\]]+])", "", url_tag, flags=re.IGNORECASE)
                url_tag_removed = re.sub(r"(\[url[\=\]]https?:\/\/hdbits\.o[^\]]+])", "", url_tag_removed, flags=re.IGNORECASE)
                url_tag_removed = url_tag_removed.replace("[/url]", "")
                desc = desc.replace(url_tag, url_tag_removed)

        # Remove links to PassThePopcorn/HDBits
        desc = desc.replace("http://passthepopcorn.me", "PassThePopcorn").replace("https://passthepopcorn.me", "PassThePopcorn")
        desc = desc.replace("http://hdbits.org", "HDBits").replace("https://hdbits.org", "HDBits")

        # Catch Stray Images and Prepare Image List
        imagelist: list[dict[str, Any]] = []
        excluded_urls: set[str] = set()

        source_encode_comps = re.findall(r"\[comparison=Source, Encode\][\s\S]*", desc, flags=re.IGNORECASE)
        source_vs_encode_sections = re.findall(r"Source Vs Encode:[\s\S]*", desc, flags=re.IGNORECASE)
        specific_cases = source_encode_comps + source_vs_encode_sections

        # Extract URLs and update excluded_urls
        for block in specific_cases:
            urls = re.findall(r"(https?:\/\/[^\s\[\]]+\.(?:png|jpg))", block, flags=re.IGNORECASE)
            excluded_urls.update(urls)
            desc = desc.replace(block, "")

        # General [comparison=...] handling
        comps = re.findall(r"\[comparison=[\s\S]*?\[\/comparison\]", desc, flags=re.IGNORECASE)
        hides = re.findall(r"\[hide[\s\S]*?\[\/hide\]", desc, flags=re.IGNORECASE)
        comps.extend(hides)
        nocomp = desc

        # Exclude URLs from excluded array fom `nocomp`
        for url in excluded_urls:
            nocomp = nocomp.replace(url, "")

        comp_placeholders: list[str] = []

        # Replace comparison/hide tags with placeholder because sometimes uploaders use comp images as loose images
        for i, comp in enumerate(comps):
            nocomp = nocomp.replace(comp, "")
            desc = desc.replace(comp, f"COMPARISON_PLACEHOLDER-{i} ")
            comp_placeholders.append(comp)

        # as the name implies, protect image links while doing regex things
        def protect_links(desc: str) -> tuple[str, list[str]]:
            links: list[str] = re.findall(r"https?://\S+", desc)
            for i, link in enumerate(links):
                desc = desc.replace(link, f"__LINK_PLACEHOLDER_{i}__")
            return desc, links

        def restore_links(desc: str, links: list[str]) -> str:
            for i, link in enumerate(links):
                desc = desc.replace(f"__LINK_PLACEHOLDER_{i}__", link)
            return desc

        links: list[str] = []

        if is_disc == "DVD":
            desc = re.sub(r"\[mediainfo\][\s\S]*?\[\/mediainfo\]", "", desc)

        elif is_disc == "BDMV":
            desc = re.sub(r"\[mediainfo\][\s\S]*?\[\/mediainfo\]", "", desc)
            desc = re.sub(r"DISC INFO:[\s\S]*?(\n\n|$)", "", desc, flags=re.IGNORECASE)
            desc = re.sub(r"Disc Title:[\s\S]*?(\n\n|$)", "", desc, flags=re.IGNORECASE)
            desc = re.sub(r"Disc Size:[\s\S]*?(\n\n|$)", "", desc, flags=re.IGNORECASE)
            desc = re.sub(r"Protection:[\s\S]*?(\n\n|$)", "", desc, flags=re.IGNORECASE)
            desc = re.sub(r"BD-Java:[\s\S]*?(\n\n|$)", "", desc, flags=re.IGNORECASE)
            desc = re.sub(r"BDInfo:[\s\S]*?(\n\n|$)", "", desc, flags=re.IGNORECASE)
            desc = re.sub(r"PLAYLIST REPORT:[\s\S]*?(?=\n\n|$)", "", desc, flags=re.IGNORECASE)
            desc = re.sub(r"Name:[\s\S]*?(\n\n|$)", "", desc, flags=re.IGNORECASE)
            desc = re.sub(r"Length:[\s\S]*?(\n\n|$)", "", desc, flags=re.IGNORECASE)
            desc = re.sub(r"Size:[\s\S]*?(\n\n|$)", "", desc, flags=re.IGNORECASE)
            desc = re.sub(r"Total Bitrate:[\s\S]*?(\n\n|$)", "", desc, flags=re.IGNORECASE)
            desc = re.sub(r"VIDEO:[\s\S]*?(?=\n\n|$)", "", desc, flags=re.IGNORECASE)
            desc = re.sub(r"AUDIO:[\s\S]*?(?=\n\n|$)", "", desc, flags=re.IGNORECASE)
            desc = re.sub(r"SUBTITLES:[\s\S]*?(?=\n\n|$)", "", desc, flags=re.IGNORECASE)
            desc = re.sub(r"Codec\s+Bitrate\s+Description[\s\S]*?(?=\n\n|$)", "", desc, flags=re.IGNORECASE)
            desc = re.sub(r"Codec\s+Language\s+Bitrate\s+Description[\s\S]*?(?=\n\n|$)", "", desc, flags=re.IGNORECASE)

        else:
            desc = re.sub(r"\[mediainfo\][\s\S]*?\[\/mediainfo\]", "", desc)
            desc = re.sub(r"(^general\nunique)(.*?)^$", "", desc, flags=re.MULTILINE | re.IGNORECASE | re.DOTALL)
            desc = re.sub(r"(^general\ncomplete)(.*?)^$", "", desc, flags=re.MULTILINE | re.IGNORECASE | re.DOTALL)
            desc = re.sub(r"(^(Format[\s]{2,}:))(.*?)^$", "", desc, flags=re.MULTILINE | re.IGNORECASE | re.DOTALL)
            desc = re.sub(r"(^(video|audio|text)( #\d+)?\nid)(.*?)^$", "", desc, flags=re.MULTILINE | re.IGNORECASE | re.DOTALL)
            desc = re.sub(r"(^(menu)( #\d+)?\n)(.*?)^$", "", f"{desc}\n\n", flags=re.MULTILINE | re.IGNORECASE | re.DOTALL)

            desc, links = protect_links(desc)

            desc = re.sub(
                r"\[b\](.*?)(Matroska|DTS|AVC|x264|Progressive|23\.976 fps|16:9|[0-9]+x[0-9]+|[0-9]+ MiB|[0-9]+ Kbps|[0-9]+ bits|cabac=.*?/ aq=.*?|\d+\.\d+ Mbps)\[/b\]",
                "",
                desc,
                flags=re.IGNORECASE | re.DOTALL,
            )
            desc = re.sub(
                r"(Matroska|DTS|AVC|x264|Progressive|23\.976 fps|16:9|[0-9]+x[0-9]+|[0-9]+ MiB|[0-9]+ Kbps|[0-9]+ bits|cabac=.*?/ aq=.*?|\d+\.\d+ Mbps|[0-9]+\s+channels|[0-9]+\.[0-9]+\s+KHz|[0-9]+ KHz|[0-9]+\s+bits)",
                "",
                desc,
                flags=re.IGNORECASE | re.DOTALL,
            )
            desc = re.sub(
                r"\[u\](Format|Bitrate|Channels|Sampling Rate|Resolution):\[/u\]\s*\d*.*?",
                "",
                desc,
                flags=re.IGNORECASE,
            )
            desc = re.sub(
                r"^\s*\d+\s*(channels|KHz|bits)\s*$",
                "",
                desc,
                flags=re.MULTILINE | re.IGNORECASE,
            )

            desc = re.sub(r"^\s+$", "", desc, flags=re.MULTILINE)
            desc = re.sub(r"\n{2,}", "\n", desc)

        desc = restore_links(desc, links)

        # Convert Quote tags:
        desc = re.sub(r"\[quote.*?\]", "[code]", desc)
        desc = desc.replace("[/quote]", "[/code]")

        # Remove Alignments:
        desc = re.sub(r"\[align=.*?\]", "", desc)
        desc = desc.replace("[/align]", "")

        # Remove size tags
        desc = re.sub(r"\[size=.*?\]", "", desc)
        desc = desc.replace("[/size]", "")

        # Remove Videos
        desc = re.sub(r"\[video\][\s\S]*?\[\/video\]", "", desc)

        # Remove Staff tags
        desc = re.sub(r"\[staff[\s\S]*?\[\/staff\]", "", desc)

        # Remove Movie/Person/User/hr/Indent
        remove_list = ["[movie]", "[/movie]", "[artist]", "[/artist]", "[user]", "[/user]", "[indent]", "[/indent]", "[size]", "[/size]", "[hr]"]
        for each in remove_list:
            desc = desc.replace(each, "")

        # Remove Images in IMG tags
        desc = re.sub(r"\[img\][\s\S]*?\[\/img\]", "", desc, flags=re.IGNORECASE)
        desc = re.sub(r"\[img=[\s\S]*?\]", "", desc, flags=re.IGNORECASE)

        # Extract loose images and add to imagelist as dictionaries
        loose_images = re.findall(r"(https?:\/\/[^\s\[\]]+\.(?:png|jpg))", nocomp, flags=re.IGNORECASE)
        for img_url in loose_images:
            if img_url not in excluded_urls:  # Only include URLs not part of excluded sections
                image_dict = {"img_url": img_url, "raw_url": img_url, "web_url": img_url}
                imagelist.append(image_dict)
                desc = desc.replace(img_url, "")

        # Re-place comparisons
        for i, comp in enumerate(comp_placeholders):
            comp = re.sub(r"\[\/?img[\s\S]*?\]", "", comp, flags=re.IGNORECASE)
            desc = desc.replace(f"COMPARISON_PLACEHOLDER-{i} ", comp)

        # Convert hides with multiple images to comparison
        desc = self.convert_collapse_to_comparison(desc, "hide", hides)

        # Strip blank lines:
        desc = desc.strip("\n")
        desc = re.sub("\n\n+", "\n\n", desc)
        while desc.startswith("\n"):
            desc = desc.replace("\n", "", 1)
        desc = desc.strip("\n")

        if desc.replace("\n", "").strip() == "":
            return "", imagelist
        if self.is_only_bbcode(desc):
            return "", imagelist

        return desc, imagelist

    def clean_unit3d_description(self, desc: str, site: str) -> tuple[str, list[dict[str, Any]]]:
        # Unescape HTML
        desc = html.unescape(desc)
        # Replace carriage returns with newlines
        desc = desc.replace("\r\n", "\n")
        desc = self.remove_known_boilerplate(desc)

        # Remove links to site
        site_netloc = urllib.parse.urlparse(site).netloc
        site_domain = site_netloc.split(".")[0]
        site_regex = rf"(\[url[\=\]]https?:\/\/{site_domain}\.[^\/\]]+/[^\]]+])([^\[]+)(\[\/url\])?"
        site_url_tags = re.findall(site_regex, desc)
        if site_url_tags:
            for site_url_tag in site_url_tags:
                site_url_tag = "".join(site_url_tag)
                url_tag_regex = rf"(\[url[\=\]]https?:\/\/{site_domain}\.[^\/\]]+[^\]]+])"
                url_tag_removed = re.sub(url_tag_regex, "", site_url_tag)
                url_tag_removed = url_tag_removed.replace("[/url]", "")
                desc = desc.replace(site_url_tag, url_tag_removed)

        # Subdomains such as an image host on the site must keep their full host
        desc = re.sub(rf"(?<![\w.-]){re.escape(site_netloc)}", site_domain, desc)

        # Temporarily hide spoiler tags
        spoilers = re.findall(r"\[spoiler[\s\S]*?\[\/spoiler\]", desc)
        nospoil = desc
        spoiler_placeholders: list[str] = []
        for i in range(len(spoilers)):
            nospoil = nospoil.replace(spoilers[i], "")
            desc = desc.replace(spoilers[i], f"SPOILER_PLACEHOLDER-{i} ")
            spoiler_placeholders.append(spoilers[i])

        # Get Images from [img] tags, checking if they're wrapped in [url] tags
        imagelist: list[dict[str, Any]] = []

        # First, find images wrapped in URL tags: [url=web_url][img]img_url[/img][/url]
        url_img_pattern = r"\[url=(https?://[^\]]+)\]\[img[^\]]*\](.*?)\[/img\]\[/url\]"
        url_img_matches = re.findall(url_img_pattern, desc, flags=re.IGNORECASE)
        for web_url, img_url in url_img_matches:
            image_dict = {
                "img_url": img_url.strip(),
                "raw_url": img_url.strip(),
                "web_url": web_url.strip(),
            }
            imagelist.append(image_dict)
            # Remove the entire [url=...][img]...[/img][/url] structure
            desc = re.sub(rf"\[url={re.escape(web_url)}\]\[img[^\]]*\]{re.escape(img_url)}\[/img\]\[/url\]", "", desc, flags=re.IGNORECASE)

        # Then find standalone [img] tags (not wrapped in URL)
        img_tags = re.findall(r"\[img[^\]]*\](.*?)\[/img\]", desc, re.IGNORECASE)
        if img_tags:
            for img_url in img_tags:
                img_url = img_url.strip()
                # Check if this image was already added (wrapped in URL)
                if not any(img["img_url"] == img_url for img in imagelist):
                    image_dict = {
                        "img_url": img_url,
                        "raw_url": img_url,
                        "web_url": img_url,
                    }
                    imagelist.append(image_dict)
                # Remove the [img] tag
                desc = re.sub(rf"\[img[^\]]*\]{re.escape(img_url)}\[/img\]", "", desc, flags=re.IGNORECASE)

        # Filter out bot images from imagelist
        bot_image_urls = [
            "https://blutopia.xyz/favicon.ico",  # Example bot image URL
            "https://i.ibb.co/2NVWb0c/uploadrr.webp",
            "https://blutopia/favicon.ico",
            # Add any other known bot image URLs here
        ]
        imagelist = [img for img in imagelist if img["img_url"] not in bot_image_urls and not re.search(r"thumbs", img["img_url"], re.IGNORECASE)]
        # TMDB artwork (logos, posters, stills) is never a screenshot
        imagelist = [img for img in imagelist if (urllib.parse.urlparse(img["img_url"]).hostname or "").lower() != "image.tmdb.org"]

        # Restore spoiler tags
        if spoiler_placeholders:
            for i, spoiler in enumerate(spoiler_placeholders):
                desc = desc.replace(f"SPOILER_PLACEHOLDER-{i} ", spoiler)

        # Check for and clean up empty [center] tags
        centers = re.findall(r"\[center[\s\S]*?\[\/center\]", desc)
        if centers:
            for center in centers:
                # If [center] contains only whitespace or empty tags, remove the entire tag
                cleaned_center = re.sub(r"\[center\]\s*\[\/center\]", "", center)
                cleaned_center = re.sub(r"\[center\]\s+", "[center]", cleaned_center)
                cleaned_center = re.sub(r"\s*\[\/center\]", "[/center]", cleaned_center)
                desc = desc.replace(center, "") if cleaned_center == "[center][/center]" else desc.replace(center, cleaned_center.strip())

        # Remove bot signatures
        bot_signature_regex = r"""
            \[center\]\s*\[img=\d+\]https:\/\/blutopia\.xyz\/favicon\.ico\[\/img\]\s*\[b\]
            Uploaded\sUsing\s\[url=https:\/\/github\.com\/HDInnovations\/UNIT3D\]UNIT3D\[\/url\]\s
            Auto\sUploader\[\/b\]\s*\[img=\d+\]https:\/\/blutopia\.xyz\/favicon\.ico\[\/img\]\s*\[\/center\]|
            \[center\]\s*\[b\]Uploaded\sUsing\s\[url=https:\/\/github\.com\/HDInnovations\/UNIT3D\]UNIT3D\[\/url\]
            \sAuto\sUploader\[\/b\]\s*\[\/center\]|
            \[center\]\[url=https:\/\/github\.com\/z-ink\/uploadrr\]\[img=\d+\]https:\/\/i\.ibb\.co\/2NVWb0c\/uploadrr\.webp\[\/img\]\[\/url\]\[\/center\]|
            \n\[center\]\[url=https:\/\/github\.com\/edge20200\/Only-Uploader\]Powered\sby\s
            Only-Uploader\[\/url\]\[\/center\]|
            \[center\]\[url=\/torrents\?perPage=\d+&name=[^\]]*\]\[\/url\]\[\/center\]
        """
        desc = re.sub(bot_signature_regex, "", desc, flags=re.IGNORECASE | re.VERBOSE)
        # Remove AITHER internal signature
        desc = re.sub(
            r"\[center\]\[b\]\[size=\d+\]🖌️\[/size\]\[/b\][\s\S]*?This is an internal release which was first released exclusively on Aither\.[\s\S]*?🍻 Cheers to all the Aither.*?\[/center\]",
            "",
            desc,
            flags=re.IGNORECASE,
        )
        desc = re.sub(r"\[center\].*Created by.*Upload Assistant.*\[\/center\]", "", desc, flags=re.IGNORECASE)
        desc = re.sub(r"\[right\].*Created by.*Upload Assistant.*\[\/right\]", "", desc, flags=re.IGNORECASE)
        # Remove Upload-Assistant signatures imported from another release.
        ua_signature_regex = r"""
            ^[ \t]*
            \[(?:right|center|align=(?:right|center))\][ \t]*(?:\n[ \t]*)?
            \[url=https:\/\/github\.com\/[^\]\/]+\/[^\]\/]*Upload-Assistant\][ \t]*(?:\n[ \t]*)?
            (?:\[size=\d+\][ \t]*(?:\n[ \t]*)?)?
            (?:Shared\s+with|Compartilhado\s+com)\s+Upload[-\s]+Assistant
            (?:[ \t]+v?\d+(?:[.+-]\d+)*)?
            (?:[ \t]+\(fork\))?
            [ \t]*(?:\n[ \t]*)?
            (?:\[\/size\][ \t]*(?:\n[ \t]*)?)?
            \[\/url\][ \t]*(?:\n[ \t]*)?
            \[\/(?:right|center|align)\][ \t]*$
        """
        desc = re.sub(ua_signature_regex, "", desc, flags=re.IGNORECASE | re.MULTILINE | re.VERBOSE)

        # Remove leftover [img] or [URL] tags in the description
        desc = re.sub(r"\[img\][\s\S]*?\[\/img\]", "", desc, flags=re.IGNORECASE)
        desc = re.sub(r"\[img=[\s\S]*?\]", "", desc, flags=re.IGNORECASE)
        # desc = re.sub(r"\[URL=[\s\S]*?\]\[\/URL\]", "", desc, flags=re.IGNORECASE)

        # Strip trailing whitespace and newlines:
        desc = desc.rstrip()

        if desc.replace("\n", "") == "":
            return "", imagelist
        if self.is_only_bbcode(desc):
            return "", imagelist
        return desc, imagelist

    def remove_known_boilerplate(self, desc: str) -> str:
        """Remove release group boilerplate and upload tool signatures."""
        for patterns in (*RELEASE_GROUP_BOILERPLATE.values(), *UPLOAD_TOOL_SIGNATURES.values()):
            for pattern in patterns:
                desc = re.sub(pattern, "", desc, flags=re.IGNORECASE)
        return desc

    def is_only_bbcode(self, desc: str) -> bool:
        # Remove all BBCode tags
        text = re.sub(r"\[/?[a-zA-Z0-9]+(?:=[^\]]*)?\]", "", desc)
        # Remove whitespace and newlines
        text = text.strip()
        # If nothing left, it's only BBCode
        return not text

    def convert_pre_to_code(self, desc: str) -> str:
        desc = desc.replace("[pre]", "[code]")
        return desc.replace("[/pre]", "[/code]")

    def convert_code_to_pre(self, desc: str) -> str:
        desc = desc.replace("[code]", "[pre]")
        return desc.replace("[/code]", "[/pre]")

    def convert_hide_to_spoiler(self, desc: str) -> str:
        desc = desc.replace("[hide", "[spoiler")
        return desc.replace("[/hide]", "[/spoiler]")

    def convert_spoiler_to_hide(self, desc: str) -> str:
        desc = desc.replace("[spoiler", "[hide")
        return desc.replace("[/spoiler]", "[/hide]")

    def remove_hide(self, desc: str) -> str:
        return desc.replace("[hide]", "").replace("[/hide]", "")

    def convert_named_spoiler_to_named_hide(self, desc: str) -> str:
        """
        Converts [spoiler=Name] to [hide=Name]
        """
        desc = re.sub(r"\[spoiler=([^]]+)]", r"[hide=\1]", desc, flags=re.IGNORECASE)
        return desc.replace("[/spoiler]", "[/hide]")

    def remove_spoiler(self, desc: str) -> str:
        return re.sub(r"\[\/?spoiler[\s\S]*?\]", "", desc, flags=re.IGNORECASE)

    def remove_color(self, desc: str) -> str:
        """
        Removes [color=...] and [/color] tags.
        """
        pattern = r"\[/?color(?:=[^\]]*)?\]"
        return re.sub(pattern, "", desc, flags=re.IGNORECASE)

    def convert_named_colors(self, desc: str) -> str:
        """Convert CSS named colors in BBCode color tags to hexadecimal values."""

        def convert(match: re.Match[str]) -> str:
            color_name = match.group(1).strip().lower()
            color_hex = _css4_colors().get(color_name)
            return f"[color={color_hex.lower()}]" if color_hex else match.group(0)

        return re.sub(r"\[color=([^\]]+)\]", convert, desc, flags=re.IGNORECASE)

    def convert_hex_colors_to_named(self, desc: str) -> str:
        """Convert exact CSS4 hexadecimal colors in BBCode tags to named colors."""

        def convert(match: re.Match[str]) -> str:
            color_hex = match.group(1).lower()
            if len(color_hex) == 4:
                color_hex = "#" + "".join(character * 2 for character in color_hex[1:])
            color_name = _css4_colors_by_hex().get(color_hex)
            return f"[color={color_name}]" if color_name else match.group(0)

        return re.sub(r"\[color=(#[0-9a-fA-F]{3}|#[0-9a-fA-F]{6})\]", convert, desc, flags=re.IGNORECASE)

    def convert_named_spoiler_to_normal_spoiler(self, desc: str) -> str:
        return re.sub(r"(\[spoiler=[^]]+])", "[spoiler]", desc, flags=re.IGNORECASE)

    def convert_spoiler_to_code(self, desc: str) -> str:
        desc = desc.replace("[spoiler", "[code")
        return desc.replace("[/spoiler]", "[/code]")

    def convert_code_to_quote(self, desc: str) -> str:
        desc = desc.replace("[code", "[quote")
        return desc.replace("[/code]", "[/quote]")

    def remove_img_resize(self, desc: str) -> str:
        """
        Converts [img=number] or any other parameters to just [img]
        """
        return re.sub(r"\[img(?:[^\]]*)\]", "[img]", desc, flags=re.IGNORECASE)

    def clamp_size_tags(self, desc: str, max_size: int = 10) -> str:
        """Clamp integer BBCode size tags without changing other markup."""

        def clamp(match: re.Match[str]) -> str:
            return match.group(0) if int(match.group(1)) <= max_size else f"[size={max_size}]"

        return re.sub(r"\[size=(\d+)\]", clamp, desc, flags=re.IGNORECASE)

    def convert_headings_to_sizes(self, desc: str) -> str:
        """Convert BBCode h1-h6 tags to tracker-compatible size markup."""
        heading_sizes = {
            "1": 6,
            "2": 5,
            "3": 4,
            "4": 3,
            "5": 2,
            "6": 1,
        }

        def convert(match: re.Match[str]) -> str:
            level = match.group(1)
            content = match.group(2)
            if level == "6":
                return f"[size=1][b][color=grey]{content}[/color][/b][/size]"
            return f"[size={heading_sizes[level]}][b]{content}[/b][/size]"

        return re.sub(r"\[h([1-6])\](.*?)\[/h\1\]", convert, desc, flags=re.IGNORECASE | re.DOTALL)

    def remove_extra_lines(self, desc: str) -> str:
        """
        Removes more than 2 consecutive newlines
        """
        return re.sub(r"\n{3,}", "\n\n", desc)

    def convert_to_align(self, desc: str) -> str:
        """
        Converts [right], [left], [center] to [align=right], [align=left], [align=center]
        """
        desc = re.sub(r"\[(right|center|left)\]", lambda m: f"[align={m.group(1)}]", desc)
        return re.sub(r"\[/(right|center|left)\]", "[/align]", desc)

    def remove_sup(self, desc: str) -> str:
        """
        Removes [sup] tags
        """
        return desc.replace("[sup]", "").replace("[/sup]", "")

    def remove_sub(self, desc: str) -> str:
        """
        Removes [sub] tags
        """
        return desc.replace("[sub]", "").replace("[/sub]", "")

    def remove_list(self, desc: str) -> str:
        """
        Removes [list] tags
        """
        return desc.replace("[list]", "").replace("[/list]", "")

    def convert_comparison_to_collapse(self, desc: str, max_width: int) -> str:
        comparisons = re.findall(r"\[comparison=[\s\S]*?\[\/comparison\]", desc)
        for comp in comparisons:
            line: list[str] = []
            output: list[str] = []
            comp_sources = comp.split("]", 1)[0].replace("[comparison=", "").replace(" ", "").split(",")
            comp_images = comp.split("]", 1)[1].replace("[/comparison]", "").replace(",", "\n").replace(" ", "\n")
            comp_images = re.findall(r"(https?:\/\/.*\.(?:png|jpg))", comp_images, flags=re.IGNORECASE)
            screens_per_line = len(comp_sources)
            img_size = int(max_width / screens_per_line)
            if img_size > 350:
                img_size = 350
            for img in comp_images:
                img = img.strip()
                if img != "":
                    bb = f"[url={img}][img={img_size}]{img}[/img][/url]"
                    line.append(bb)
                    if len(line) == screens_per_line:
                        output.append("".join(line))
                        line = []
            output_str = "\n".join(output)
            new_bbcode = f"[spoiler={' vs '.join(comp_sources)}][center]{' | '.join(comp_sources)}[/center]\n{output_str}[/spoiler]"
            desc = desc.replace(comp, new_bbcode)
        return desc

    def convert_comparison_to_centered(self, desc: str, max_width: int) -> str:
        comparisons = re.findall(r"\[comparison=[\s\S]*?\[\/comparison\]", desc)
        for comp in comparisons:
            line: list[str] = []
            output: list[str] = []
            comp_sources = comp.split("]", 1)[0].replace("[comparison=", "").strip()
            comp_sources = re.split(r"\s*,\s*", comp_sources)
            comp_images = comp.split("]", 1)[1].replace("[/comparison]", "").replace(",", "\n").replace(" ", "\n")
            comp_images = re.findall(r"(https?:\/\/.*\.(?:png|jpg))", comp_images, flags=re.IGNORECASE)
            screens_per_line = len(comp_sources)
            img_size = int(max_width / screens_per_line)
            if img_size > 350:
                img_size = 350
            for img in comp_images:
                img = img.strip()
                if img != "":
                    bb = f"[url={img}][img={img_size}]{img}[/img][/url]"
                    line.append(bb)
                    if len(line) == screens_per_line:
                        output.append("".join(line))
                        line = []
            output_str = "\n".join(output)
            new_bbcode = f"[center]{' | '.join(comp_sources)}\n{output_str}[/center]"
            desc = desc.replace(comp, new_bbcode)
        return desc

    def convert_collapse_to_comparison(self, desc: str, spoiler_hide: str, collapses: list[str]) -> str:
        # Convert Comparison spoilers to [comparison=]
        if collapses != []:
            for i in range(len(collapses)):
                tag = collapses[i]
                images = re.findall(r"\[img[\s\S]*?\[\/img\]", tag, flags=re.IGNORECASE)
                if len(images) >= 6:
                    comp_images: list[str] = []
                    final_sources: list[str] = []
                    for image in images:
                        image_url = re.sub(r"\[img[\s\S]*\]", "", image.replace("[/img]", ""), flags=re.IGNORECASE)
                        comp_images.append(image_url)
                    sources = ""
                    if spoiler_hide == "spoiler":
                        spoiler_match = re.match(r"\[spoiler[\s\S]*?\]", tag)
                        if spoiler_match:
                            sources = spoiler_match[0].replace("[spoiler=", "")[:-1]
                        else:
                            continue
                    elif spoiler_hide == "hide":
                        hide_match = re.match(r"\[hide[\s\S]*?\]", tag)
                        if hide_match:
                            sources = hide_match[0].replace("[hide=", "")[:-1]
                        else:
                            continue
                    if not sources:
                        continue
                    sources = re.sub("comparison", "", sources, flags=re.IGNORECASE)
                    for each in ["vs", ",", "|"]:
                        sources_list = sources.split(each)
                        sources = "$".join(sources_list)
                    sources_list = sources.split("$")
                    final_sources = [source.strip() for source in sources_list]
                    comp_images_str = "\n".join(comp_images)
                    final_sources_str = ", ".join(final_sources)
                    spoil2comp = f"[comparison={final_sources_str}]{comp_images_str}[/comparison]"
                    desc = desc.replace(tag, spoil2comp)
        return desc
