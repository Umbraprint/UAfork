# Upload Assistant © 2025 Audionut & wastaken7 — Licensed under UAPL v1.0
import asyncio
import contextlib
import fnmatch
import glob
import math
import os
import platform
import random
import re
import subprocess
import sys
import time
from collections.abc import Sequence
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import cli_ui
import torf
from rich.progress import BarColumn, TaskProgressColumn, TextColumn
from torf import Torrent

from bin.get_mkbrr import MkbrrBinaryManager
from src.app_paths import CODE_DIR
from src.binaries import configured_binary
from src.console import console, is_cli_progress_suppressed, logger, progress_display
from src.meta import Meta
from src.resource_coordinator import resource_slot
from src.stats import record_event, record_event_async
from src.torrent_manifest import TorrentManifest
from src.torrent_policy import PIECE_SIZE_MAX, PIECE_SIZE_MIN, hdbits_piece_size
from src.torrent_policy import hdbits_pieces_allowed as hdbits_pieces_allowed
from src.webui_progress import complete_progress, has_progress_callback, publish_progress

SUBTITLE_EXTENSIONS = (".srt", ".sub", ".vtt", ".ssa", ".ass", ".idx")
DISC_EXCLUDE_GLOBS = ("._*", "*/._*", "*.lwi")


def calculate_piece_size(
    total_size: int,
    min_size: int,
    max_size: int,
    meta: Meta,
    piece_size: int | None = None,
) -> int:
    return TorrentCreator.calculate_piece_size(
        total_size=total_size,
        min_size=min_size,
        max_size=max_size,
        meta=meta,
        piece_size=piece_size,
    )


class CustomTorrent(torf.Torrent):
    def __init__(self, meta: Meta, *args: Any, **kwargs: Any) -> None:
        self._meta = meta

        # Extract and store the precalculated piece size
        self._precalculated_piece_size: int | None = kwargs.pop("piece_size", None)
        super().__init__(*args, **kwargs)

        # Set piece size directly
        if self._precalculated_piece_size is not None:
            self._piece_size = self._precalculated_piece_size
            self.metainfo["info"]["piece length"] = self._precalculated_piece_size

    @property
    def piece_size_min(self) -> int:
        return PIECE_SIZE_MIN

    @piece_size_min.setter
    def piece_size_min(self, piece_size_min: int | None) -> None:
        _ = piece_size_min
        return

    @property
    def piece_size_max(self) -> int:
        return PIECE_SIZE_MAX

    @piece_size_max.setter
    def piece_size_max(self, piece_size_max: int | None) -> None:
        _ = piece_size_max
        return

    @property
    def piece_size(self) -> int:
        return self._piece_size

    @piece_size.setter
    def piece_size(self, value: int | None) -> None:
        if self._precalculated_piece_size is not None:
            value = self._precalculated_piece_size
        if value is None:
            return

        self._piece_size = value
        self.metainfo["info"]["piece length"] = value

    def validate_piece_size(self, _meta: Meta | None = None) -> None:
        if self._precalculated_piece_size is not None:
            self._piece_size = self._precalculated_piece_size
            self.metainfo["info"]["piece length"] = self._precalculated_piece_size
            return


class TorrentCreator:
    # Limit concurrent torrent creation to avoid heavy parallel hashing
    _create_torrent_semaphore = asyncio.Semaphore(1)
    _create_torrent_inflight = 0
    _torf_start_time = time.time()

    @classmethod
    async def rehash_torrents(cls, meta: Meta) -> None:
        TorrentManifest(meta.base_dir, meta.uuid).clear()
        path = Path(str(meta.path))
        await cls.create_torrent(meta, path, "BASE")
        if meta.subtitle_files:
            await cls.create_torrent(meta, path, "BASE_SUBS")

    @staticmethod
    def calculate_piece_size(
        total_size: int,
        min_size: int,
        max_size: int,
        meta: Meta,
        piece_size: int | None = None,
    ) -> int:
        if "HDBITS" in meta.trackers:
            return hdbits_piece_size(total_size)

        # Set max_size
        if piece_size:
            try:
                max_size = min(piece_size * 1024 * 1024, PIECE_SIZE_MAX)
            except ValueError:
                max_size = 134217728  # Fallback to default if conversion fails
        else:
            max_size = 134217728  # 128 MiB default maximum

        logger.debug(f"Content size: {total_size / (1024 * 1024):.2f} MiB")
        logger.debug(f"Max size: {max_size}")

        total_size_mib = total_size / (1024 * 1024)

        if total_size_mib <= 60:  # <= 60 MiB
            piece_size = 32 * 1024  # 32 KiB
        elif total_size_mib <= 120:  # <= 120 MiB
            piece_size = 64 * 1024  # 64 KiB
        elif total_size_mib <= 240:  # <= 240 MiB
            piece_size = 128 * 1024  # 128 KiB
        elif total_size_mib <= 480:  # <= 480 MiB
            piece_size = 256 * 1024  # 256 KiB
        elif total_size_mib <= 960:  # <= 960 MiB
            piece_size = 512 * 1024  # 512 KiB
        elif total_size_mib <= 1920:  # <= 1.875 GiB
            piece_size = 1024 * 1024  # 1 MiB
        elif total_size_mib <= 3840:  # <= 3.75 GiB
            piece_size = 2 * 1024 * 1024  # 2 MiB
        elif total_size_mib <= 7680:  # <= 7.5 GiB
            piece_size = 4 * 1024 * 1024  # 4 MiB
        elif total_size_mib <= 15360:  # <= 15 GiB
            piece_size = 8 * 1024 * 1024  # 8 MiB
        elif total_size_mib <= 46080:  # <= 45 GiB
            piece_size = 16 * 1024 * 1024  # 16 MiB
        elif total_size_mib <= 92160:  # <= 90 GiB
            piece_size = 32 * 1024 * 1024  # 32 MiB
        elif total_size_mib <= 138240:  # <= 135 GiB
            piece_size = 64 * 1024 * 1024
        else:
            piece_size = 128 * 1024 * 1024  # 128 MiB

        if any(tracker in meta.trackers for tracker in ["HDBITS", "PASSTHEPOPCORN"]) and piece_size > 16 * 1024 * 1024:
            piece_size = 16 * 1024 * 1024

        # Enforce minimum and maximum limits
        piece_size = max(min_size, min(piece_size, max_size))

        # Calculate number of pieces for debugging
        num_pieces = math.ceil(total_size / piece_size)
        logger.debug(f"Selected piece size: {piece_size / 1024:.2f} KiB")
        logger.debug(f"Number of pieces: {num_pieces}")

        return piece_size

    @staticmethod
    def build_mkbrr_exclude_string(root_folder: str, filelist: Sequence[str], allow_subs: bool = False) -> str:
        if allow_subs:
            manual_patterns = ["*.nfo", "*.jpg", "*.png", "*.txt", "*.xml"]
        else:
            manual_patterns = ["*.nfo", "*.jpg", "*.png", "*.srt", "*.sub", "*.vtt", "*.ssa", "*.ass", "*.txt", "*.xml"]
        keep_set = {str(Path(f).resolve()) for f in filelist}

        exclude_files: set[str] = set()
        for dirpath, _, filenames in os.walk(root_folder):
            for fname in filenames:
                full_path = str(Path(Path(dirpath) / fname).resolve())
                if full_path in keep_set:
                    continue
                if any(fnmatch.fnmatch(fname, pat) for pat in manual_patterns):
                    continue
                exclude_files.add(fname)

        return ",".join(sorted(exclude_files) + manual_patterns)

    @classmethod
    async def create_torrent(
        cls,
        meta: Meta,
        path: str | os.PathLike[str],
        output_filename: str,
        tracker_url: str | None = None,
        piece_size: int = 0,
        make_default: bool = False,
    ) -> str | Torrent:
        # Ensure only one torrent creation runs at a time
        wait_started: float | None = None
        if cls._create_torrent_semaphore.locked():
            wait_started = time.time()
            logger.debug("[yellow]Waiting for create_torrent slot...[/yellow]")

        async with cls._create_torrent_semaphore:
            cls._create_torrent_inflight += 1
            if meta.debug:
                wait_msg = ""
                if wait_started is not None:
                    waited = time.time() - wait_started
                    wait_msg = f" (waited {waited:.2f}s)"
                logger.debug(f"[cyan]create_torrent start | in-flight={cls._create_torrent_inflight}{wait_msg}[/cyan]")

            try:
                if not piece_size:
                    piece_size = meta.max_piece_size
                tracker_url = tracker_url or None
                include: list[str] = []
                exclude: list[str] = []

                is_subs = "BASE_SUBS" in output_filename
                is_base = output_filename in {"BASE", "BASE_SUBS"}
                creation_filelist = list(meta.filelist)
                if is_subs and meta.subtitle_files:
                    creation_filelist.extend(meta.subtitle_files)

                # A single-file release must use its parent as the creation root
                # when external subtitles are requested; otherwise neither torf nor
                # mkbrr can discover sibling subtitle files.
                if is_subs and Path(path).is_file():
                    path = Path(path).parent

                if meta.category not in ("MOVIE", "TV"):
                    # Music releases always keep their folder, including
                    # one-track singles (e.g. Orpheus rejects folderless music).
                    if meta.isdir and len(meta.filelist) == 1 and not meta.keep_folder and meta.category != "MUSIC":
                        path = meta.filelist[0]
                elif not meta.is_disc:
                    if meta.keep_folder:
                        logger.info("--keep-folder was specified. Preserving the root folder for torrent creation.")
                    # specific nfo catch for certain trackers. BASE catch should prevent unintentional inclusion by default
                    if meta.keep_nfo and "BASE" not in output_filename:
                        logger.info("--keep-nfo was specified. Including NFO files in torrent.")
                        include = ["*.mkv", "*.mp4", "*.ts", "*.nfo"]
                        exclude = ["*.*", "*sample.mkv"]
                        meta.mkbrr = False
                    elif len(creation_filelist) == 1 and not (meta.keep_folder or meta.tv_pack or is_subs):
                        path = creation_filelist[0]
                    elif Path(path).is_dir():
                        root = Path(path).absolute()
                        for file in creation_filelist:
                            try:
                                relative_file = Path(file).absolute().relative_to(root)
                            except ValueError:
                                logger.warning(f"[yellow]Selected file is outside torrent root and will be skipped: {file}")
                                continue
                            # torf matches paths including the torrent's root name.
                            include.append(glob.escape((Path(root.name) / relative_file).as_posix()))
                        exclude = ["*", "*/**"]

                if meta.is_disc:
                    exclude.extend(DISC_EXCLUDE_GLOBS)
                    if output_filename == "BASE":
                        exclude.extend(f"*{extension}" for extension in SUBTITLE_EXTENSIONS)

                # Calculate initial size
                def calculate_size() -> int:
                    size = 0
                    if Path(path).is_file():
                        size = Path(path).stat().st_size
                    elif Path(path).is_dir():
                        for root, _dirs, files in os.walk(path):
                            size += sum((Path(root) / f).stat().st_size for f in files if (Path(root) / f).is_file())
                    return size

                initial_size = await asyncio.to_thread(calculate_size)

                # If using mkbrr, run the external application
                if meta.mkbrr:
                    try:
                        # Validate input path to prevent potential command injection
                        if not Path(path).exists():
                            raise ValueError(f"Path does not exist: {path}")
                        mkbrr_binary = cls.get_mkbrr_path(meta)
                        # Validate mkbrr binary exists and is executable
                        if not Path(mkbrr_binary).exists():
                            raise FileNotFoundError(f"mkbrr binary not found: {mkbrr_binary}")
                        if is_base:
                            output_path = Path(meta.base_dir) / "tmp" / meta.uuid / "torrents" / ".staging" / f"{output_filename}.torrent"
                            output_path.parent.mkdir(parents=True, exist_ok=True)
                        else:
                            output_path = Path(meta.base_dir) / "tmp" / meta.uuid / f"{output_filename}.torrent"

                        # Ensure executable permission for non-Windows systems
                        if not sys.platform.startswith("win"):
                            with contextlib.suppress(Exception):
                                Path(mkbrr_binary).chmod(0o700)

                        cmd = [mkbrr_binary, "create", os.fspath(path)]

                        if tracker_url:
                            cmd.extend(["-t", tracker_url])

                        if meta.randomized >= 1:
                            cmd.extend(["-e"])

                        if "HDBITS" in meta.trackers:
                            power = max(16, hdbits_piece_size(initial_size).bit_length() - 1)
                            cmd.extend(["-l", str(power)])
                        elif piece_size and not tracker_url:
                            try:
                                max_size_bytes = piece_size * 1024 * 1024

                                # Calculate the appropriate power of 2 (log2)
                                # We want the largest power of 2 that's less than or equal to max_size_bytes
                                power = min(27, max(16, math.floor(math.log2(max_size_bytes))))

                                cmd.extend(["-l", str(power)])
                                logger.info(f"[yellow]Setting mkbrr piece length to 2^{power} ({(2**power) / (1024 * 1024):.2f} MiB)")
                            except ValueError, TypeError:
                                logger.warning("[yellow]Warning: Invalid max_piece_size value, using default piece length")

                        if not piece_size and not tracker_url and not any(tracker in meta.trackers for tracker in ["HDBITS", "PASSTHEPOPCORN"]):
                            cmd.extend(["-m", "27"])

                        if meta.mkbrr_threads != "0":
                            cmd.extend(["--workers", str(meta.mkbrr_threads)])

                        if not meta.is_disc and meta.category in ("MOVIE", "TV"):
                            exclude_str = cls.build_mkbrr_exclude_string(str(path), creation_filelist, allow_subs=is_subs)
                            cmd.extend(["--exclude", exclude_str])
                        elif meta.is_disc:
                            cmd.extend(["--exclude", ",".join(exclude)])

                        cmd.extend(["-o", str(output_path)])
                        logger.debug(f"[cyan]mkbrr cmd: {cmd}")

                        # Run mkbrr subprocess in thread to avoid blocking
                        def run_mkbrr() -> int:
                            # mkbrr prints UTF-8 file names; the Windows locale codec (cp1252) cannot read them.
                            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", bufsize=1)  # noqa: S603

                            if process.stdout is None:
                                return process.wait()

                            total_pieces = 100  # Default to 100% for scaling progress
                            pieces_done = 0
                            mkbrr_start_time = time.time()

                            with progress_display(
                                TextColumn("[progress.description]{task.description}"),
                                BarColumn(),
                                TaskProgressColumn(),
                                console=console,
                                transient=False,
                                disable=has_progress_callback(),
                            ) as progress:
                                task = progress.add_task("mkbrr hashing...", total=total_pieces)
                                publish_progress("mkbrr-hash", "mkbrr hashing...", current=0, total=total_pieces, detail="Starting mkbrr hashing")

                                for line in process.stdout:
                                    line = line.strip()

                                    # Detect hashing progress, speed, and percentage
                                    match = re.search(r"Hashing pieces.*?\[(\d+(?:\.\d+)? (?:G|M)(?:B|iB)/s)\]\s+(\d+)%", line)
                                    if match:
                                        speed = match.group(1)  # Extract speed (e.g., "1.7 GiB/s")
                                        pieces_done = int(match.group(2))  # Extract percentage (e.g., "14")

                                        # Try to extract the ETA directly if it's in the format [elapsed:remaining]
                                        eta_match = re.search(r"\[(\d+)s:(\d+)s\]", line)
                                        if eta_match:
                                            eta_seconds = int(eta_match.group(2))
                                            eta = time.strftime("%M:%S", time.gmtime(eta_seconds))
                                        else:
                                            # Fallback to calculating ETA if not directly available
                                            elapsed_time = time.time() - mkbrr_start_time
                                            if pieces_done > 0:
                                                estimated_total_time = elapsed_time / (pieces_done / 100)
                                                eta_seconds = int(max(0.0, estimated_total_time - elapsed_time))
                                                eta = time.strftime("%M:%S", time.gmtime(eta_seconds))
                                            else:
                                                eta = "--:--"  # Placeholder if we can't estimate yet

                                        progress.update(task, description=f"mkbrr hashing... {speed} | ETA: {eta}", completed=pieces_done)
                                        publish_progress(
                                            "mkbrr-hash",
                                            "mkbrr hashing...",
                                            current=pieces_done,
                                            total=total_pieces,
                                            detail=f"{speed} | ETA: {eta}",
                                        )

                                    # Detect final output line
                                    if "Wrote" in line and ".torrent" in line and meta.debug:
                                        logger.info(f"[bold cyan]{line}")  # Print the final torrent file creation message

                                result = process.wait()
                                if result == 0 and Path(output_path).exists():
                                    progress.update(task, completed=total_pieces)
                                    complete_progress("mkbrr-hash", "mkbrr hashing...", current=total_pieces, total=total_pieces)
                                else:
                                    failure_detail = f"Expected torrent file {output_path} was not created" if result == 0 else f"mkbrr exited with status code {result}"
                                    publish_progress(
                                        "mkbrr-hash",
                                        "mkbrr hashing...",
                                        current=pieces_done,
                                        total=total_pieces,
                                        detail=failure_detail,
                                        status="failed",
                                    )
                                return result

                        async with resource_slot("torrent-hash", "torrent hashing"):
                            result = await asyncio.to_thread(run_mkbrr)

                        # Verify the torrent was actually created
                        if result != 0:
                            logger.info(f"[bold red]mkbrr exited with non-zero status code: {result}")
                            raise RuntimeError(f"mkbrr exited with status code {result}")

                        if not Path(output_path).exists():
                            logger.info("[bold red]mkbrr did not create a torrent file!")
                            raise FileNotFoundError(f"Expected torrent file {output_path} was not created")
                        if is_base:
                            manifest = TorrentManifest(meta.base_dir, meta.uuid)
                            entry = manifest.register(output_path, "base_subs" if is_subs else "base", "generated", make_default=make_default)
                            output_path.unlink(missing_ok=True)
                            await record_event_async("artifact", service="torrent", operation="created", outcome="success", category="base")
                            return str(manifest.entry_path(entry))
                        await record_event_async("artifact", service="torrent", operation="created", outcome="success", category="tracker")
                        return output_path

                    except subprocess.CalledProcessError as e:
                        logger.info(f"[bold red]Error creating torrent with mkbrr: {e}")
                        logger.info("[yellow]Falling back to CustomTorrent method")
                        meta.mkbrr = False
                    except Exception as e:
                        logger.info(f"[bold red]Error using mkbrr: {e!s}")
                        logger.info("[yellow]Falling back to CustomTorrent method")
                        meta.mkbrr = False
                overall_start_time = time.time()

                piece_size = cls.calculate_piece_size(initial_size, 32768, 134217728, meta, piece_size=piece_size)

                # Fallback to CustomTorrent if mkbrr is not used
                torrent = CustomTorrent(
                    meta=meta,
                    path=path,
                    trackers=["https://fake.tracker"],
                    source="UA",
                    private=True,
                    exclude_globs=exclude,
                    include_globs=include,
                    creation_date=datetime.now(UTC),
                    comment=f"{meta.ua_name} (fork)",
                    created_by=f"{meta.ua_name} (fork)",
                    piece_size=piece_size,
                )
                progress_id = f"torrent-hash-{meta.uuid}"
                progress_label = f"Hashing {output_filename} torrent"
                torrent._webui_progress_id = progress_id
                torrent._webui_progress_label = progress_label
                publish_progress(progress_id, progress_label, current=0, total=1, detail="Starting torrent hash", group="media", unit="pieces")

                # Run torrent generation in thread to avoid blocking the event loop
                staging_path = (
                    Path(meta.base_dir) / "tmp" / meta.uuid / "torrents" / ".staging" / f"{output_filename}.torrent"
                    if is_base
                    else Path(meta.base_dir) / "tmp" / meta.uuid / f"{output_filename}.torrent"
                )
                staging_path.parent.mkdir(parents=True, exist_ok=True)

                def generate_torrent() -> None:
                    torrent.generate(callback=cls.torf_cb, interval=5)
                    torrent.write(staging_path, overwrite=True)
                    torrent.verify_filesize(path)

                try:
                    async with resource_slot("torrent-hash", "torrent hashing"):
                        await asyncio.to_thread(generate_torrent)
                except Exception as error:
                    publish_progress(progress_id, progress_label, detail=str(error), status="failed", group="media", unit="pieces")
                    raise

                total_elapsed_time = time.time() - overall_start_time
                formatted_time = time.strftime("%H:%M:%S", time.gmtime(total_elapsed_time))

                torrent_file_size = staging_path.stat().st_size / 1024
                logger.debug("")
                logger.debug(f"[bold green]torrent created in {formatted_time}")
                logger.debug(f"[green]Torrent file size: {torrent_file_size:.2f} KB")
                complete_progress(progress_id, progress_label, current=1, total=1, detail="Torrent created", group="media", unit="pieces")
                if is_base:
                    manifest = TorrentManifest(meta.base_dir, meta.uuid)
                    entry = manifest.register(staging_path, "base_subs" if is_subs else "base", "generated", make_default=make_default)
                    staging_path.unlink(missing_ok=True)
                    await record_event_async("artifact", service="torrent", operation="created", outcome="success", category="base")
                    return str(manifest.entry_path(entry))
                await record_event_async("artifact", service="torrent", operation="created", outcome="success", category="tracker")
                return torrent
            finally:
                cls._create_torrent_inflight -= 1
                logger.debug(f"[cyan]create_torrent end | in-flight={cls._create_torrent_inflight}[/cyan]")

    @staticmethod
    def torf_cb(torrent: Torrent, _filepath: str, pieces_done: int, pieces_total: int) -> None:
        if pieces_done == 0:
            TorrentCreator._torf_start_time = time.time()  # Reset start time when hashing starts

        elapsed_time = time.time() - TorrentCreator._torf_start_time

        # Calculate percentage done
        percentage_done = (pieces_done / pieces_total) * 100 if pieces_total > 0 else 0.0

        # Estimate ETA (if at least one piece is done)
        if pieces_done > 0 and pieces_total > 0:
            estimated_total_time = elapsed_time / (pieces_done / pieces_total)
            eta_seconds = max(0.0, estimated_total_time - elapsed_time)
            eta = time.strftime("%M:%S", time.gmtime(eta_seconds))
        else:
            eta = "--:--"

        # Calculate hashing speed (MB/s)
        if elapsed_time > 0 and pieces_done > 0:
            piece_size_bytes = torrent.piece_size or 0
            piece_size = piece_size_bytes / (1024 * 1024)
            speed = (pieces_done * piece_size) / elapsed_time
            speed_str = f"{speed:.2f} MB/s"
        else:
            speed_str = "-- MB/s"

        # Display progress with percentage, speed, and ETA
        if not has_progress_callback() and not is_cli_progress_suppressed():
            cli_ui.info_progress(f"Hashing... {speed_str} | ETA: {eta}", int(percentage_done), 100)
        progress_id = getattr(torrent, "_webui_progress_id", "torrent-hash")
        progress_label = getattr(torrent, "_webui_progress_label", "Hashing torrent")
        publish_progress(
            progress_id,
            progress_label,
            current=pieces_done,
            total=pieces_total or 1,
            detail=f"{speed_str} | ETA: {eta}",
            group="media",
            unit="pieces",
        )

    @staticmethod
    def create_random_torrents(base_dir: str, uuid: str, num: int | str, path: str) -> None:
        manual_name = re.sub(r"[^0-9a-zA-Z\[\]\'\-]+", ".", Path(path).name)
        base_path = TorrentManifest(base_dir, uuid).default_path()
        if base_path is None:
            raise FileNotFoundError("No base torrent is registered in the torrent manifest")
        base_torrent = Torrent.read(base_path)
        for i in range(1, int(num) + 1):
            new_torrent = base_torrent
            new_torrent.metainfo["info"]["entropy"] = random.randint(1, 999999)  # type: ignore  # nosec B311  # noqa: S311
            Torrent.copy(new_torrent).write(f"{base_dir}{'/' + 'tmp' + '/'}{uuid}/[RAND-{i}]{manual_name}.torrent", overwrite=True)
            record_event("artifact", service="torrent", operation="created", outcome="success", category="randomized")

    @staticmethod
    async def create_base_from_existing_torrent(torrentpath: str, base_dir: str, uuid: str, source_size: int = 0) -> str | None:
        if Path(torrentpath).exists():
            base_torrent = Torrent.read(torrentpath)
            has_subs = any(Path(str(f)).suffix.lower() in SUBTITLE_EXTENSIONS for f in base_torrent.files)
            manifest = TorrentManifest(base_dir, uuid)
            entry = manifest.register(torrentpath, "base_subs" if has_subs else "base", "client")
            await record_event_async(
                "artifact",
                service="torrent",
                operation="reused",
                outcome="success",
                category="base",
                bytes_count=source_size,
            )
            return str(manifest.entry_path(entry))
        return None

    @staticmethod
    def get_mkbrr_path(meta: Meta) -> str:
        """Determine the correct mkbrr binary based on OS and architecture."""
        if configured := configured_binary("mkbrr_path"):
            return configured
        existing_binary = MkbrrBinaryManager.find_existing_binary(CODE_DIR) or MkbrrBinaryManager.find_existing_binary(meta.base_dir)
        if existing_binary:
            return existing_binary

        base_dir = Path(meta.base_dir) / "bin" / "mkbrr"

        # Detect OS & Architecture
        system = platform.system().lower()
        arch = platform.machine().lower()

        if system == "windows":
            if arch in {"x86_64", "amd64", "arm64", "aarch64"}:
                # Windows ARM currently uses the x86_64 mkbrr build via Windows emulation.
                binary_path = Path(base_dir) / "windows" / "x86_64" / "mkbrr.exe"
            else:
                raise Exception("Unsupported Windows architecture")
        elif system == "darwin":
            binary_path = Path(base_dir) / "macos" / "arm64" / "mkbrr" if "arm" in arch else Path(base_dir) / "macos" / "x86_64" / "mkbrr"
        elif system == "linux":
            if "x86_64" in arch:
                binary_path = Path(base_dir) / "linux" / "amd64" / "mkbrr"
            elif "armv6" in arch:
                binary_path = Path(base_dir) / "linux" / "armv6" / "mkbrr"
            elif "arm" in arch:
                binary_path = Path(base_dir) / "linux" / "arm" / "mkbrr"
            elif "aarch64" in arch or "arm64" in arch:
                binary_path = Path(base_dir) / "linux" / "arm64" / "mkbrr"
            else:
                raise Exception("Unsupported Linux architecture")
        else:
            raise Exception("Unsupported OS")

        if not Path(binary_path).exists():
            raise FileNotFoundError(f"mkbrr binary not found: {binary_path}")

        return str(binary_path)


def build_mkbrr_exclude_string(root_folder: str, filelist: Sequence[str], allow_subs: bool = False) -> str:
    return TorrentCreator.build_mkbrr_exclude_string(root_folder, filelist, allow_subs)


async def create_torrent(
    meta: Meta,
    path: str | os.PathLike[str],
    output_filename: str,
    tracker_url: str | None = None,
    piece_size: int = 0,
    make_default: bool = False,
) -> str | Torrent:
    return await TorrentCreator.create_torrent(
        meta=meta,
        path=path,
        output_filename=output_filename,
        tracker_url=tracker_url,
        piece_size=piece_size,
        make_default=make_default,
    )


def torf_cb(torrent: Torrent, filepath: str, pieces_done: int, pieces_total: int) -> None:
    TorrentCreator.torf_cb(torrent, filepath, pieces_done, pieces_total)


def create_random_torrents(base_dir: str, uuid: str, num: int | str, path: str) -> None:
    TorrentCreator.create_random_torrents(base_dir, uuid, num, path)


async def create_base_from_existing_torrent(torrentpath: str, base_dir: str, uuid: str, source_size: int = 0) -> str | None:
    return await TorrentCreator.create_base_from_existing_torrent(torrentpath, base_dir, uuid, source_size)


def get_mkbrr_path(meta: Meta) -> str:
    return TorrentCreator.get_mkbrr_path(meta)
