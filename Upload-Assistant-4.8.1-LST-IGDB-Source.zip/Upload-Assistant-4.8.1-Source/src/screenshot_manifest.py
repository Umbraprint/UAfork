"""UUID-addressed local screenshot inventory.

Screenshot filenames are implementation details.  Consumers select a capture
group (main video, disc, or playlist) from this manifest instead of deriving
meaning from a filename.
"""

import json
import threading
import uuid
from pathlib import Path
from typing import Any

from src.temp_paths import release_temp_dir, screenshots_dir

_locks: dict[str, threading.RLock] = {}
_locks_guard = threading.Lock()


def _lock(base_dir: str | Path | None, release_id: str) -> threading.RLock:
    key = str(_path(base_dir, release_id).resolve()).casefold()
    with _locks_guard:
        return _locks.setdefault(key, threading.RLock())


def _path(base_dir: str | Path | None, release_id: str) -> Path:
    return release_temp_dir(base_dir, release_id) / "screenshot_manifest.json"


def _load(base_dir: str | Path, release_id: str) -> dict[str, Any]:
    try:
        value = json.loads(_path(base_dir, release_id).read_text(encoding="utf-8"))
    except OSError, json.JSONDecodeError:
        value = {}
    return value if isinstance(value, dict) else {}


def _save(base_dir: str | Path, release_id: str, value: dict[str, Any]) -> None:
    output = _path(base_dir, release_id)
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, indent=2), encoding="utf-8")
    temporary.replace(output)


def register(
    base_dir: str | Path,
    release_id: str,
    paths: list[str | Path],
    group: str,
    *,
    timestamps: dict[str, float] | None = None,
    slot_timestamps: dict[str, float] | None = None,
    pages: dict[str, int] | None = None,
) -> list[Path]:
    """Publish capture files under UUID names and return their new paths."""
    with _lock(base_dir, release_id):
        manifest = _load(base_dir, release_id)
        entries = manifest.setdefault("screenshots", {})
        if not isinstance(entries, dict):
            entries = manifest["screenshots"] = {}
        result: list[Path] = []
        for value in paths:
            source = Path(value)
            if not source.is_file():
                continue
            screenshot_id = uuid.uuid4().hex
            suffix = source.suffix.lower() or ".png"
            target = source.with_name(f"{screenshot_id}{suffix}")
            while target.exists():
                screenshot_id = uuid.uuid4().hex
                target = source.with_name(f"{screenshot_id}{suffix}")
            source.replace(target)
            entries[screenshot_id] = {"file": target.name, "group": group}
            if timestamps is not None and str(source) in timestamps:
                entries[screenshot_id]["timestamp"] = timestamps[str(source)]
            if slot_timestamps is not None and str(source) in slot_timestamps:
                entries[screenshot_id]["slot_timestamp"] = slot_timestamps[str(source)]
            if pages is not None and str(source) in pages:
                entries[screenshot_id]["page"] = pages[str(source)]
            result.append(target)
        _save(base_dir, release_id, manifest)
        return result


def files(base_dir: str | Path, release_id: str, group: str | None = None) -> list[Path]:
    """Return active screenshots in registration order, optionally by group."""
    directory = screenshots_dir(base_dir, release_id)
    entries = _load(base_dir, release_id).get("screenshots", {})
    if not isinstance(entries, dict):
        return []
    result = []
    for screenshot_id, value in entries.items():
        if not isinstance(value, dict) or (group is not None and value.get("group") != group):
            continue
        path = directory / str(value.get("file", f"{screenshot_id}.png"))
        if path.is_file():
            result.append(path)
    return result


def capture_timestamps(base_dir: str | Path, release_id: str, group: str, *, original_slots: bool = False) -> list[float]:
    """Return active capture times, optionally preferring original sampling slots."""
    directory = screenshots_dir(base_dir, release_id)
    entries = _load(base_dir, release_id).get("screenshots", {})
    if not isinstance(entries, dict):
        return []
    result = []
    for value in entries.values():
        if not isinstance(value, dict) or value.get("group") != group:
            continue
        timestamp = value.get("slot_timestamp", value.get("timestamp")) if original_slots else value.get("timestamp")
        if isinstance(timestamp, (int, float)) and (directory / str(value.get("file", ""))).is_file():
            result.append(float(timestamp))
    return result


def capture_pages(base_dir: str | Path, release_id: str, group: str) -> set[int]:
    """Return the book pages behind the active screenshots of one group."""
    directory = screenshots_dir(base_dir, release_id)
    entries = _load(base_dir, release_id).get("screenshots", {})
    if not isinstance(entries, dict):
        return set()
    return {
        value["page"]
        for value in entries.values()
        if isinstance(value, dict) and value.get("group") == group and isinstance(value.get("page"), int) and (directory / str(value.get("file", ""))).is_file()
    }


def set_page(base_dir: str | Path, release_id: str, path: Path, page: int) -> None:
    """Record the book page now shown by an existing screenshot file."""
    with _lock(base_dir, release_id):
        manifest = _load(base_dir, release_id)
        entries = manifest.get("screenshots")
        if not isinstance(entries, dict):
            return
        for value in entries.values():
            if isinstance(value, dict) and value.get("file") == path.name:
                value["page"] = page
        _save(base_dir, release_id, manifest)


def clear_group(base_dir: str | Path, release_id: str, group: str) -> None:
    """Delete the active files and manifest entries for one capture group."""
    with _lock(base_dir, release_id):
        manifest = _load(base_dir, release_id)
        entries = manifest.get("screenshots")
        if not isinstance(entries, dict):
            return
        directory = screenshots_dir(base_dir, release_id)
        for screenshot_id, value in list(entries.items()):
            if not isinstance(value, dict) or value.get("group") != group:
                continue
            path = directory / str(value.get("file", f"{screenshot_id}.png"))
            path.unlink(missing_ok=True)
            entries.pop(screenshot_id)
        _save(base_dir, release_id, manifest)


def group_for(base_dir: str | Path, release_id: str, path: Path) -> str:
    """Return the logical capture group for a local screenshot."""
    entries = _load(base_dir, release_id).get("screenshots", {})
    if isinstance(entries, dict):
        for value in entries.values():
            if isinstance(value, dict) and value.get("file") == path.name:
                group = value.get("group")
                if isinstance(group, str) and group:
                    return group
    return "main"


def forget_file(base_dir: str | Path, release_id: str, path: Path) -> None:
    """Remove a transient capture entry after it has been atomically moved."""
    with _lock(base_dir, release_id):
        manifest = _load(base_dir, release_id)
        entries = manifest.get("screenshots")
        if not isinstance(entries, dict):
            return
        for screenshot_id, value in list(entries.items()):
            if isinstance(value, dict) and value.get("file") == path.name:
                entries.pop(screenshot_id)
        _save(base_dir, release_id, manifest)
