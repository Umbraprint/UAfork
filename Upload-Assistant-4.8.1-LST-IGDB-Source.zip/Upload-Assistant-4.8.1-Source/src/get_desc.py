# Upload Assistant © 2025 Audionut & wastaken7 — Licensed under UAPL v1.0
import asyncio
import contextlib
import html
import json
import math
import os
import re
import urllib.parse
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation
from pathlib import Path
from typing import Any, ClassVar, cast
from urllib.parse import ParseResult, urlsplit

import aiofiles
import httpx
import langcodes
from bs4 import BeautifulSoup, Comment, NavigableString, Tag
from jinja2 import Template
from langcodes.tag_parser import LanguageTagError

from src.audible import build_audible_author_url, resolve_audible_url
from src.bbcode import BBCODE
from src.bluray_com import ensure_release_subheader
from src.cogs.redaction import PathAwareEncoder
from src.console import logger
from src.description_languages import COMMON_LABELS, GAME_LABELS, MUSIC_LABELS, get_book_labels, get_labels
from src.description_review import apply_saved_draft
from src.languages import languages_manager
from src.mediainfo import MediaInfo
from src.meta import Meta
from src.music.analyzer import RIPPER_LOG_RE, read_rip_log
from src.screenshot_manifest import files as manifest_files
from src.takescreens import TakeScreensManager
from src.tracker_images import get_tracker_image_collection, has_tracker_image_collection
from src.trackers.common import Common
from src.uploadscreens import UploadScreensManager


def html_to_bbcode(text: str) -> str:
    """Convert HTML tags to BBCode format."""
    if not text:
        return text

    # Clean up <br> tags adjacent to list item tags to prevent empty lines
    text = re.sub(r"<br\s*/?>\s*</li>", "</li>", text, flags=re.IGNORECASE)
    text = re.sub(r"<li>\s*<br\s*/?>", "<li>", text, flags=re.IGNORECASE)

    # Define HTML to BBCode tag mappings
    html_bbcode_map = [
        (r"<b>(.*?)</b>", r"[b]\1[/b]"),
        (r"<i>(.*?)</i>", r"[i]\1[/i]"),
        (r"<u>(.*?)</u>", r"[u]\1[/u]"),
        (r"<s>(.*?)</s>", r"[s]\1[/s]"),
        (r"<em>(.*?)</em>", r"[i]\1[/i]"),
        (r"<strong>(.*?)</strong>", r"[b]\1[/b]"),
        (r"<strike>(.*?)</strike>", r"[s]\1[/s]"),
        (r"<del>(.*?)</del>", r"[s]\1[/s]"),
        (r"<br\s*/?>", r"\n"),
        (r"<br>", r"\n"),
        (r"<p>(.*?)</p>", r"\1\n"),
        (r"<li>(.*?)</li>", r"* \1\n"),
        (r"<li>", r"* "),
        (r"</li>", r"\n"),
        (r"<ul[^>]*>", r""),
        (r"</ul>", r""),
    ]

    converted_text = text
    for html_pattern, bbcode_replacement in html_bbcode_map:
        converted_text = re.sub(html_pattern, bbcode_replacement, converted_text, flags=re.IGNORECASE | re.DOTALL)

    # Strip any residual HTML tags
    return re.sub(r"<[^>]+>", "", converted_text)


def _clean_game_requirements(value: str) -> str:
    """Convert a Steam requirements block to clean BBCode."""
    cleaned = html.unescape(html_to_bbcode(value))
    cleaned = re.sub(r"<[^>]+>", "", cleaned).strip()
    return re.sub(
        r"^\[b\](?:Minimum|Recommended|Mínimo|Mínimos|Recomendado|Recomendados):?\[/b\]\s*",
        "",
        cleaned,
        flags=re.IGNORECASE,
    )


def _parse_game_requirement_items(value: str) -> list[tuple[str, str, str]]:
    """Return normalized key, display label, and value for each Steam requirement."""
    cleaned = _clean_game_requirements(value)
    if not cleaned:
        return []

    items: list[list[str]] = []
    unlabeled_count = 0
    label_counts: dict[str, int] = {}
    item_pattern = re.compile(r"^\[b\](?P<label>.+?)(?::\s*)?\[/b\]\s*:?[ \t]*(?P<value>.*)$", re.IGNORECASE)

    for raw_line in cleaned.splitlines():
        is_list_item = bool(re.match(r"^\s*\*\s*", raw_line))
        line = re.sub(r"^\s*\*\s*", "", raw_line).strip()
        if not line:
            continue
        match = item_pattern.match(line)
        if match:
            label = _safe_game_field(match.group("label").rstrip(":").replace("*", "")).strip()
            item_value = match.group("value").strip()
            base_key = label.casefold()
            occurrence = label_counts.get(base_key, 0)
            label_counts[base_key] = occurrence + 1
            key = f"label:{base_key}:{occurrence}"
            items.append([key, label or "-", item_value or "-"])
        elif is_list_item or not items:
            items.append([f"unlabeled:{unlabeled_count}", "-", line])
            unlabeled_count += 1
        else:
            items[-1][2] = f"{items[-1][2]}\n{line}"

    if not items:
        return [("details", "-", cleaned)]
    return [(key, label, item_value) for key, label, item_value in items]


def _safe_game_field(value: Any) -> str:
    text = re.sub(r"<[^>]+>", "", html.unescape(str(value or ""))).strip()
    return " ".join(text.replace("[", "").replace("]", "").split())


def _clean_description_text(value: Any) -> str:
    """Remove serialization escapes that may be returned in synopsis text."""
    text = str(value or "").strip()

    # Some providers return the complete synopsis as a JSON string literal.
    if len(text) >= 2 and text[0] == text[-1] == '"':
        try:
            decoded = json.loads(text)
        except json.JSONDecodeError, TypeError:
            pass
        else:
            if isinstance(decoded, str):
                text = decoded.strip()

    text = html.unescape(text)

    # Handle partially escaped payloads as well (for example, ``\\"text\\"``).
    return text.replace(r"\"", '"').replace(r"\/", "/")


def _book_overview_to_bbcode(value: str) -> str:
    """Preserve useful HTML formatting in book synopses from any source."""
    soup = BeautifulSoup(_clean_description_text(value), "html.parser")

    def render(node: Any) -> str:
        if isinstance(node, Comment):
            return ""
        if isinstance(node, NavigableString):
            return str(node)
        if not isinstance(node, Tag) or node.name in {"script", "style", "template", "img"}:
            return ""
        if node.name == "br":
            return "\n"
        content = "".join(render(child) for child in node.children)
        inline_tags = {"b": "b", "strong": "b", "i": "i", "em": "i", "u": "u", "s": "s", "strike": "s", "del": "s"}
        if node.name in inline_tags and content.strip():
            tag = inline_tags[node.name]
            return f"[{tag}]{content}[/{tag}]"
        if node.name == "a":
            href = _safe_game_url(node.get("href"))
            return f"[url={href}]{content}[/url]" if href and content.strip() else content
        if node.name == "li":
            return f"* {content.strip()}\n"
        if node.name in {"p", "div", "ul", "ol"}:
            return f"{content.strip()}\n\n"
        if node.name in {"h1", "h2", "h3", "h4", "h5", "h6"} and content.strip():
            return f"[b]{content.strip()}[/b]\n\n"
        if node.name == "blockquote" and content.strip():
            return f"[quote]{content.strip()}[/quote]\n\n"
        return content

    converted = "".join(render(child) for child in soup.contents)
    return re.sub(r"\n{3,}", "\n\n", converted).strip()


def _safe_game_url(value: Any) -> str:
    url = str(value or "").strip()
    parsed = urllib.parse.urlparse(url)
    return url if parsed.scheme in {"http", "https"} and parsed.netloc and not any(char in url for char in "[]\r\n") else ""


def _format_game_duration(seconds: Any) -> str:
    if not isinstance(seconds, int) or seconds <= 0:
        return ""
    hours, remainder = divmod(seconds, 3600)
    minutes = remainder // 60
    if hours and minutes:
        return f"{hours}h {minutes}m"
    if hours:
        return f"{hours}h"
    return f"{minutes}m"


async def gen_desc(
    meta: Meta,
    _takescreens_manager: TakeScreensManager,
    _uploadscreens_manager: UploadScreensManager,
) -> Meta:
    apply_saved_draft(meta)

    def clean_text(text: str) -> str:
        return text.replace("\r\n", "\n").strip()

    description_link = meta.description_link
    description_file = meta.description_file
    description_inline = meta.description_inline
    scene_nfo = False
    bhd_nfo = False

    description_lines: list[str] = []
    content_written = False

    base_dir = meta.base_dir
    uuid = meta.uuid
    specified_dir = Path(base_dir) / "tmp" / uuid
    source_dir = Path(meta.path or "")

    if meta.description_override:
        description_lines.append(clean_text(meta.description_override))
        content_written = True
    elif meta.description_template:
        try:
            template_path = f"{meta.base_dir}/data/templates/{meta.description_template}.txt"
            async with aiofiles.open(template_path, encoding="utf-8") as f:
                template = Template(await f.read())
            template_desc = template.render(meta)
            cleaned_content = clean_text(template_desc)
            if cleaned_content:
                if len(template_desc) > 0:
                    description_lines.append(cleaned_content)
                    meta.description_template_content = cleaned_content
                content_written = True
        except FileNotFoundError:
            logger.info(f"[ERROR] Template '{meta.description_template}' not found.")

    if description_inline and not content_written:
        cleaned_content = clean_text(description_inline)
        if cleaned_content:
            description_lines.append(cleaned_content)
            content_written = True
    if meta.nfo:
        logger.debug(f"specified_dir_path: {specified_dir}")
        logger.debug(f"sourcedir_path: {source_dir}")
        if "auto_nfo" in meta and meta.auto_nfo is True:
            nfo_files = sorted(str(p) for p in specified_dir.glob("*.nfo"))
            scene_nfo = True
        elif "bhd_nfo" in meta and meta.bhd_nfo is True:
            nfo_files = sorted(str(p) for p in specified_dir.glob("*.nfo"))
            bhd_nfo = True
        else:
            nfo_files = sorted(str(p) for p in source_dir.glob("*.nfo"))
        if not nfo_files:
            logger.info("NFO was set but no nfo file was found")
            if not content_written:
                description_lines.append("")
            meta.description = "\n".join(description_lines).strip()
            meta.saved_description = bool(meta.description)
            return meta

        if nfo_files:
            nfo = nfo_files[0]
            try:
                async with aiofiles.open(nfo, encoding="utf-8") as nfo_file:
                    nfo_content = await nfo_file.read()
                logger.debug("NFO content read with utf-8 encoding.")
            except UnicodeDecodeError:
                logger.debug("utf-8 decoding failed, trying latin1.")
                async with aiofiles.open(nfo, encoding="latin1") as nfo_file:
                    nfo_content = await nfo_file.read()

            if not content_written:
                if scene_nfo is True:
                    description_lines.append(f"[center][spoiler=Scene NFO:][code]{nfo_content}[/code][/spoiler][/center]")
                elif bhd_nfo is True:
                    description_lines.append(f"[center][spoiler=FraMeSToR NFO:][code]{nfo_content}[/code][/spoiler][/center]")
                else:
                    description_lines.append(f"[code]{nfo_content}[/code]")

                content_written = True

            nfo_content_utf8 = nfo_content.encode("utf-8", "ignore").decode("utf-8")
            meta.description_nfo_content = nfo_content_utf8

    if description_link:
        try:
            parsed: ParseResult = urllib.parse.urlparse(description_link.replace("/raw/", "/") or "")
            split = os.path.split(parsed.path)
            raw = parsed._replace(path=f"{split[0]}/raw/{split[1]}" if split[0] != "/" else f"/raw{parsed.path}")
            raw_url = urllib.parse.urlunparse(raw)
            async with httpx.AsyncClient(timeout=20.0) as client:
                response = await client.get(raw_url)
            description_link_content = response.text
            cleaned_content = clean_text(description_link_content)
            if cleaned_content and "Not Found" not in cleaned_content:
                if not content_written:
                    description_lines.append(cleaned_content)
                meta.description_link_content = cleaned_content
                content_written = True
            elif cleaned_content and "Not Found" in cleaned_content:
                logger.error("Description link returned 'Not Found'")
        except Exception as e:
            logger.info(f"[ERROR] Failed to fetch description from link: {e}")
            raise e

    if description_file and Path(description_file).is_file():
        async with aiofiles.open(description_file, encoding="utf-8") as f:
            file_content = await f.read()
        cleaned_content = clean_text(file_content)
        if cleaned_content:
            if not content_written:
                description_lines.append(cleaned_content)
            meta.description_file_content = cleaned_content
            content_written = True

    if not content_written:
        description_text = meta.description.strip() if meta.description else ""
        if description_text:
            description_lines.append(description_text)
            content_written = True

    if not meta.skip_gen_desc and not content_written:
        description_text = meta.description.strip() if meta.description else ""
        if description_text:
            description_lines = [description_text]
            content_written = True

    meta.description = "\n".join(description_lines).strip()
    meta.saved_description = bool(meta.description)

    if meta.description in ("None", "", " "):
        meta.description = ""

    return meta


class DescriptionBuilder:
    def __init__(self, tracker: str, config: dict[str, Any], language: str = "en"):
        self.config: dict[str, Any] = config
        self.common = Common(config)
        self.tracker: str = tracker
        self.language = language
        self.takescreens_manager = TakeScreensManager(config)
        self.uploadscreens_manager = UploadScreensManager(config)

        trackers_config = self.config.get("TRACKERS")
        if not isinstance(trackers_config, dict):
            raise KeyError("Missing 'TRACKERS' section in config")
        trackers_config_map = cast(dict[str, Any], trackers_config)

        tracker_cfg = trackers_config_map.get(tracker)
        if tracker_cfg is None:
            available = list(trackers_config_map.keys())
            raise KeyError(f"Missing tracker config for '{tracker}'; available trackers: {available}")

        self.tracker_config: dict[str, Any] = cast(dict[str, Any], tracker_cfg) if isinstance(tracker_cfg, dict) else {}
        self.parser = self.common.parser

    def _get_bool_config(self, key: str, default: bool = False, meta: Meta | None = None) -> bool:
        """Helper to get a boolean config value safely. Falls back to DEFAULT or default if invalid/empty."""
        val = self._get_tag_override(key, meta)
        if val is None:
            val = self.tracker_config.get(key)
            if val is None or val == "":
                val = self.config["DEFAULT"].get(key, default)

        if isinstance(val, bool):
            return val
        if isinstance(val, str):
            val_lower = val.lower().strip()
            if val_lower in ("true", "1", "yes", "on"):
                return True
            if val_lower in ("false", "0", "no", "off", ""):
                return False
        try:
            return bool(int(val))
        except ValueError, TypeError:
            return default

    def _get_int_config(self, key: str, default: Any = 0, meta: Meta | None = None) -> int:
        """Helper to get an integer config value safely. Falls back to DEFAULT or default if invalid/empty."""
        val = self._get_tag_override(key, meta)
        if val is None:
            val = self.tracker_config.get(key)
            if val is None or val == "":
                val = self.config["DEFAULT"].get(key, default)

        try:
            return int(val)
        except ValueError, TypeError:
            try:
                return int(default)
            except ValueError, TypeError:
                return 0

    def _get_tag_override(self, key: str, meta: Meta | None) -> Any:
        """Return a tag-specific value, preserving false and zero overrides."""
        tag_value = getattr(meta, "tag", "")
        if not tag_value:
            return None

        tag = str(tag_value).strip().lstrip("-").casefold()
        if not tag:
            return None

        default_config = self.config.get("DEFAULT", {})
        config_sources = (self.tracker_config, default_config)
        for config_source in config_sources:
            if not isinstance(config_source, dict):
                continue
            tag_overrides = config_source.get("tag_overrides", {})
            if not isinstance(tag_overrides, dict):
                continue
            for configured_tag, overrides in tag_overrides.items():
                if str(configured_tag).strip().lstrip("-").casefold() != tag or not isinstance(overrides, dict):
                    continue
                if key in overrides and overrides[key] is not None:
                    return overrides[key]

        return None

    def _get_str_config(self, key: str, default: str = "", meta: Meta | None = None) -> str:
        """Get a string config value, optionally overridden by the release group tag."""
        tag_override = self._get_tag_override(key, meta)
        if tag_override is not None:
            return str(tag_override)
        if key in self.tracker_config:
            val = self.tracker_config[key]
            if val is not None:
                return str(val)
        val = self.config["DEFAULT"].get(key, default)
        return str(val) if val is not None else default

    async def get_custom_header(self, meta: Meta) -> str:
        """Returns a custom header if configured."""
        try:
            custom_description_header = self._get_str_config("custom_description_header", "", meta)
            if custom_description_header:
                return custom_description_header
        except Exception as e:
            logger.warning(f"[yellow]Warning: Error setting custom description header: {e!s}[/yellow]")

        return ""

    async def get_tonemapped_header(self, meta: Meta) -> str:
        try:
            tonemapped_description_header = self._get_str_config("tonemapped_header", "", meta)
            if tonemapped_description_header and meta.tonemapped:
                return tonemapped_description_header
        except Exception as e:
            logger.warning(f"[yellow]Warning: Error setting tonemapped header: {e!s}[/yellow]")
        return ""

    def _header_candidates(self, key: str, meta: Meta, *legacy: str) -> tuple[str, ...]:
        """Header spellings an imported description can carry: tag override, tracker
        override, DEFAULT and legacy literals. Markup-bearing only (a bare word is
        indistinguishable from prose), longest first, deterministic tie-break."""
        candidates = set(legacy)
        tag_override = self._get_tag_override(key, meta)
        if tag_override is not None:
            candidates.add(str(tag_override))
        for source in (self.tracker_config, self.config["DEFAULT"]):
            value = source.get(key)
            if value is not None:
                candidates.add(str(value))
        return self._markup_blocks(candidates)

    @staticmethod
    def _markup_blocks(blocks: Any) -> tuple[str, ...]:
        """Markup-bearing, stripped, longest first, deterministic tie-break."""
        return tuple(sorted({block.strip() for block in blocks if "[" in block}, key=lambda block: (-len(block), block)))

    @staticmethod
    def _block_regex(blocks: tuple[str, ...]) -> str:
        """Match any block anchored to whitespace, a bracket or a string edge, loose whitespace between tokens."""
        alternatives = "|".join("(?:" + r"\s*".join(re.escape(token) for token in block.split()) + ")" for block in blocks)
        return r"(?:^|(?<=[\s\]]))(?:" + alternatives + r")(?=[\s\[]|$)"

    def _tonemapped_header_candidates(self, meta: Meta) -> tuple[str, ...]:
        # uploads made before a config change carry this exact spelling
        return self._header_candidates("tonemapped_header", meta, "[center][code] Screenshots have been tonemapped for reference [/code][/center]")

    def _strip_tonemapped_header(self, text: str, meta: Meta, *, replacing: bool) -> str:
        """Collapse duplicated tonemapped headers in an imported description.

        ``clean_unit3d_description`` keeps plain BBCode, so an imported header
        survives and ``get_tonemapped_header`` may append another. Leave one copy
        when nothing is re-added, none when it is. One pass over the original text
        only (re-scanning a splice could eat body text), anchored to whitespace,
        a bracket or a string edge, loose whitespace between tokens.
        """
        try:
            headers = self._tonemapped_header_candidates(meta)
        except Exception as e:
            logger.warning(f"[yellow]Warning: Error reading tonemapped header: {e!s}[/yellow]")
            return text
        pattern = re.compile(self._block_regex(headers), re.IGNORECASE)
        keep = 0 if replacing else 1
        matches = list(pattern.finditer(text))
        pieces = []
        cursor = 0
        for match in matches[keep:]:
            pieces.append(text[cursor : match.start()])
            cursor = match.end()
        pieces.append(text[cursor:])
        return "".join(pieces)

    # Image-section headers with their code defaults and example-config spellings.
    _IMAGE_SECTION_HEADERS: ClassVar[dict[str, tuple[str, ...]]] = {
        "screenshot_header": ("[h2]Screenshots[/h2]",),
        "disc_menu_header": ("[h2]Disc Menu Screenshots[/h2]",),
        "audio_spectrogram_header": ("[center][b]Audio Spectrogram[/b][/center]", "[h2]Audio Spectrogram[/h2]"),
        "dynamic_hdr_plot_header": ("[center][b]Dynamic HDR Metadata[/b][/center]", "[h2]Dynamic HDR Metadata[/h2]"),
    }
    # A header still introduces images when, past opening layout tags, an image, link or comparison follows.
    _SECTION_IMAGES = r"\s*(?:\[(?:center|left|right|align|spoiler|hide|size|b|u|i)\b[^\]]*\]\s*)*\[(?:img|url|comparison)\b"

    @staticmethod
    def _collapse_removed(text: str, removed: str) -> str:
        """Close the gap left by each removal, keeping at most one blank line."""
        return re.sub(rf"\s*{removed}(?:\s*{removed})*\s*", lambda match: "\n" * min(2, match.group(0).count("\n")) or " ", text).strip()

    def _strip_orphan_section_headers(self, text: str, meta: Meta) -> str:
        """Remove generated image-section headers left without their images.

        The import cleaners extract images into the image list, so a header from an
        imported UA upload is left above nothing while this run renders its own.
        A header still followed by images is kept.
        """
        try:
            headers = self._markup_blocks(header for key, legacy in self._IMAGE_SECTION_HEADERS.items() for header in self._header_candidates(key, meta, *legacy))
        except Exception as e:
            logger.warning(f"[yellow]Warning: Error reading image section headers: {e!s}[/yellow]")
            return text
        if not headers:
            return text
        pattern = re.compile(rf"{self._block_regex(headers)}(?!{self._SECTION_IMAGES})", re.IGNORECASE)
        stripped, count = pattern.subn("\x00", text)
        return self._collapse_removed(stripped, "\x00") if count else text

    def _strip_regenerated_parts(self, text: str, parts: list[str]) -> str:
        """Remove copies of sections this run renders again, such as the custom header,
        language lines, episode overview and signature carried by an imported UA upload."""
        blocks = self._markup_blocks(part for part in parts if part.strip())
        if not blocks:
            return text
        stripped, count = re.subn(self._block_regex(blocks), "\x00", text, flags=re.IGNORECASE)
        return self._collapse_removed(stripped, "\x00") if count else text

    @staticmethod
    def _strip_plain_text_edges(text: str, header: str, signature: str) -> str:
        """Remove a plain-text custom header or signature rendered again. Without markup it
        cannot be told from prose, so only a whole first or last line is removed."""
        stripped = text
        header, signature = header.strip(), signature.strip()
        if header and "[" not in header:
            stripped = re.sub(rf"^\s*{re.escape(header)}[ \t]*(?:\n|$)", "", stripped, count=1)
        if signature and "[" not in signature:
            stripped = re.sub(rf"(?:^|\n)[ \t]*{re.escape(signature)}\s*$", "", stripped, count=1)
        return stripped.strip() if stripped != text else text

    def _clean_imported_description(
        self,
        text: str,
        meta: Meta,
        regenerated_parts: list[str],
        *,
        replacing_tonemapped_header: bool,
        custom_header: str = "",
        custom_signature: str = "",
    ) -> str:
        """Remove what UA itself generated from a description imported from another upload."""
        text = self._strip_tonemapped_header(text, meta, replacing=replacing_tonemapped_header)
        text = self._strip_regenerated_parts(text, regenerated_parts)
        text = self._strip_orphan_section_headers(text, meta)
        return self._strip_plain_text_edges(text, custom_header, custom_signature)

    async def get_logo_section(self, meta: Meta) -> tuple[str, str]:
        """Returns the logo URL and size if applicable."""
        logo, logo_size = "", ""
        try:
            if not self._get_bool_config("add_logo", False, meta):
                return logo, logo_size

            if self.tracker in ("BJSHARE", "ANTHELION", "GREATPOSTERWALL", "BRASILTRACKER", "FUNFILE", "HDSPACE", "HDTORRENTS", "SPEEDAPP"):
                logo_resize_url = meta.tmdb_logo
                if logo_resize_url:
                    if logo_resize_url.endswith(".svg"):
                        logo_resize_url = logo_resize_url.replace(".svg", ".png")
                    logo = f"https://image.tmdb.org/t/p/w300/{logo_resize_url}"
                    logo_size = "300"
                    return logo, logo_size

            logo = meta.logo
            logo_size = str(self._get_int_config("logo_size", 300, meta))

            if logo:
                return logo, logo_size
        except Exception as e:
            logger.warning(f"[yellow]Warning: Error getting logo section: {e!s}[/yellow]")

        return logo, logo_size

    async def get_tv_info(self, meta: Meta) -> tuple[str, str]:
        title: str = ""
        overview: str = ""
        try:
            if not self._get_bool_config("episode_overview", False, meta) or meta.category != "TV":
                return title, overview

            if self.tracker in ("CAPYBARABR", "BJSHARE", "BRASILTRACKER", "LOCADORA", "SAMARITANO"):
                episode_tmdb_data = meta.episode_tmdb_data
                title = episode_tmdb_data.get("name", "")
                overview = episode_tmdb_data.get("overview", "")
                if overview:
                    overview = _clean_description_text(html_to_bbcode(str(overview)))
                return title, overview

            tvmaze_episode_data = meta.tvmaze_episode_data

            season_name = tvmaze_episode_data.get("season_name", "") or meta.tvdb_season_name
            season_number = meta.season
            episode_number = meta.episode
            overview = tvmaze_episode_data.get("overview", "") or meta.overview_meta

            # Convert HTML tags to BBCode
            if overview:
                overview = html_to_bbcode(overview)
                overview = _clean_description_text(overview)

            episode_name = tvmaze_episode_data.get("episode_name", "")
            episode_title = meta.auto_episode_title or (episode_name if (not episode_name.lower().startswith("episode") and "tba" not in episode_name.lower()) else "")

            title = ""
            if season_name:
                title = f"{season_name}"
                if season_number:
                    title += f" - {season_number}{episode_number}"

            if episode_title:
                if title:
                    title += ": "
                title += f"{episode_title}"

        except Exception as e:
            logger.warning(f"[yellow]Warning: Error getting TV info: {e!s}[/yellow]")

        return title, overview

    async def get_mediainfo_section(self, meta: Meta) -> str:
        """Returns the mediainfo section, using a cache file if available."""
        if meta.is_disc == "BDMV" or meta.category in ("GAME", "BOOK", "MUSIC"):
            return ""

        if self._get_bool_config("full_mediainfo", True, meta) or meta.is_disc:
            mi_path = f"{meta.base_dir}{'/' + 'tmp' + '/'}{meta.uuid}/MEDIAINFO_CLEANPATH.txt"
            if await self.common.path_exists(mi_path):
                async with aiofiles.open(mi_path, encoding="utf-8") as mi:
                    return await mi.read()

        cache_file_dir = Path(meta.base_dir) / "tmp" / meta.uuid
        cache_file_path = Path(cache_file_dir) / "MEDIAINFO_SHORT.txt"

        file_exists = Path(cache_file_path).exists()
        file_size = Path(cache_file_path).stat().st_size if file_exists else 0

        if file_exists and file_size > 0:
            with contextlib.suppress(Exception):
                async with aiofiles.open(cache_file_path, encoding="utf-8") as f:
                    return await f.read()

        video_file = meta.filelist[0]

        if meta.mediainfo:
            media_info_content = self.format_short_mediainfo_json(meta.mediainfo, video_file)
            if media_info_content:
                with contextlib.suppress(Exception):
                    await self.common.makedirs(str(cache_file_dir))
                    async with aiofiles.open(cache_file_path, mode="w", encoding="utf-8") as f:
                        await f.write(media_info_content)
                return media_info_content

        return ""

    @staticmethod
    def format_short_mediainfo_json(mediainfo: dict[str, Any] | None, video_file: str = "") -> str:
        """Render the short MediaInfo section from meta.mediainfo."""
        if not mediainfo:
            return ""
        raw_tracks = mediainfo.get("media", {}).get("track", [])
        if not isinstance(raw_tracks, list):
            return ""
        tracks = [track for track in raw_tracks if isinstance(track, dict)]

        def value(track: dict[str, Any], key: str) -> str:
            field = track.get(key, "")
            return field.strip() if isinstance(field, str) else ""

        def format_duration(seconds: str) -> str:
            try:
                milliseconds = int((Decimal(seconds) * 1000).to_integral_value(rounding=ROUND_HALF_UP))
            except InvalidOperation, ValueError:
                return ""
            hours, milliseconds = divmod(milliseconds, 3_600_000)
            minutes, milliseconds = divmod(milliseconds, 60_000)
            seconds, milliseconds = divmod(milliseconds, 1000)
            return f"{hours:02}:{minutes:02}:{seconds:02}.{milliseconds:03}"

        def format_size(bytes_value: str) -> str:
            try:
                gibibytes = Decimal(bytes_value) / (1024**3)
            except InvalidOperation:
                return ""
            precision = ".1f" if gibibytes >= 10 else ".2f"
            return f"{gibibytes:{precision}} GiB"

        def format_bitrate(bits_per_second: str) -> str:
            try:
                bitrate = Decimal(bits_per_second)
            except InvalidOperation:
                return ""
            if bitrate >= 10_000_000:
                return f"{bitrate / 1_000_000:.1f} Mb/s"
            return f"{int((bitrate / 1000).to_integral_value(rounding=ROUND_HALF_UP)):,}".replace(",", " ") + " kb/s"

        def format_sampling_rate(hertz: str) -> str:
            try:
                return f"{Decimal(hertz) / 1000:.1f} kHz"
            except InvalidOperation:
                return ""

        def language_name(language: str) -> str:
            if not language:
                return ""
            try:
                parsed = langcodes.Language.get(language)
                name = parsed.language_name("en")
                return f"{name} ({parsed.territory})" if parsed.territory else name
            except LanguageTagError:
                return language

        general = next((track for track in tracks if value(track, "@type") == "General"), None)
        if general is None:
            return ""

        filename = Path(value(general, "CompleteName") or video_file).stem
        output = [
            filename,
            "",
            "---GENERAL----",
            f"Size...........: {format_size(value(general, 'FileSize'))}",
            f"Container......: {value(general, 'Format')}",
            f"Duration.......: {format_duration(value(general, 'Duration'))}",
            "",
        ]

        for video in (track for track in tracks if value(track, "@type") == "Video"):
            codec = value(video, "Format")
            codec += ", " + value(video, "Encoded_Library") if value(video, "Encoded_Library") else ""
            codec += ", " + value(video, "HDR_Format_String") if value(video, "HDR_Format_String") else ""
            codec += ", " + value(video, "transfer_characteristics") if value(video, "transfer_characteristics") else ""
            output.extend(
                [
                    "---VIDEO----",
                    f"Codec..........: {codec}",
                    f"Resolution.....: {value(video, 'Width')}x{value(video, 'Height')}",
                    f"Bit rate.......: {format_bitrate(value(video, 'BitRate'))}",
                    f"Frame rate.....: {value(video, 'FrameRate')} fps",
                    "",
                ]
            )

        for audio in (track for track in tracks if value(track, "@type") == "Audio"):
            title = value(audio, "Title")
            output.extend(
                [
                    "---AUDIO----",
                    f"Format.........: {value(audio, 'Format_Commercial_IfAny') or value(audio, 'Format')}",
                    f"Channels.......: {value(audio, 'Channels')} channel{'s' if value(audio, 'Channels') != '1' else ''}",
                    f"Sample rate....: {format_sampling_rate(value(audio, 'SamplingRate'))}",
                    f"Bit rate.......: {format_bitrate(value(audio, 'BitRate'))}",
                    f"Language.......: {language_name(value(audio, 'Language'))}{f' ({title})' if title else ''}",
                    "",
                ]
            )

        for index, text in enumerate(track for track in tracks if value(track, "@type") == "Text"):
            if index == 0:
                output.append("---SUBTITLES---")
            title = value(text, "Title")
            output.append(f"Language.......: {language_name(value(text, 'Language'))}{f' ({title})' if title else ''}, {value(text, 'Format')}")

        return "\n".join(output).rstrip() + "\n"

    async def get_bdinfo_section(self, meta: Meta) -> str:
        """Returns the bdinfo section if applicable."""
        try:
            if meta.is_disc == "BDMV":
                bdinfo_sections: list[str] = []
                if meta.discs:
                    for disc in meta.discs:
                        file_info = disc.get("summary", "")
                        if file_info:
                            bdinfo_sections.append(file_info)
                return "\n\n".join(bdinfo_sections)
        except Exception as e:
            logger.warning(f"[yellow]Warning: Error getting bdinfo section: {e!s}[/yellow]")

        return ""

    async def screenshot_header(self, meta: Meta) -> str:
        """Returns the screenshot header if applicable."""
        try:
            screenheader = self._get_str_config("screenshot_header", "", meta)
            if screenheader:
                return screenheader
        except Exception as e:
            logger.warning(f"[yellow]Warning: Error getting screenshot header: {e!s}[/yellow]")

        return ""

    async def menu_screenshot_header(self, meta: Meta) -> str:
        """Returns the screenshot header for menus if applicable."""
        try:
            menu_images = get_tracker_image_collection(meta, self.tracker, "menu_images")
            if meta.is_disc and menu_images:
                disc_menu_header = self._get_str_config("disc_menu_header", "", meta)
                if disc_menu_header:
                    return disc_menu_header
        except Exception as e:
            logger.warning(f"[yellow]Warning: Error getting menus screenshot header: {e!s}[/yellow]")

        return ""

    async def get_user_description(self, meta: Meta) -> str:
        """Returns the user-provided description (file or link)"""
        try:
            if meta.description_override:
                return ""
            description_file_content = meta.description_file_content.strip()
            description_link_content = meta.description_link_content.strip()

            if description_file_content or description_link_content:
                if description_file_content:
                    return description_file_content
                if description_link_content:
                    return description_link_content
        except Exception as e:
            logger.warning(f"[yellow]Warning: Error getting user description: {e!s}[/yellow]")

        return ""

    async def get_custom_signature(self, meta: Meta) -> str:
        custom_signature: str = ""
        try:
            custom_signature = self._get_str_config("custom_signature", "", meta)
        except Exception as e:
            logger.warning(f"[yellow]Warning: Error setting custom signature: {e!s}[/yellow]")

        return custom_signature

    def format_bluray_link(self, url: str, label: str) -> str:
        if self.tracker == "IMMORTALSEED":
            return f"{label} — {url}" if label else url
        if self.tracker == "TORRENTLEECH":
            return f'<a href="{html.escape(url, quote=True)}">{html.escape(label)}</a>' if label else url
        if not label:
            return f"[url]{url}[/url]"
        # The subheader is text, not tracker BBCode.
        safe_label = label.replace("[", "&#91;").replace("]", "&#93;")
        return f"[url={url}]{safe_label}[/url]"

    async def get_bluray_section(self, meta: Meta) -> tuple[str, str]:
        release_url: str = ""
        cover_list: list[str] = []
        cover_images: str = ""

        try:
            cover_size = self._get_int_config("bluray_image_size", 250, meta)
            bluray_link = self._get_bool_config("add_bluray_link", False, meta)

            if meta.is_disc in ["BDMV", "DVD"] and bluray_link and meta.release_url:
                release_url = meta.release_url
                await ensure_release_subheader(meta)

            cover_data = meta.hosted_artwork
            if not cover_data and await self.common.path_exists(f"{meta.base_dir}{'/' + 'tmp' + '/'}{meta.uuid}/covers.json"):
                try:
                    async with aiofiles.open(f"{meta.base_dir}{'/' + 'tmp' + '/'}{meta.uuid}/covers.json", encoding="utf-8") as f:
                        cover_data = json.loads(await f.read())
                except Exception:
                    cover_data = None

            use_bluray_images = self._get_bool_config("use_bluray_images", False, meta)
            if meta.is_disc in ["BDMV", "DVD"] and use_bluray_images and cover_data:
                for img_data in cover_data:
                    web_url = img_data.get("web_url", "")
                    raw_url = img_data.get("raw_url", "")

                    if self.tracker == "TORRENTLEECH":
                        cover_list.append(f"""<a href="{web_url}"><img src="{raw_url}" style="max-width: {cover_size}px;"></a>  """)
                    elif self.tracker == "HDTORRENTS":
                        cover_list.append(f"<a href='{raw_url}'><img src='{web_url}' height=137></a> ")
                    else:
                        cover_list.append(f"[url={web_url}][img={cover_size}]{raw_url}[/img][/url]")

            if cover_list:
                cover_images = "".join(cover_list)

        except Exception as e:
            logger.warning(f"[yellow]Warning: Error getting bluray section: {e!s}[/yellow]")

        return release_url, cover_images

    async def get_audio_spectrogram_section(self, meta: Meta) -> str:
        """Returns the audio spectrogram section if applicable."""
        try:
            add_audio_spectrogram = self._get_bool_config("add_audio_spectrogram", False, meta)
            add_spec = meta.audio_spectrogram or meta.audio_spectrogram_tracks or add_audio_spectrogram
            if not add_spec:
                return ""

            spectrograms_images = get_tracker_image_collection(meta, self.tracker, "spectrograms_images")
            if not spectrograms_images:
                return ""
            audio_spectrogram_header = self._get_str_config("audio_spectrogram_header", "[center][b]Audio Spectrogram[/b][/center]", meta)
            desc_parts: list[str] = [audio_spectrogram_header] if audio_spectrogram_header is not None else []
            desc_parts.append("\n[center]")
            screens_per_row = await self.get_screens_per_row(meta)
            for img_index, spec_img in enumerate(spectrograms_images):
                if isinstance(spec_img, dict):
                    web_url = spec_img.get("web_url")
                    raw_url = spec_img.get("raw_url")
                    img_url = spec_img.get("img_url", raw_url) or ""
                    if web_url and raw_url:
                        desc_parts.append(self.format_screenshot(web_url, raw_url, img_url, meta=meta))
                        self._append_screenshot_row_separator(desc_parts, img_index, screens_per_row)
            desc_parts.append("[/center]\n")
            return "".join(desc_parts)
        except Exception as e:
            logger.warning(f"[yellow]Warning: Error getting audio spectrogram section: {e!s}[/yellow]")
        return ""

    async def get_dynamic_hdr_plot_section(self, meta: Meta) -> str:
        """Return Dolby Vision/HDR10+ dynamic metadata plots, when enabled."""
        if not (meta.dynamic_hdr_plot or self._get_bool_config("add_dynamic_hdr_plot", False, meta)):
            return ""
        plot_images = get_tracker_image_collection(meta, self.tracker, "dynamic_hdr_plot_images")
        if not plot_images:
            return ""
        header = self._get_str_config("dynamic_hdr_plot_header", "[center][b]Dynamic HDR Metadata[/b][/center]", meta)
        desc_parts: list[str] = [header] if header is not None else []
        desc_parts.append("\n[center]")
        for image in plot_images:
            if not isinstance(image, dict):
                continue
            web_url = image.get("web_url")
            raw_url = image.get("raw_url")
            img_url = image.get("img_url", raw_url) or ""
            if web_url and raw_url:
                desc_parts.append(self.format_screenshot(web_url, raw_url, img_url, meta=meta))
                desc_parts.append("\n")
        desc_parts.append("[/center]\n")
        return "".join(desc_parts)

    def _build_book_desc_section(self, meta: Meta, table: bool = True, underline: bool = False, bullet: str = "") -> str:
        """Build the BBCode table or list for BOOK-category uploads."""
        if self.tracker in ("TORRENTLEECH", "IMMORTALSEED", "IPTORRENTS", "SPEEDAPP"):
            table = False

        header = "[h2]"
        header_end = "[/h2]"

        asin = meta.asin
        author = meta.author
        book_translator = meta.book_translator
        edition = meta.edition
        isbn = meta.isbn
        narrator = meta.narrator
        overview = meta.overview
        publisher = meta.publisher
        year = str(meta.year) if meta.year is not None else ""

        labels = get_book_labels(self.language)
        str_asin = "ASIN"
        str_author = labels["author"]
        str_avg_bitrate = labels["average_bitrate"]
        str_book_translator = labels["book_translator"]
        str_duration = labels["duration"]
        str_edition = labels["edition"]
        str_isbn = "ISBN"
        str_narrator = labels["narrator"]
        str_overview = labels["overview"]
        str_publisher = labels["publisher"]
        str_service = labels["service"]
        str_technical_details = labels["technical_details"]
        str_year = labels["year"]

        if overview:
            overview = _book_overview_to_bbcode(overview)

        audible_url = ""
        if asin:
            with contextlib.suppress(ValueError):
                audible_url = resolve_audible_url(
                    asin,
                    explicit_url=meta.audible_url,
                    domain=self.config.get("DEFAULT", {}).get("audible_domain", ""),
                )

        # Collect key-value pairs
        fields: list[tuple[str, str]] = []
        if author:
            author_display = author
            audible_authors = meta.audible_authors
            author_names = [item["name"] for item in audible_authors if item.get("name")]
            if meta.audiobook and audible_url and author_names and author in (author_names[0], ", ".join(author_names)):
                try:
                    domain = (urlsplit(audible_url).hostname or "").removeprefix("www.")
                    author_display = ", ".join(
                        f"[url={build_audible_author_url(item['asin'], domain)}]{item['name']}[/url]" if item.get("asin") else item["name"] for item in audible_authors
                    )
                except ValueError, KeyError:
                    pass
            fields.append((str_author, author_display))
        if book_translator:
            fields.append((str_book_translator, book_translator))
        if narrator:
            fields.append((str_narrator, narrator))
        if publisher:
            fields.append((str_publisher, publisher))
        service = meta.service_longname or meta.service
        if service:
            fields.append((str_service, service))
        if isbn:
            fields.append((str_isbn, isbn))
        if asin:
            asin_display = asin
            if audible_url:
                asin_display = f"[url={audible_url}]{asin}[/url]"
            fields.append((str_asin, asin_display))
        if meta.audiobook and meta.audible_rating_average is not None and meta.audible_rating_count:
            score = f"{meta.audible_rating_average:.1f}"
            if self.language == "pt-BR":
                score = score.replace(".", ",")
            rating_display = f"{score}/5 ({meta.audible_rating_count} {labels['audible_ratings']})"
            fields.append((labels["audible_rating"], rating_display))
        if edition:
            fields.append((str_edition, edition))
        if year:
            fields.append((str_year, year))
        if meta.audiobook:
            audiobook_duration_formatted = meta.audiobook_duration_formatted
            avg_bitrate = meta.audiobook_bitrate
            if audiobook_duration_formatted:
                fields.append((str_duration, audiobook_duration_formatted))
            if avg_bitrate:
                fields.append((str_avg_bitrate, f"{avg_bitrate} kbps"))

        if not (fields or overview):
            return ""

        if table:
            final_book_parts: list[str] = []
            if underline:
                header = "[b][u]"
                header_end = "[/u][/b]\n"

            if fields:
                final_book_parts.append(f"{header}{str_technical_details}{header_end}")
                table_lines = ["[table]"]
                for label, val in fields:
                    table_lines.append(f"[tr][td][b]{label}[/b][/td][td]{val}[/td][/tr]")
                table_lines.append("[/table]")
                final_book_parts.append("\n".join(table_lines))

            if meta.epubmeta_output:
                final_book_parts.append(f"[spoiler=EPUB Metadata][code]{meta.epubmeta_output}[/code][/spoiler]")

            if overview:
                final_book_parts.append(f"{header}{str_overview}{header_end}\n{overview}")

            return "\n\n".join(part for part in final_book_parts if part.strip())
        book_parts = []
        prefix = f"{bullet} " if bullet else ""
        for label, val in fields:
            book_parts.append(f"{prefix}[b]{label}:[/b] {val}")

        final_book_parts = []
        if underline:
            header = "[b][u]"
            header_end = "[/u][/b]\n"
        else:
            header = "[h2]"
            header_end = "[/h2]"

        if book_parts:
            final_book_parts.append(f"{header}{str_technical_details}{header_end}" + "\n".join(book_parts))

        if overview:
            final_book_parts.append(f"{header}{str_overview}{header_end}{overview}")

        return "\n\n".join(final_book_parts)

    def _build_game_desc_section(self, meta: Meta, table: bool = True) -> str:
        """Build the beautiful BBCode layout for GAME-category uploads."""
        if meta.category != "GAME":
            return ""

        if self.tracker in ("CZTEAM",):
            table = False

        game_parts: list[str] = []

        header = "[h2]"
        header_end = "[/h2]"

        use_pt_br = self.language == "pt-BR"
        str_technical_details = "Technical Details" if not use_pt_br else "Detalhes Técnicos"
        str_overview = "Overview" if not use_pt_br else "Visão Geral"
        str_platform = "Platform" if not use_pt_br else "Plataforma"
        str_version = "Version" if not use_pt_br else "Versão"
        str_genre = "Genre" if not use_pt_br else "Gênero"
        str_developer = "Developer" if not use_pt_br else "Desenvolvedor"
        str_publisher = "Publisher" if not use_pt_br else "Distribuidora"
        str_system_requirements = "System Requirements" if not use_pt_br else "Requisitos do Sistema"
        str_minimum = "Minimum" if not use_pt_br else "Mínimo"
        str_recommended = "Recommended" if not use_pt_br else "Recomendado"
        str_official_supported_languages = "Officially Supported Languages" if not use_pt_br else "Idiomas Oficialmente Suportados"
        str_language = "Language" if not use_pt_br else "Idioma"
        str_support = "Support" if not use_pt_br else "Suporte"
        game_labels = get_labels(GAME_LABELS, self.language)
        str_technical_details = game_labels["technical_details"]
        str_overview = game_labels["overview"]
        str_platform = game_labels["platform"]
        str_version = game_labels["version"]
        str_genre = game_labels["genre"]
        str_developer = game_labels["developer"]
        str_publisher = game_labels["publisher"]
        str_system_requirements = game_labels["system_requirements"]
        str_minimum = game_labels["minimum"]
        str_recommended = game_labels["recommended"]
        str_official_supported_languages = game_labels["official_supported_languages"]
        str_language = game_labels["language"]
        str_support = game_labels["support"]

        def append_rows_section(title: str, rows: list[tuple[str, str]]) -> None:
            rows = [(label, value) for label, value in rows if value]
            if not rows:
                return
            lines = [f"{header}{title}{header_end}"]
            if table:
                table_lines = ["[table]"]
                table_lines.extend(f"[tr][td][b]{label}[/b][/td][td]{value}[/td][/tr]" for label, value in rows)
                table_lines.append("[/table]")
                lines.append("\n".join(table_lines))
            else:
                lines.extend(f"[b]{label}[/b] {value}" for label, value in rows)
            game_parts.append("\n".join(lines))

        # 1. Technical Details
        fields: list[tuple[str, str]] = []
        if meta.platform:
            fields.append((str_platform, _safe_game_field(meta.platform)))
        release_date = meta.igdb_first_release_date or meta.year
        if release_date:
            fields.append((game_labels["release_date"], _safe_game_field(release_date)))
        if meta.game_version:
            fields.append((str_version, _safe_game_field(meta.game_version)))
        if meta.game_region:
            fields.append((game_labels["region"], _safe_game_field(meta.game_region)))
        if meta.game_release_edition:
            edition = _safe_game_field(meta.game_release_edition)
            if meta.game_release_edition_year:
                edition = f"{edition} ({meta.game_release_edition_year})"
            fields.append((game_labels["edition"], edition))
        if meta.game_release_type:
            fields.append((game_labels["release_type"], _safe_game_field(meta.game_release_type)))
        if meta.game_release_title:
            fields.append((game_labels["release_title"], _safe_game_field(meta.game_release_title)))
        if meta.game_release_scene is not None:
            fields.append((game_labels["scene_release"], game_labels["yes"] if meta.game_release_scene else game_labels["no"]))
        if meta.game_parent_title:
            fields.append((game_labels["parent_game"], _safe_game_field(meta.game_parent_title)))
        if meta.game_type:
            fields.append((game_labels["game_type"], _safe_game_field(meta.game_type)))
        if meta.game_status:
            fields.append((game_labels["status"], _safe_game_field(meta.game_status)))
        if meta.genres:
            fields.append((str_genre, ", ".join(_safe_game_field(value) for value in meta.genres)))
        if meta.game_age_ratings:
            fields.append((game_labels["age_rating"], ", ".join(f"{_safe_game_field(source)}: {_safe_game_field(rating)}" for source, rating in meta.game_age_ratings.items())))
        for label, values in (
            (game_labels["franchise"], meta.game_franchises),
            (game_labels["engine"], meta.game_engines),
            (game_labels["game_modes"], meta.game_modes),
            (game_labels["perspectives"], meta.game_player_perspectives),
            (game_labels["themes"], meta.game_themes),
            (game_labels["features"], meta.game_features),
        ):
            if values:
                fields.append((label, ", ".join(_safe_game_field(value) for value in values)))
        if meta.developer:
            fields.append((str_developer, _safe_game_field(meta.developer)))
        if meta.publisher:
            fields.append((str_publisher, _safe_game_field(meta.publisher)))
        if meta.game_designers:
            fields.append((game_labels["designers"], ", ".join(_safe_game_field(value) for value in meta.game_designers)))
        if meta.game_composers:
            fields.append((game_labels["composers"], ", ".join(_safe_game_field(value) for value in meta.game_composers)))
        steam_url = _safe_game_url(meta.steam_url)
        if steam_url:
            fields.append(("Steam", f"[url={steam_url}]Steam[/url]"))
        official_url = _safe_game_url(meta.game_official_url)
        if official_url:
            fields.append((game_labels["official_site"], f"[url={official_url}]{game_labels['official_site']}[/url]"))
        trailer_url = _safe_game_url(meta.youtube)
        if trailer_url:
            fields.append((game_labels["trailer"], f"[url={trailer_url}]{game_labels['trailer']}[/url]"))

        append_rows_section(str_technical_details, fields)

        # 2. Overview Section
        overview_text = ""
        localized_overviews = meta.localized_overviews
        pt_br_overview = localized_overviews.get("brazilian", "") if isinstance(localized_overviews, dict) else ""
        overview = meta.overview if not use_pt_br else pt_br_overview

        # Strip HTML tags and convert to BBCode if present
        if overview:
            overview = html_to_bbcode(str(overview))
            overview = re.sub(r"<[^>]+>", "", overview).strip()
            overview = _clean_description_text(overview)

        if overview:
            overview_text = f"\n{header}{str_overview}{header_end}\n{overview}\n"

        if overview_text:
            game_parts.append(overview_text)

        rating_rows: list[tuple[str, str]] = []
        if isinstance(meta.game_ratings, dict):
            for source, rating in meta.game_ratings.items():
                if not isinstance(rating, dict):
                    continue
                score = rating.get("score")
                maximum = rating.get("max")
                if isinstance(score, bool) or isinstance(maximum, bool) or not isinstance(score, (int, float)) or not isinstance(maximum, (int, float)) or maximum <= 0:
                    continue
                value = f"{score:g}/{maximum:g}"
                count = rating.get("count")
                if isinstance(count, int) and count >= 0:
                    value += f" ({count:,} {game_labels['votes'].lower()})"
                url = _safe_game_url(rating.get("url"))
                if url:
                    value = f"[url={url}]{value}[/url]"
                rating_rows.append((_safe_game_field(source), value))
        append_rows_section(game_labels["ratings"], rating_rows)

        multiplayer_rows = []
        if isinstance(meta.game_multiplayer_modes, dict):
            multiplayer_rows = [
                (_safe_game_field(platform), ", ".join(_safe_game_field(capability) for capability in capabilities))
                for platform, capabilities in meta.game_multiplayer_modes.items()
                if isinstance(capabilities, list) and capabilities
            ]
        append_rows_section(game_labels["multiplayer"], multiplayer_rows)

        time_rows = []
        if isinstance(meta.game_time_to_beat, dict):
            time_rows = [
                (game_labels[label], _format_game_duration(meta.game_time_to_beat.get(key)))
                for key, label in (("hastily", "main_story"), ("normally", "main_extras"), ("completely", "completionist"))
            ]
        append_rows_section(game_labels["time_to_beat"], time_rows)

        # 3. System Requirements Section
        req_min = meta.requirements_minimum
        req_rec = meta.requirements_recommended

        if req_min or req_rec:
            header_title = f"{str_system_requirements}"
            game_parts.append(f"{header}{header_title}{header_end}")

            col_min_header = f"{str_minimum}"
            col_rec_header = f"{str_recommended}"

            clean_min = _clean_game_requirements(req_min) if req_min else ""
            clean_rec = _clean_game_requirements(req_rec) if req_rec else ""

            if table:
                min_items = _parse_game_requirement_items(req_min) if req_min else []
                rec_items = _parse_game_requirement_items(req_rec) if req_rec else []
                min_by_key = {key: (label, value) for key, label, value in min_items}
                rec_by_key = {key: (label, value) for key, label, value in rec_items}
                row_keys = list(min_by_key)
                row_keys.extend(key for key in rec_by_key if key not in min_by_key)

                table_lines = ["[table]"]
                table_lines.append(f"[tr][td][b]{game_labels['hardware']}[/b][/td][td][b]{col_min_header}[/b][/td][td][b]{col_rec_header}[/b][/td][/tr]")
                for key in row_keys:
                    min_label, min_value = min_by_key.get(key, ("", "-"))
                    rec_label, rec_value = rec_by_key.get(key, ("", "-"))
                    label = min_label or rec_label or "-"
                    table_lines.append(f"[tr][td][b]{label}[/b][/td][td]{min_value}[/td][td]{rec_value}[/td][/tr]")
                table_lines.append("[/table]")
                game_parts.append("\n".join(table_lines))
            else:
                # Simple BBCode format without table
                simple_lines = []
                if clean_min:
                    simple_lines.append(f"[b]{col_min_header}[/b] {clean_min}")
                if clean_rec:
                    simple_lines.append(f"\n[b]{col_rec_header}[/b] {clean_rec}")
                game_parts.append("\n".join(simple_lines))

        # 4. Supported Languages
        languages = meta.languages
        if languages and isinstance(languages, dict):
            support_labels = game_labels["language_support_types"]

            def localized_support(support: Any) -> str:
                cleaned_support = _safe_game_field(support)
                return support_labels.get(cleaned_support.casefold(), cleaned_support)

            if table:
                table_rows = []
                table_rows.append(f"[tr][td][b]{str_language}[/b][/td][td][b]{str_support}[/b][/td][/tr]")

                for lang, support in sorted(languages.items()):
                    lang = (lang or "").strip() or "-"
                    support_str = ", ".join(localized_support(value) for value in support).strip() or "-"

                    table_rows.append(f"[tr][td]{lang}[/td][td]{support_str}[/td][/tr]")

                table_text = "\n".join(table_rows)
                spoiler_str = f"{header}{str_official_supported_languages}{header_end}\n[table]\n{table_text}\n[/table]\n"
                game_parts.append(spoiler_str)
            else:
                # Simple BBCode format without table
                simple_lang_lines = []
                for lang, support in sorted(languages.items()):
                    support_str = ", ".join(localized_support(value) for value in support)
                    simple_lang_lines.append(f"[b]{lang}[/b]: {support_str}")
                simple_section = f"{header}{str_official_supported_languages}{header_end}\n" + "\n".join(simple_lang_lines) + "\n"
                game_parts.append(simple_section)

        return "\n".join(part for part in game_parts if part.strip())

    @staticmethod
    def _build_music_tracklist(tracks: list[Any], labels: dict[str, Any], table: bool = True) -> str:
        """Render the audio files in disc/track order from the release snapshot."""

        def positive_number(value: Any) -> int | None:
            try:
                number = int(value)
            except TypeError, ValueError, OverflowError:
                return None
            return number if number > 0 else None

        ordered = []
        for index, track in enumerate(tracks):
            if not isinstance(track, dict):
                continue
            relative_path = str(track.get("relative_path") or "")
            title = str(track.get("title") or "").strip() or Path(relative_path.replace("\\", "/")).stem
            if not title:
                continue
            disc = positive_number(track.get("disc_number")) or 1
            number = positive_number(track.get("track_number"))
            ordered.append((disc, number, relative_path.casefold(), index, title, track.get("duration")))

        if not ordered:
            return ""
        ordered.sort(key=lambda item: (item[0], item[1] if item[1] is not None else float("inf"), item[2], item[3]))
        multiple_discs = len({item[0] for item in ordered}) > 1
        lines = [f"[h2]{labels['tracklist']}[/h2]"]
        if table:
            lines.extend(
                [
                    "[table]",
                    f"[tr][td][b]{labels['track_number']}[/b][/td][td][b]{labels['title']}[/b][/td][td][b]{labels['duration']}[/b][/td][/tr]",
                ]
            )
        for disc, number, _, _, title, duration in ordered:
            # BBCode needs bracket protection, but HTML escaping turns apostrophes
            # and ampersands into visible entities on some trackers.
            safe_title = title.replace("[", "\uff3b").replace("]", "\uff3d").replace("<", "\u2039").replace(">", "\u203a")
            try:
                seconds = float(duration)
            except TypeError, ValueError, OverflowError:
                seconds = 0
            duration_text = ""
            if 0 < seconds < float("inf"):
                minutes, remainder = divmod(round(seconds), 60)
                duration_text = f"{minutes:02d}:{remainder:02d}"
            track_number = f"{number:02d}" if number is not None else "—"
            if multiple_discs:
                track_number = f"{disc}.{track_number}"
            if table:
                lines.append(f"[tr][td]{track_number}[/td][td]{safe_title}[/td][td]{duration_text}[/td][/tr]")
            else:
                lines.append(f"{track_number}. {safe_title}" + (f" ({duration_text})" if duration_text else ""))
        if table:
            lines.append("[/table]")
        return "\n".join(lines)

    @staticmethod
    def _build_music_rip_logs(release: dict[str, Any], labels: dict[str, Any]) -> str:
        """Render each CD rip log (EAC, XLD, ...) inside its own spoiler and code block."""
        auxiliary = release.get("auxiliary")
        logs = auxiliary.get("logs") if isinstance(auxiliary, dict) else None
        root_value = str(release.get("root") or "")
        if not isinstance(logs, list) or not root_value:
            return ""
        root = Path(root_value).resolve()
        blocks = []
        for relative in cast(list[Any], logs):
            log_path = (root / str(relative)).resolve()
            try:
                # Logs are a few dozen KB; anything far larger is not worth embedding.
                if not log_path.is_relative_to(root) or log_path.stat().st_size > 1_048_576:
                    continue
            except OSError:
                continue
            log_text = read_rip_log(log_path, signature=RIPPER_LOG_RE).replace("\r\n", "\n").replace("\r", "\n").strip()
            if not log_text:
                continue
            # A closing tag inside the log would end the block early; some trackers turn [code] into [pre].
            log_text = re.sub(r"\[(/\s*(?:code|pre|spoiler))", "\N{FULLWIDTH LEFT SQUARE BRACKET}\\1", log_text, flags=re.IGNORECASE)
            name = str(relative).replace("\\", "/").replace("[", "\N{FULLWIDTH LEFT SQUARE BRACKET}").replace("]", "\N{FULLWIDTH RIGHT SQUARE BRACKET}")
            blocks.append(f"[spoiler={name}][code]{log_text}[/code][/spoiler]")
        if not blocks:
            return ""
        return f"[h2]{labels['rip_logs']}[/h2]\n" + "\n".join(blocks)

    @staticmethod
    def _music_cover_url(meta: Meta) -> str:
        """Return the hosted MUSIC cover URL, or a user-supplied public artwork URL."""
        hosted = meta.hosted_artwork[0] if isinstance(meta.hosted_artwork, list) and meta.hosted_artwork else {}
        for candidate in (hosted.get("raw_url") if isinstance(hosted, dict) else "", meta.artwork_url):
            url = str(candidate or "").strip()
            if re.match(r"^https?://\S+$", url, flags=re.IGNORECASE):
                return url
        return ""

    def _build_music_desc_section(self, meta: Meta, table: bool = True) -> str:
        """Build a tracker-neutral BBCode summary for MUSIC-category uploads."""
        if meta.category != "MUSIC" or not isinstance(meta.music_release, dict):
            return ""

        if self.tracker in ("CZTEAM", "TORRENTLEECH", "IMMORTALSEED", "IPTORRENTS", "SPEEDAPP"):
            table = False

        release = meta.music_release
        fields_data = release.get("fields", {})
        tracks = release.get("tracks", [])
        external_ids = release.get("external_ids", {})
        if not isinstance(fields_data, dict):
            fields_data = {}
        if not isinstance(tracks, list):
            tracks = []
        if not isinstance(external_ids, dict):
            external_ids = {}
        if not fields_data and not tracks and not external_ids:
            return ""

        header = "[h2]"
        header_end = "[/h2]"
        use_pt_br = self.language == "pt-BR"

        def value(name: str, fallback: Any = "") -> Any:
            """Return a populated normalized release field or its fallback."""
            item = fields_data.get(name, {})
            if isinstance(item, dict) and item.get("value") not in (None, "", [], {}):
                return item["value"]
            return fallback

        def display(item: Any) -> str:
            """Format a release field for human-readable BBCode output."""
            if isinstance(item, list):
                return ", ".join(str(part) for part in item if str(part).strip())
            return str(item).strip() if item not in (None, "") else ""

        def technical_values(name: str, formatter: Any = str) -> str:
            """Format unique valid technical values from the release tracks."""
            formatted_values: dict[Any, str] = {}
            for track in tracks:
                if not isinstance(track, dict):
                    continue
                item = track.get(name)
                if item in (None, ""):
                    continue
                try:
                    hash(item)
                    formatted = display(formatter(item))
                except TypeError, ValueError, OverflowError:
                    continue
                if formatted:
                    formatted_values[item] = formatted
            return ", ".join(formatted_values[item] for item in sorted(formatted_values, key=str))

        def average_bitrate() -> str:
            """Return the release's average bitrate, weighted by track duration when every track has one."""
            samples: list[tuple[float, float]] = []
            for track in tracks:
                if not isinstance(track, dict):
                    continue
                try:
                    bitrate = float(track.get("bitrate") or 0)
                except TypeError, ValueError, OverflowError:
                    continue
                try:
                    duration = float(track.get("duration") or 0)
                except TypeError, ValueError, OverflowError:
                    duration = 0.0
                if bitrate > 0 and math.isfinite(bitrate):
                    samples.append((bitrate, duration if duration > 0 and math.isfinite(duration) else 0.0))
            if not samples:
                return ""
            total_duration = sum(duration for _, duration in samples)
            if all(duration > 0 for _, duration in samples):
                average = sum(bitrate * duration for bitrate, duration in samples) / total_duration
            else:
                average = sum(bitrate for bitrate, _ in samples) / len(samples)
            return f"{round(average / 1000)} kbps"

        text = {
            "details": "Music Details" if not use_pt_br else "Detalhes da Música",
            "artist": "Artist" if not use_pt_br else "Artista",
            "album": "Album" if not use_pt_br else "Álbum",
            "year": "Original Release Year" if not use_pt_br else "Ano de Lançamento Original",
            "release_year": "Release Year" if not use_pt_br else "Ano desta Edição",
            "edition": "Edition" if not use_pt_br else "Edição",
            "edition_year": "Edition Year" if not use_pt_br else "Ano da Edição",
            "type": "Release Type" if not use_pt_br else "Tipo de Lançamento",
            "media": "Media" if not use_pt_br else "Mídia",
            "label": "Label" if not use_pt_br else "Gravadora",
            "catalogue": "Catalogue Number" if not use_pt_br else "Número de Catálogo",
            "genres": "Genres" if not use_pt_br else "Gêneros",
            "tracks": "Tracks" if not use_pt_br else "Faixas",
            "discs": "Discs" if not use_pt_br else "Discos",
            "format": "Format" if not use_pt_br else "Formato",
            "codec": "Codec",
            "bit_depth": "Bit Depth" if not use_pt_br else "Profundidade de Bits",
            "sample_rate": "Sample Rate" if not use_pt_br else "Taxa de Amostragem",
            "channels": "Channels" if not use_pt_br else "Canais",
            "bitrate": "Bitrate",
            "audio": "Audio" if not use_pt_br else "Áudio",
            "external_ids": "External IDs" if not use_pt_br else "IDs Externos",
        }
        text.update(get_labels(MUSIC_LABELS, self.language))
        external_id_labels = text["external_id_labels"]

        def musicbrainz_link(kind: str, identifier: Any) -> str:
            """Return a safe MusicBrainz BBCode link for a canonical UUID."""
            identifier = str(identifier or "").strip()
            if not re.fullmatch(r"[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}", identifier, re.IGNORECASE):
                return ""
            return f"[url=https://musicbrainz.org/{kind}/{identifier}]{identifier}[/url]"

        def discogs_link(kind: str, identifier: Any) -> str:
            """Return a safe Discogs BBCode link for a known release/master ID."""
            raw_identifier = str(identifier or "").strip()
            match = re.fullmatch(
                rf"(?:https?://(?:www\.)?discogs\.com/)?{kind}(?:/|:)(\d+)(?:-[^/?#]+)?/?(?:[?#].*)?",
                raw_identifier,
                re.IGNORECASE,
            )
            numeric_identifier = match.group(1) if match else raw_identifier if raw_identifier.isdecimal() else ""
            return f"[url=https://www.discogs.com/{kind}/{numeric_identifier}]{numeric_identifier}[/url]" if numeric_identifier else ""

        # The release IDs pin the exact edition; the group/master IDs only stand in when the release ID is unknown.
        musicbrainz_release = musicbrainz_link("release", external_ids.get("musicbrainz_release"))
        discogs_release = discogs_link("release", external_ids.get("discogs_release"))
        external_id_links = [
            (external_id_labels["musicbrainz_release"], musicbrainz_release),
            (external_id_labels["musicbrainz_release_group"], "" if musicbrainz_release else musicbrainz_link("release-group", external_ids.get("musicbrainz_release_group"))),
            (external_id_labels["discogs_release"], discogs_release),
            (external_id_labels["discogs_master"], "" if discogs_release else discogs_link("master", external_ids.get("discogs_master"))),
        ]
        external_id_links = [f"{label}: {link}" for label, link in external_id_links if link]

        # Later years are only worth a row when they differ from an earlier one.
        year = display(value("year", meta.year))
        release_year = display(value("release_year"))
        if release_year == year:
            release_year = ""
        edition_year = display(value("edition_year"))
        if edition_year in (year, release_year):
            edition_year = ""

        try:
            disc_count = int(value("disc_count", 1))
        except TypeError, ValueError:
            disc_count = 1

        # Format, codec, bit depth, sample rate and channels share one row, e.g. "FLAC / 24-bit / 96 kHz / Stereo".
        audio_format = display(value("format", technical_values("format")))
        codec = technical_values("codec")
        if codec and codec.casefold() != audio_format.casefold():
            audio_format = f"{audio_format} ({codec})" if audio_format else codec
        audio = " / ".join(
            part
            for part in (
                audio_format,
                technical_values("bit_depth", lambda item: f"{item}-bit"),
                technical_values("sample_rate", lambda item: f"{int(item) / 1000:g} kHz"),
                technical_values("channels", lambda item: {1: "Mono", 2: "Stereo"}.get(int(item), f"{item} channels")),
            )
            if part
        )

        tracklist = self._build_music_tracklist(tracks, text, table=table)
        rip_logs = self._build_music_rip_logs(release, text)

        music_fields = [
            (text["artist"], display(value("artists", value("artist", meta.artist)))),
            (text["album"], display(value("album", meta.title))),
            (text["year"], year),
            (text["release_year"], release_year),
            (text["edition"], display(value("edition"))),
            (text["edition_year"], edition_year),
            (text["type"], display(value("release_type"))),
            (text["media"], display(value("media", meta.source))),
            (text["label"], display(value("release_label", value("label")))),
            (text["catalogue"], display(value("release_catalogue_number"))),
            (text["genres"], display(value("genres"))),
            # The tracklist below already lists every track.
            (text["tracks"], "" if tracklist else display(value("track_count"))),
            (text["discs"], str(disc_count) if disc_count > 1 else ""),
            (text["audio"], audio),
            (text["bitrate"], average_bitrate()),
            (text["external_ids"], ", ".join(external_id_links) if table else "\n".join(external_id_links)),
        ]
        music_fields = [(label, field_value) for label, field_value in music_fields if field_value]
        if not music_fields:
            return "\n\n".join(part for part in (tracklist, rip_logs) if part)

        # Only these trackers get the hosted cover as a first column beside the details.
        cover_url = self._music_cover_url(meta) if self.tracker in ("ASIANCINEMA", "TORRENTLEECH") else ""

        if table:
            table_lines = ["[table]"]
            table_lines.extend(f"[tr][td][b]{label}[/b][/td][td]{field_value}[/td][/tr]" for label, field_value in music_fields)
            table_lines.append("[/table]")
            body = "\n".join(table_lines)
            if cover_url and "[" not in cover_url and "]" not in cover_url:
                body = f"[table]\n[tr][td][img=250]{cover_url}[/img][/td][td]\n{body}\n[/td][/tr]\n[/table]"
        else:
            body = "\n".join(f"[b]{label}:[/b] {field_value}" for label, field_value in music_fields)
            if cover_url and self.tracker == "TORRENTLEECH":
                # TorrentLeech has no BBCode tables but accepts HTML; keep the markup on one
                # line so the tracker's newline-to-<br> conversion stays inside the cell.
                safe_url = html.escape(cover_url, quote=True)
                body = (
                    f'<table><tr><td style="vertical-align: top; padding-right: 15px;"><img src="{safe_url}" style="max-width: 250px;"></td>'
                    f'<td style="vertical-align: top;">{body}</td></tr></table>'
                )
        return f"{header}{text['details']}{header_end}\n{body}" + "".join(f"\n\n{part}" for part in (tracklist, rip_logs) if part)

    async def general_description_generator(
        self,
        meta: Meta,
        # Section controls
        audio_spectrogram: bool = True,
        bluray: bool = True,
        book: bool = True,
        custom_header: bool = True,
        custom_signature: bool = True,
        description: bool = True,
        game: bool = True,
        languages: bool = True,
        logo: bool = True,
        mediainfo: bool = True,
        menu_screenshots: bool = True,
        nfo: bool = True,
        screenshots: bool = True,
        tonemapped_header: bool = True,
        tv_info: bool = True,
        ua_signature: bool = True,  # ci: ua_signature v4.8
        user_description: bool = True,
        music: bool = True,
        dynamic_hdr_plot: bool = True,
        approved_image_hosts: list[str] | None = None,
        signature: str = "",  # ci: ua_signature v4.8
        desc_header: str = "",
    ) -> str:
        apply_saved_draft(meta)
        image_list = get_tracker_image_collection(meta, self.tracker, "screenshots")
        image_list = cast(list[Any], image_list)

        if image_list is None:
            image_list = []
        if approved_image_hosts is None:
            approved_image_hosts = []
        # get_tracker_image_collection falls back to meta.image_list, so only a real override
        # replaces the base screenshots. It never disables per-file pack screenshots: those
        # upload through allowed_hosts, so a tracker's host policy is honoured either way.
        images = image_list if image_list and has_tracker_image_collection(meta, self.tracker, "screenshots") else meta.image_list
        multi_screens = self._get_int_config("multiScreens", 2, meta)
        if meta.sorted_filelist:
            multi_screens = 0

        desc_parts: list[str] = []

        # Custom Header
        if custom_header:
            if not desc_header:
                desc_header = await self.get_custom_header(meta)
            if desc_header:
                desc_parts.append(desc_header + "\n")

        # Language
        if languages:
            language_labels = get_labels(COMMON_LABELS, self.language)
            try:
                if not meta.language_checked:
                    await languages_manager.process_desc_language(meta, self.tracker)
                if meta.audio_languages and meta.write_audio_languages:
                    desc_parts.append(f"[code]{language_labels['audio_languages']}: {', '.join(meta.audio_languages)}[/code]\n")

                if meta.subtitle_languages and meta.write_subtitle_languages:
                    desc_parts.append(f"[code]{language_labels['subtitle_languages']}: {', '.join(meta.subtitle_languages)}[/code]\n")
                if meta.subtitle_languages and meta.write_hc_languages:
                    desc_parts.append(f"[code]{language_labels['hardcoded_subtitles']}: {', '.join(meta.subtitle_languages)}[/code]\n")
            except Exception as e:
                logger.warning(f"[yellow]Warning: Error processing language: {e!s}[/yellow]")

        # Logo
        if logo:
            logo_url, logo_size = await self.get_logo_section(meta)
            if logo_url and logo_size:
                if self.tracker == "TORRENTLEECH":
                    desc_parts.append(f'<center><img src="{html.escape(logo_url, quote=True)}" width="{logo_size}"></center>\n')
                else:
                    desc_parts.append(f"[center][img={logo_size}]{logo_url}[/img][/center]\n")

        # Mediainfo / BDInfo section for trackers like BJSHARE
        if mediainfo:
            if self.tracker == "BJSHARE":
                if meta.is_disc == "DVD":
                    desc_parts.append(f"[hide=DVD MediaInfo][pre]{await self.get_mediainfo_section(meta)}[/pre][/hide]")
                bd_info = await self.get_bdinfo_section(meta)
                if bd_info:
                    desc_parts.append(f"[hide=BDInfo][pre]{bd_info}[/pre][/hide]")
            elif self.tracker == "DIGITALCORE":
                bd_info = await self.get_bdinfo_section(meta)
                if bd_info:
                    desc_parts.append(bd_info)
            elif self.tracker in ("FUNFILE", "HDSPACE", "IPTORRENTS", "IMMORTALSEED"):
                mediainfo_sec = await self.get_mediainfo_section(meta)
                if mediainfo_sec:
                    desc_parts.append(f"[pre]{mediainfo_sec}[/pre]")
                bd_info = await self.get_bdinfo_section(meta)
                if bd_info:
                    desc_parts.append(f"[pre]{bd_info}[/pre]")
            elif self.tracker == "PTSKIT":
                mediainfo_sec = await self.get_mediainfo_section(meta)
                if mediainfo_sec:
                    desc_parts.append(mediainfo_sec)
                bd_info = await self.get_bdinfo_section(meta)
                if bd_info:
                    desc_parts.append(bd_info)
            elif self.tracker == "HDTORRENTS":
                mediainfo_sec = await self.get_mediainfo_section(meta)
                if mediainfo_sec:
                    desc_parts.append(f"[left][font=consolas]{mediainfo_sec}[/font][/left]")
                bd_info = await self.get_bdinfo_section(meta)
                if bd_info:
                    desc_parts.append(f"[left][font=consolas]{bd_info}[/font][/left]")
            elif self.tracker == "TORRENTLEECH":
                mediainfo_sec = await self.get_mediainfo_section(meta)
                if mediainfo_sec:
                    desc_parts.append(mediainfo_sec)
                bd_info = await self.get_bdinfo_section(meta)
                if bd_info:
                    desc_parts.append(bd_info)
            else:
                pass

        # Blu-ray
        if bluray:
            release_url, cover_images = await self.get_bluray_section(meta)
            if release_url:
                label = meta.release_subheader if meta.release_subheader_url == release_url else ""
                desc_parts.append(f"[center]{self.format_bluray_link(release_url, label)}[/center]")
            if cover_images:
                desc_parts.append(f"[center]{cover_images}[/center]\n")

        # TV
        if tv_info:
            title, episode_overview = await self.get_tv_info(meta)
            if episode_overview:
                if title:
                    desc_parts.append(f"[center]{title}[/center]\n")
                desc_parts.append(f"[center]{episode_overview}[/center]\n")

        # Book details
        if book and meta.category == "BOOK":
            book_section = self._build_book_desc_section(meta)
            if book_section:
                desc_parts.append(book_section)

        # Game details
        if game and meta.category == "GAME":
            game_section = self._build_game_desc_section(meta)
            if game_section:
                desc_parts.append(game_section)

        # Music details
        if music and meta.category == "MUSIC":
            music_section = self._build_music_desc_section(meta)
            if music_section:
                desc_parts.append(music_section)

        if self.tracker == "MTEAM" and meta.mteam_description:
            desc_parts.append(meta.mteam_description)

        if (
            self.tracker
            in {
                "1PTBA",
                "LAJIDUI",
                "LEMONHD",
                "LONGPT",
                "PTCAFE",
                "PTFANS",
                "PTGTK",
                "PTZONE",
                "QINGWA",
                "RAILGUNPT",
                "XINGYUNGEPT",
                "ZMPT",
                "NEXUSPHP",
            }
            and meta.nexusphp_description
        ):
            desc_parts.append(meta.nexusphp_description)

        # Imported UA uploads carry these sections, which this run renders again.
        custom_signature_section = await self.get_custom_signature(meta) if custom_signature else ""
        regenerated_parts = [*desc_parts, custom_signature_section]

        # resolve once: the strip decision must match what is actually appended
        tonemapped_header_text = await self.get_tonemapped_header(meta) if tonemapped_header else ""
        replacing_tonemapped_header = bool(tonemapped_header_text.strip())

        meta_description_value = meta.description
        if isinstance(meta_description_value, str):
            meta_description = meta_description_value
        elif meta_description_value is None:
            meta_description = ""
        else:
            meta_description = str(meta_description_value)

        if meta.auto_nfo and meta.description_nfo_content:
            scene_nfo_block = f"[center][spoiler=Scene NFO:][code]{meta.description_nfo_content}[/code][/spoiler][/center]"
            meta_description = meta_description.replace(scene_nfo_block, "").strip()

        # Description that may come from API requests
        if description:
            # Add FraMeSToR NFO to AITHER
            if self.tracker == "AITHER" and "framestor" in meta and meta.framestor:
                nfo_content = meta.description_nfo_content
                if nfo_content:
                    aither_framestor_nfo = f"[code]{nfo_content}[/code]"
                    aither_framestor_nfo = aither_framestor_nfo.replace(
                        "https://i.imgur.com/e9o0zpQ.png",
                        "https://beyondhd.co/images/2017/11/30/c5802892418ee2046efba17166f0cad9.png",
                    )
                    images = []
                    desc_parts.append(aither_framestor_nfo)
                else:
                    # Remove NFO from description
                    meta_description = re.sub(
                        r"\[center\]\[spoiler=.*? NFO:\]\[code\](.*?)\[/code\]\[/spoiler\]\[/center\]",
                        "",
                        meta_description,
                        flags=re.DOTALL,
                    )
                    if meta_description:
                        desc_parts.append(
                            self._clean_imported_description(
                                meta_description,
                                meta,
                                regenerated_parts,
                                replacing_tonemapped_header=replacing_tonemapped_header,
                                custom_header=desc_header if custom_header else "",
                                custom_signature=custom_signature_section,
                            )
                        )
            elif meta_description:
                desc_parts.append(
                    self._clean_imported_description(
                        meta_description,
                        meta,
                        regenerated_parts,
                        replacing_tonemapped_header=replacing_tonemapped_header,
                        custom_header=desc_header if custom_header else "",
                        custom_signature=custom_signature_section,
                    )
                )

        # NFO details
        if nfo:
            nfo_content = meta.description_nfo_content
            if isinstance(nfo_content, str) and nfo_content:
                if self.tracker == "DIGITALCORE":
                    desc_parts.append(f"[nfo]{nfo_content}[/nfo]")
                elif self.tracker == "TORRENTLEECH":
                    desc_parts.append(f"<div style='display: flex; justify-content: center;'><div style='background-color: #000000; color: #ffffff;'>{nfo_content}</div></div>")
                else:
                    desc_parts.append(f"[pre]{nfo_content}[/pre]")

        # Description from file/pastebin link
        if user_description:
            user_description_content = await self.get_user_description(meta)
            # ``gen_desc`` promotes a supplied file/link to ``meta.description``
            # while retaining it as the user-description source.  Trackers that
            # enable both sections must not render that same content twice.
            if not description or user_description_content.strip() != meta_description.strip():
                desc_parts.append(user_description_content)

        # Render image sections before deciding whether their headings are
        # needed to distinguish them. Logos, text and footers do not count.
        menu_section = await self.menu_section(meta) if menu_screenshots else ""
        tonemapped_section = tonemapped_header_text if tonemapped_header else ""
        audio_spectrogram_section = await self.get_audio_spectrogram_section(meta) if audio_spectrogram else ""
        dynamic_hdr_plot_section = await self.get_dynamic_hdr_plot_section(meta) if dynamic_hdr_plot else ""

        discs_and_screenshots = await self._handle_discs_and_screenshots(meta, approved_image_hosts, images, multi_screens) if screenshots else ""
        if self._get_bool_config("hide_screenshot_header_if_only_section", True, meta):
            image_sections = [
                (menu_section, await self.menu_screenshot_header(meta) if menu_section else ""),
                (discs_and_screenshots, await self.screenshot_header(meta) if discs_and_screenshots else ""),
                (audio_spectrogram_section, self._get_str_config("audio_spectrogram_header", "[center][b]Audio Spectrogram[/b][/center]", meta)),
                (dynamic_hdr_plot_section, self._get_str_config("dynamic_hdr_plot_header", "[center][b]Dynamic HDR Metadata[/b][/center]", meta)),
            ]
            # Count rendered headings, including repeated headings in packs.
            # Only remove a known generated heading from its own section.
            header_count = sum(section.count(header) for section, header in image_sections if header.strip())
            if header_count == 1:
                menu_section, discs_and_screenshots, audio_spectrogram_section, dynamic_hdr_plot_section = (
                    section.replace(header, "", 1) if header.strip() else section for section, header in image_sections
                )

        # Menu Screenshots
        desc_parts.append(menu_section)

        # Tonemapped Header
        desc_parts.append(tonemapped_section)

        # Discs and Screenshots
        if screenshots:
            desc_parts.append(discs_and_screenshots)

        # Audio Spectrograms
        desc_parts.append(audio_spectrogram_section)

        # Dynamic HDR metadata plots (Dolby Vision / HDR10+)
        if dynamic_hdr_plot:
            desc_parts.append(dynamic_hdr_plot_section)

        # Custom Signature
        if custom_signature:
            desc_parts.append(custom_signature_section)

        description_str: str = "\n".join(part for part in desc_parts if part.strip())

        if meta.debug:
            desc_file = f"{meta.base_dir}{'/' + 'tmp' + '/'}{meta.uuid}/[{self.tracker}]DESCRIPTION.txt"
            logger.debug(f"DEBUG: Saving final description to [yellow]{desc_file}[/yellow]")
            async with aiofiles.open(desc_file, "w", encoding="utf-8") as description_file:
                await description_file.write(self.tracker_specific_formats(self.tracker, "\n".join(part for part in (description_str, ((signature or (f"[right][url=https://github.com/wastaken7/Upload-Assistant][size=4]{meta.ua_signature}[/size][/url][/right]" if meta.ua_signature else "")) if ua_signature else "")) if part.strip())))  # fmt: off

        # fmt: off
        return self.tracker_specific_formats(self.tracker, "\n".join(part for part in (description_str, ((signature or (f"[right][url=https://github.com/wastaken7/Upload-Assistant][size=4]{meta.ua_signature}[/size][/url][/right]" if meta.ua_signature else "")) if ua_signature else "")) if part.strip()))  # ci: ua_signature v4.8
        # fmt: on

    async def _check_saved_pack_image_links(self, meta: Meta, approved_image_hosts: list[str]) -> dict[str, Any]:
        pack_images_file = Path(meta.base_dir) / "tmp" / meta.uuid / "pack_image_links.json"
        pack_images_data: dict[str, Any] = {}
        approved_hosts = set(approved_image_hosts or [])
        if await self.common.path_exists(pack_images_file):
            try:
                async with aiofiles.open(pack_images_file, encoding="utf-8") as f:
                    pack_images_data = json.loads(await f.read())

                    # Filter out keys with non-approved image hosts
                    keys_to_remove: list[str] = []
                    for key_name, key_data in pack_images_data.get("keys", {}).items():
                        images_to_keep: list[dict[str, str]] = []
                        for img in key_data.get("images", []):
                            raw_url = img.get("raw_url", "")
                            # Extract hostname from URL and check against approved hosts
                            try:
                                parsed_url: ParseResult = urllib.parse.urlparse(raw_url or "")
                                hostname = parsed_url.netloc

                                # Use suffix-based matching: check if hostname matches or is subdomain of approved host
                                host_approved = False
                                if not approved_hosts:
                                    host_approved = True  # If no approved hosts specified, allow all
                                else:
                                    for approved_host in approved_hosts:
                                        if hostname == approved_host or hostname.endswith(f".{approved_host}"):
                                            host_approved = True
                                            break

                                if host_approved:
                                    images_to_keep.append(img)
                                elif meta.debug:
                                    logger.info(f"[yellow]Filtering out image from non-approved host: {hostname}[/yellow]")
                            except Exception:
                                # If URL parsing fails, skip this image
                                logger.debug(f"[yellow]Could not parse URL: {raw_url}[/yellow]")
                                continue

                        if images_to_keep:
                            # Update the key with only approved images
                            pack_images_data["keys"][key_name]["images"] = images_to_keep
                            pack_images_data["keys"][key_name]["count"] = len(images_to_keep)
                        else:
                            # Mark key for removal if no approved images
                            keys_to_remove.append(key_name)

                    # Remove keys with no approved images
                    for key_name in keys_to_remove:
                        del pack_images_data["keys"][key_name]
                        logger.debug(f"[yellow]Removed key '{key_name}' - no approved image hosts[/yellow]")

                    # Recalculate total count
                    pack_images_data["total_count"] = sum(key_data["count"] for key_data in pack_images_data.get("keys", {}).values())

                    if pack_images_data.get("total_count", 0) < 3:
                        pack_images_data = {}  # Invalidate if less than 3 images total
                        logger.debug("[yellow]Invalidating pack images - less than 3 approved images total[/yellow]")
                    else:
                        logger.debug(f"[green]Loaded previously uploaded images from {pack_images_file}")
                        logger.debug(f"[blue]Found {pack_images_data.get('total_count', 0)} approved images across {len(pack_images_data.get('keys', {}))} keys[/blue]")
            except Exception as e:
                logger.warning(f"[yellow]Warning: Could not load pack image data: {e!s}[/yellow]")
        return pack_images_data

    async def _handle_discs_and_screenshots(
        self,
        meta: Meta,
        approved_image_hosts: list[str],
        images: list[dict[str, str]],
        multi_screens: int,
        include_header: bool = True,
    ) -> str:
        if not images:
            return ""
        try:
            screenheader = await self.screenshot_header(meta) if include_header else ""
        except Exception:
            screenheader = None

        # Check for saved pack_image_links.json file
        pack_images_data = await self._check_saved_pack_image_links(meta, approved_image_hosts)

        char_limit = self._get_int_config("charLimit", 14000)
        file_limit = self._get_int_config("fileLimit", 5)
        thumb_size = self._get_int_config("pack_thumb_size", 300, meta)
        process_limit = self._get_int_config("processLimit", 10)

        screens_per_row = await self.get_screens_per_row(meta)

        desc_parts: list[str] = []

        if meta.category == "GAME":
            if screenheader is not None:
                desc_parts.append(screenheader + "\n")
            desc_parts.append("[center]")
            for img_index in range(len(images[: meta.screens if meta.screens is not None else 6])):
                web_url = images[img_index]["web_url"]
                raw_url = images[img_index]["raw_url"]
                desc_parts.append(self.format_screenshot(web_url, raw_url, meta=meta))
                self._append_screenshot_row_separator(desc_parts, img_index, screens_per_row)
            desc_parts.append("[/center]")
            return "".join(desc_parts)

        discs = meta.discs
        if len(discs) == 1:
            each = discs[0]
            if each["type"] == "DVD":
                desc_parts.append("[center]")
                desc_parts.append(f"[spoiler={Path(each['vob']).name}][code]{each['vob_mi']}[/code][/spoiler]\n\n")
                desc_parts.append("[/center]")
            if screenheader is not None:
                desc_parts.append(screenheader + "\n")
            desc_parts.append("[center]")
            for img_index in range(len(images[: meta.screens])):
                web_url = images[img_index]["web_url"]
                raw_url = images[img_index]["raw_url"]
                img_url = images[img_index].get("img_url", raw_url)
                desc_parts.append(self.format_screenshot(web_url, raw_url, img_url, meta=meta))
                self._append_screenshot_row_separator(desc_parts, img_index, screens_per_row)
            desc_parts.append("[/center]")
            if each["type"] == "BDMV":
                bdinfo_keys = [key for key in each if key.startswith("bdinfo")]
                if len(bdinfo_keys) > 1:
                    if "retry_count" not in meta:
                        meta.retry_count = 0

                    for i, key in enumerate(bdinfo_keys[1:], start=1):  # Skip the first bdinfo
                        new_images_key = f"new_images_playlist_{i}"
                        bdinfo = each[key]
                        edition = bdinfo.get("edition", "Unknown Edition")

                        # Find the corresponding summary for this bdinfo
                        summary_key = f"summary_{i}" if i > 0 else "summary"
                        summary = each.get(summary_key, "No summary available")

                        # Check for saved images first
                        if pack_images_data and "keys" in pack_images_data and new_images_key in pack_images_data["keys"]:
                            saved_images = pack_images_data["keys"][new_images_key]["images"]
                            if saved_images:
                                logger.debug(f"[yellow]Using saved images from pack_image_links.json for {new_images_key}")

                                meta[new_images_key] = []
                                for img in saved_images:
                                    meta[new_images_key].append(
                                        {
                                            "img_url": img.get("img_url", ""),
                                            "raw_url": img.get("raw_url", ""),
                                            "web_url": img.get("web_url", ""),
                                        }
                                    )

                        if meta.get(new_images_key):
                            desc_parts.append("[center]\n\n")
                            # Use the summary corresponding to the current bdinfo
                            desc_parts.append(f"[spoiler={edition}][code]{summary}[/code][/spoiler]\n\n")
                            logger.debug("[yellow]Using original uploaded images for first disc")
                            desc_parts.append("[center]")
                            for img_index, img in enumerate(meta[new_images_key]):
                                web_url = img["web_url"]
                                raw_url = img["raw_url"]
                                img_url = img.get("img_url", raw_url)
                                desc_parts.append(self.format_screenshot(web_url, raw_url, img_url, thumb_size, meta=meta))
                                self._append_screenshot_row_separator(desc_parts, img_index, screens_per_row)
                            desc_parts.append("[/center]\n\n")
                        else:
                            desc_parts.append("[center]\n\n")
                            # Use the summary corresponding to the current bdinfo
                            desc_parts.append(f"[spoiler={edition}][code]{summary}[/code][/spoiler]\n\n")
                            desc_parts.append("[/center]\n\n")
                            meta.retry_count += 1
                            meta[new_images_key] = []
                            new_screens = [f.name for f in manifest_files(meta.base_dir, meta.uuid, f"PLAYLIST_{i}")]
                            if not new_screens:
                                logger.warning(f"[yellow]Missing prepared screenshots for PLAYLIST_{i}; skipping its images in the description.[/yellow]")
                            if new_screens and not meta.skip_imghost_upload:
                                uploaded_images, _ = await self.uploadscreens_manager.upload_screens(
                                    meta,
                                    multi_screens,
                                    1,
                                    0,
                                    multi_screens,
                                    new_screens,
                                    {new_images_key: meta[new_images_key]},
                                    allowed_hosts=approved_image_hosts,
                                )
                                if uploaded_images and not meta.skip_imghost_upload:
                                    await self.common.save_image_links(meta, new_images_key, uploaded_images)
                                for img in uploaded_images:
                                    meta[new_images_key].append(
                                        {
                                            "img_url": img["img_url"],
                                            "raw_url": img["raw_url"],
                                            "web_url": img["web_url"],
                                        }
                                    )

                                desc_parts.append("[center]")
                                for img_index, img in enumerate(uploaded_images):
                                    web_url = img["web_url"]
                                    raw_url = img["raw_url"]
                                    img_url = img.get("img_url", raw_url) or ""
                                    desc_parts.append(self.format_screenshot(web_url, raw_url, img_url, thumb_size, meta=meta))
                                    self._append_screenshot_row_separator(desc_parts, img_index, screens_per_row)
                                desc_parts.append("[/center]\n\n")

                            meta_filename = f"{meta.base_dir}{'/' + 'tmp' + '/'}{meta.uuid}/meta.json"
                            async with aiofiles.open(meta_filename, "w") as f:
                                await f.write(json.dumps(meta.to_dict(), indent=4, cls=PathAwareEncoder))

        # Handle multiple discs case
        elif len(discs) > 1:
            # Initialize retry_count if not already set
            if "retry_count" not in meta:
                meta.retry_count = 0

            total_discs_to_process = min(len(discs), process_limit)
            processed_count = 0
            if multi_screens != 0:
                logger.info("[cyan]Processing screenshots for packed content (multiScreens)[/cyan]")
                logger.info(f"[cyan]{total_discs_to_process} files (processLimit)[/cyan]")

            for i, each in enumerate(discs):
                # Set a unique key per disc for managing images
                new_images_key = f"new_images_disc_{i}"

                if i == 0:
                    desc_parts.append("[center]")
                    if each["type"] == "BDMV":
                        desc_parts.append(f"{each.get('name', 'BDINFO')}\n\n")
                    elif each["type"] == "DVD":
                        desc_parts.append(f"{each['name']}:\n")
                        desc_parts.append(f"[spoiler={Path(each['vob']).name}][code]{each['vob_mi']}[/code][/spoiler]")
                        desc_parts.append(f"[spoiler={Path(each['ifo']).name}][code]{each['ifo_mi']}[/code][/spoiler]\n\n")
                    # For the first disc, use images from `meta.image_list` and add screenheader if applicable
                    logger.debug("[yellow]Using original uploaded images for first disc")
                    if screenheader is not None:
                        desc_parts.append("[/center]\n\n")
                        desc_parts.append(screenheader + "\n")
                        desc_parts.append("[center]")
                    for img_index in range(len(images[: meta.screens])):
                        web_url = images[img_index]["web_url"]
                        raw_url = images[img_index]["raw_url"]
                        img_url = images[img_index].get("img_url", raw_url)
                        desc_parts.append(self.format_screenshot(web_url, raw_url, img_url, thumb_size, meta=meta))
                        self._append_screenshot_row_separator(desc_parts, img_index, screens_per_row)
                    desc_parts.append("[/center]\n\n")
                else:
                    if multi_screens != 0:
                        processed_count += 1
                        disc_name = each.get("name", f"Disc {i}")
                        logger.info(
                            f"\rProcessing disc {processed_count}/{total_discs_to_process}: {disc_name[:40]}{'...' if len(disc_name) > 40 else ''}",
                            extra={"markup": False},
                        )
                        # Check if screenshots exist for the current disc key
                        # Check for saved images first
                        if pack_images_data and "keys" in pack_images_data and new_images_key in pack_images_data["keys"]:
                            saved_images = pack_images_data["keys"][new_images_key]["images"]
                            if saved_images:
                                logger.debug(f"[yellow]Using saved images from pack_image_links.json for {new_images_key}")

                                meta[new_images_key] = []
                                for img in saved_images:
                                    meta[new_images_key].append(
                                        {
                                            "img_url": img.get("img_url", ""),
                                            "raw_url": img.get("raw_url", ""),
                                            "web_url": img.get("web_url", ""),
                                        }
                                    )
                        if meta.get(new_images_key):
                            logger.debug(f"[yellow]Found needed image URLs for {new_images_key}")
                            desc_parts.append("[center]")
                            if each["type"] == "BDMV":
                                desc_parts.append(f"[spoiler={each.get('name', 'BDINFO')}][code]{each['summary']}[/code][/spoiler]\n\n")
                            elif each["type"] == "DVD":
                                desc_parts.append(f"{each['name']}:\n")
                                desc_parts.append(f"[spoiler={Path(each['vob']).name}][code]{each['vob_mi']}[/code][/spoiler] ")
                                desc_parts.append(f"[spoiler={Path(each['ifo']).name}][code]{each['ifo_mi']}[/code][/spoiler]\n\n")
                            desc_parts.append("[/center]\n\n")
                            # Use existing URLs from meta to write to descfile
                            desc_parts.append("[center]")
                            for img_index, img in enumerate(meta[new_images_key]):
                                web_url = img["web_url"]
                                raw_url = img["raw_url"]
                                img_url = img.get("img_url", raw_url)
                                desc_parts.append(self.format_screenshot(web_url, raw_url, img_url, thumb_size, meta=meta))
                                self._append_screenshot_row_separator(desc_parts, img_index, screens_per_row)
                            desc_parts.append("[/center]\n\n")
                        else:
                            # Increment retry_count for tracking but use unique disc keys for each disc
                            meta.retry_count += 1
                            meta[new_images_key] = []
                            desc_parts.append("[center]")
                            if each["type"] == "BDMV":
                                desc_parts.append(f"[spoiler={each.get('name', 'BDINFO')}][code]{each['summary']}[/code][/spoiler]\n\n")
                            elif each["type"] == "DVD":
                                desc_parts.append(f"{each['name']}:\n")
                                desc_parts.append(f"[spoiler={Path(each['vob']).name}][code]{each['vob_mi']}[/code][/spoiler] ")
                                desc_parts.append(f"[spoiler={Path(each['ifo']).name}][code]{each['ifo_mi']}[/code][/spoiler]\n\n")
                            desc_parts.append("[/center]\n\n")
                            # Check if new screenshots already exist before running prep.screenshots
                            new_screens = [f.name for f in manifest_files(meta.base_dir, meta.uuid, f"FILE_{i}")]
                            if not new_screens:
                                logger.warning(f"[yellow]Missing prepared screenshots for {new_images_key}; skipping its images in the description.[/yellow]")

                            if new_screens and not meta.skip_imghost_upload:
                                uploaded_images, _ = await self.uploadscreens_manager.upload_screens(
                                    meta,
                                    multi_screens,
                                    1,
                                    0,
                                    multi_screens,
                                    new_screens,
                                    {new_images_key: meta[new_images_key]},
                                    allowed_hosts=approved_image_hosts,
                                )
                                if uploaded_images and not meta.skip_imghost_upload:
                                    await self.common.save_image_links(meta, new_images_key, uploaded_images)
                                # Append each uploaded image's data to `meta[new_images_key]`
                                for img in uploaded_images:
                                    meta[new_images_key].append(
                                        {
                                            "img_url": img["img_url"],
                                            "raw_url": img["raw_url"],
                                            "web_url": img["web_url"],
                                        }
                                    )

                                # Write new URLs to descfile
                                desc_parts.append("[center]")
                                for img_index, img in enumerate(uploaded_images):
                                    web_url = img["web_url"]
                                    raw_url = img["raw_url"]
                                    img_url = img.get("img_url", raw_url) or ""
                                    desc_parts.append(self.format_screenshot(web_url, raw_url, img_url, thumb_size, meta=meta))
                                    self._append_screenshot_row_separator(desc_parts, img_index, screens_per_row)
                                desc_parts.append("[/center]\n\n")

                            # Save the updated meta to `meta.json` after upload
                            meta_filename = f"{meta.base_dir}{'/' + 'tmp' + '/'}{meta.uuid}/meta.json"
                            async with aiofiles.open(meta_filename, "w") as f:
                                await f.write(json.dumps(meta.to_dict(), indent=4, cls=PathAwareEncoder))
                        logger.info("")

        # Handle single file case
        filelist = meta.filelist
        if len(filelist) == 1:
            if meta.comparison and meta.comparison_groups:
                desc_parts.append("[center]")
                comparison_groups = meta.comparison_groups
                if not isinstance(comparison_groups, dict):
                    comparison_groups = {str(i): v for i, v in enumerate(comparison_groups)}
                sorted_group_indices = sorted(comparison_groups.keys(), key=lambda x: int(x))

                comp_sources: list[str] = []
                for group_idx in sorted_group_indices:
                    group_data = comparison_groups[group_idx]
                    group_name = group_data.get("name", f"Group {group_idx}")
                    comp_sources.append(group_name)

                sources_string = ", ".join(comp_sources)
                desc_parts.append(f"[comparison={sources_string}]\n")

                images_per_group = min([len(comparison_groups[idx].get("urls", [])) for idx in sorted_group_indices])

                for img_idx in range(images_per_group):
                    for group_idx in sorted_group_indices:
                        group_data = comparison_groups[group_idx]
                        urls = group_data.get("urls", [])
                        if img_idx < len(urls):
                            img_url = urls[img_idx].get("raw_url", "")
                            if img_url:
                                desc_parts.append(f"{img_url}\n")

                desc_parts.append("[/comparison][/center]\n\n")

            if screenheader is not None:
                desc_parts.append(screenheader + "\n")
            desc_parts.append("[center]")
            for img_index in range(len(images[: meta.screens])):
                web_url = images[img_index]["web_url"]
                raw_url = images[img_index]["raw_url"]
                img_url = images[img_index].get("img_url", raw_url)
                desc_parts.append(self.format_screenshot(web_url, raw_url, img_url, meta=meta))
                self._append_screenshot_row_separator(desc_parts, img_index, screens_per_row)
            desc_parts.append("[/center]")

        # Handle multiple files case
        # Initialize character counter
        char_count = 0
        max_char_limit = char_limit  # Character limit
        other_files_spoiler_open = False  # Track if "Other files" spoiler has been opened
        total_files_to_process = min(len(filelist), process_limit)
        processed_count = 0
        if multi_screens != 0 and total_files_to_process > 1:
            logger.info("[cyan]Processing screenshots for packed content (multiScreens)[/cyan]")
            logger.info(f"[cyan]{total_files_to_process} files (processLimit)[/cyan]")

        # First Pass: Create and Upload Images for Each File
        for i, file in enumerate(filelist):
            if i >= process_limit:
                # console.print("[yellow]Skipping processing more files as they exceed the process limit.")
                continue
            if multi_screens != 0:
                if total_files_to_process > 1:
                    processed_count += 1
                    filename = Path(file).name
                    logger.info(f"\rProcessing file {processed_count}/{total_files_to_process}: {filename[:40]}{'...' if len(filename) > 40 else ''}", extra={"markup": False})
                if i > 0:
                    new_images_key = f"new_images_file_{i}"
                    # Check for saved images first
                    if pack_images_data and "keys" in pack_images_data and new_images_key in pack_images_data["keys"]:
                        saved_images = pack_images_data["keys"][new_images_key]["images"]
                        if saved_images:
                            logger.debug(f"[yellow]Using saved images from pack_image_links.json for {new_images_key}")

                            meta[new_images_key] = []
                            for img in saved_images:
                                meta[new_images_key].append(
                                    {
                                        "img_url": img.get("img_url", ""),
                                        "raw_url": img.get("raw_url", ""),
                                        "web_url": img.get("web_url", ""),
                                    }
                                )
                    if new_images_key not in meta or not meta[new_images_key]:
                        meta[new_images_key] = []
                        # Proceed with image generation if not already present
                        new_screens = [f.name for f in manifest_files(meta.base_dir, meta.uuid, f"FILE_{i}")]

                        # If no screenshots exist, create them
                        if not new_screens:
                            if meta.debug:
                                logger.info(f"[yellow]No existing screenshots for {new_images_key}; generating new ones.")
                            try:
                                await self.takescreens_manager.screenshots(
                                    file,
                                    f"FILE_{i}",
                                    meta.uuid,
                                    meta.base_dir,
                                    meta,
                                    multi_screens,
                                    True,
                                    cleanup_after_capture=False,
                                    capture_group=f"FILE_{i}",
                                )
                                await asyncio.sleep(0.1)
                            except Exception as e:
                                logger.info(f"Error during generic screenshot capture: {e}", extra={"markup": False})

                        new_screens = [f.name for f in manifest_files(meta.base_dir, meta.uuid, f"FILE_{i}")]

                        # Upload generated screenshots
                        if new_screens and not meta.skip_imghost_upload:
                            uploaded_images, _ = await self.uploadscreens_manager.upload_screens(
                                meta,
                                multi_screens,
                                1,
                                0,
                                multi_screens,
                                new_screens,
                                {new_images_key: meta[new_images_key]},
                                allowed_hosts=approved_image_hosts,
                            )
                            if uploaded_images and not meta.skip_imghost_upload:
                                await self.common.save_image_links(meta, new_images_key, uploaded_images)
                            for img in uploaded_images:
                                meta[new_images_key].append(
                                    {
                                        "img_url": img["img_url"],
                                        "raw_url": img["raw_url"],
                                        "web_url": img["web_url"],
                                    }
                                )

                            await asyncio.sleep(0.1)

                await asyncio.sleep(0.05)

        # Save updated meta
        meta_filename = f"{meta.base_dir}{'/' + 'tmp' + '/'}{meta.uuid}/meta.json"
        async with aiofiles.open(meta_filename, "w") as f:
            await f.write(json.dumps(meta.to_dict(), indent=4, cls=PathAwareEncoder))
        await asyncio.sleep(0.1)

        # Second Pass: Process MediaInfo and Write Descriptions
        if len(filelist) > 1:
            for i, file in enumerate(filelist):
                if i >= process_limit:
                    continue
                # Extract filename directly from the file path
                filename = Path(file.strip()).stem.replace("[", "").replace("]", "")

                # If we are beyond the file limit, add all further files in a spoiler
                if multi_screens != 0 and i >= file_limit and not other_files_spoiler_open:
                    desc_parts.append("[center][spoiler=Other files]\n")
                    char_count += len("[center][spoiler=Other files]\n")
                    other_files_spoiler_open = True

                # Write filename in BBCode format with MediaInfo in spoiler if not the first file
                if multi_screens != 0:
                    if i > 0 and char_count < max_char_limit:
                        mi_dump = MediaInfo.parse(file, output="STRING", full=False, mediainfo_options={"inform_version": "1"})
                        parsed_mediainfo = self.parser.parse_mediainfo(mi_dump)
                        formatted_bbcode = self.parser.format_bbcode(parsed_mediainfo)
                        desc_parts.append(f"[center][spoiler={filename}]{formatted_bbcode}[/spoiler][/center]\n")
                        char_count += len(f"[center][spoiler={filename}]{formatted_bbcode}[/spoiler][/center]\n")
                    else:
                        desc_parts.append(f"[center]{filename}\n[/center]\n")
                        char_count += len(f"[center]{filename}\n[/center]\n")

                # Write images if they exist
                new_images_key = f"new_images_file_{i}"
                if i == 0:  # For the first file, use 'image_list' key and add screenheader if applicable
                    if images:
                        if screenheader is not None:
                            desc_parts.append(screenheader + "\n")
                            char_count += len(screenheader + "\n")
                        desc_parts.append("[center]")
                        char_count += len("[center]")
                        for img_index in range(len(images)):
                            web_url = images[img_index]["web_url"]
                            raw_url = images[img_index]["raw_url"]
                            img_url = images[img_index].get("img_url", raw_url)
                            image_str = self.format_screenshot(web_url, raw_url, img_url, thumb_size, meta=meta)
                            desc_parts.append(image_str)
                            char_count += len(image_str)
                            char_count += len(self._append_screenshot_row_separator(desc_parts, img_index, screens_per_row))
                        desc_parts.append("[/center]\n\n")
                        char_count += len("[/center]\n\n")
                elif multi_screens != 0 and new_images_key in meta and meta[new_images_key]:
                    desc_parts.append("[center]")
                    char_count += len("[center]")
                    for img_index, img in enumerate(meta[new_images_key]):
                        web_url = img["web_url"]
                        raw_url = img["raw_url"]
                        img_url = img.get("img_url", raw_url)
                        image_str = self.format_screenshot(web_url, raw_url, img_url, thumb_size, meta=meta)
                        desc_parts.append(image_str)
                        char_count += len(image_str)
                        char_count += len(self._append_screenshot_row_separator(desc_parts, img_index, screens_per_row))
                    desc_parts.append("[/center]\n\n")
                    char_count += len("[/center]\n\n")

            if other_files_spoiler_open:
                desc_parts.append("[/spoiler][/center]\n")
                char_count += len("[/spoiler][/center]\n")

        if char_count >= 1 and meta.debug:
            logger.info(f"[yellow]Total characters written to description: {char_count}")
        if total_files_to_process > 1:
            logger.info("")

        return "".join(p for p in desc_parts if p)

    async def get_screens_per_row(self, meta: Meta | None = None) -> int:
        try:
            if self.tracker == "TORRENTLEECH":
                return 2

            # If screens_per_row is set, use that to determine how many screenshots should be on each row. Otherwise, use 2 as default
            screens_per_row = self._get_int_config("screens_per_row", 2, meta)
        except Exception:
            screens_per_row = 2
        return screens_per_row

    def _append_screenshot_row_separator(self, parts: list[str], image_index: int, screens_per_row: int) -> str:
        if not screens_per_row or (image_index + 1) % screens_per_row != 0:
            return ""

        separator = "<br><br>" if self.tracker == "TORRENTLEECH" else "\n"
        parts.append(separator)
        return separator

    async def menu_section(self, meta: Meta) -> str:
        menu_image_section = ""
        try:
            disc_menu_header = await self.menu_screenshot_header(meta)
            screens_per_row = await self.get_screens_per_row(meta)
            if meta.is_disc:
                menu_parts: list[str] = []
                menu_images = get_tracker_image_collection(meta, self.tracker, "menu_images")
                if disc_menu_header and menu_images:
                    menu_parts.append(disc_menu_header + "\n")
                if menu_images:
                    menu_parts.append("[center]")
                    for img_index, image in enumerate(menu_images):
                        web_url = image.get("web_url")
                        raw_url = image.get("raw_url")
                        img_url = image.get("img_url", raw_url)
                        if not web_url or not raw_url:
                            continue
                        menu_parts.append(self.format_screenshot(web_url, raw_url, img_url, meta=meta))
                        self._append_screenshot_row_separator(menu_parts, img_index, screens_per_row)
                    menu_parts.append("[/center]\n\n")
                    menu_image_section = "".join(menu_parts)
        except Exception as e:
            logger.warning(f"[yellow]Warning: Error processing disc menu section: {e!s}[/yellow]")

        return menu_image_section

    def format_screenshot(self, web_url: str, raw_url: str, img_url: str = "", thumb_size: str | int = "", *, meta: Meta | None = None) -> str:
        if not img_url:
            img_url = raw_url
        if not thumb_size:
            thumb_size = self._get_int_config("thumbnail_size", 350, meta)

        from src.trackersetup import get_tracker_framework

        if get_tracker_framework(self.tracker) == "NEXUSPHP":
            return f"[img]{raw_url}[/img]"
        if self.tracker == "HDTORRENTS":
            return f"<a href='{raw_url}'><img src='{img_url}' height=137></a> "
        if self.tracker == "TORRENTLEECH":
            return f'<a href="{web_url}"><img src="{img_url}" style="max-width: 350px;"></a>  '
        if self.tracker == "FUNFILE":
            return f'<a href="{web_url}" target="_blank"><img src="{img_url}" width="{thumb_size}"></a> '
        if self.tracker == "GREATPOSTERWALL":
            return f"[img]{raw_url}[/img] "
        if self.tracker in ("HDSPACE", "IPTORRENTS"):
            if "imgbox" not in web_url:
                return f"[url={web_url}][img]{img_url}[/img][/url]\n"
            return f"[url={web_url}][img]{img_url}[/img][/url] "
        return f"[url={web_url}][img={thumb_size}]{raw_url}[/img][/url] "

    def tracker_specific_formats(self, tracker: str, description: str) -> str:
        bbcode = BBCODE()
        from src.trackersetup import get_tracker_framework

        if get_tracker_framework(tracker) == "UNIT3D":
            # Protect comparison payloads from all formatting, including newline cleanup.
            comparisons: list[str] = []

            def preserve_comparison(match: re.Match[str]) -> str:
                comparisons.append(match.group(0))
                return f"\x00COMPARISON{len(comparisons) - 1}\x00"

            description = re.sub(r"\[comparison=[^\]]*\].*?\[/comparison\]", preserve_comparison, description, flags=re.IGNORECASE | re.DOTALL)

        if get_tracker_framework(tracker) == "NEXUSPHP":
            description = bbcode.remove_img_resize(description)

        if tracker == "CZTEAM":
            # Supported tags were checked with docs/bbcode-benchmark.txt.
            description = bbcode.convert_comparison_to_centered(description, 1000)
            description = bbcode.remove_img_resize(description)
            description = bbcode.convert_code_to_pre(description)
            description = bbcode.convert_hide_to_spoiler(description)
            # Titled spoilers are not supported, so keep the title as bold text above a plain spoiler.
            description = re.sub(r"\[spoiler=([^\]]+)\]", lambda m: f"[b]{m.group(1).strip()}[/b]\n[spoiler]", description, flags=re.IGNORECASE)
            description = bbcode.convert_headings_to_sizes(description)
            description = bbcode.clamp_size_tags(description, 7)
            description = re.sub(r"\[align=(center|right)\](.*?)\[/align\]", r"[\1]\2[/\1]", description, flags=re.IGNORECASE | re.DOTALL)
            description = re.sub(r"\[/?(?:align(?:=[^\]]*)?|left|note|alert|hr|sup|sub)\]", "", description, flags=re.IGNORECASE)

        if tracker in {"ANTHELION", "BJSHARE", "BRASILTRACKER", "GREATPOSTERWALL"}:
            description = bbcode.clamp_size_tags(description)
            description = bbcode.convert_named_colors(description)
            description = bbcode.convert_headings_to_sizes(description)

        if tracker == "BRASILTRACKER":
            description = bbcode.remove_img_resize(description)
            description = bbcode.remove_list(description)

        if tracker == "BJSHARE":
            description = bbcode.convert_named_spoiler_to_named_hide(description)
            description = bbcode.convert_spoiler_to_hide(description)
            description = bbcode.remove_img_resize(description)
            description = bbcode.convert_to_align(description)
            description = bbcode.remove_list(description)
            description = description.replace("[code]", "[pre]").replace("[/code]", "[/pre]")

        if tracker == "ANTHELION":
            description = bbcode.convert_to_align(description)
            description = bbcode.remove_img_resize(description)
            description = bbcode.remove_sup(description)
            description = bbcode.remove_sub(description)
            description = bbcode.remove_list(description)
            description = description.replace("•", "-").replace("’", "'").replace("–", "-")  # noqa: RUF001
            description = description.replace("[code]", "[pre]").replace("[/code]", "[/pre]")

        if tracker == "DIGITALCORE":
            description = bbcode.remove_img_resize(description)
            description = description.replace("[user]", "").replace("[/user]", "")
            description = description.replace("[align=left]", "").replace("[/align]", "")
            description = description.replace("[right]", "").replace("[/right]", "")
            description = description.replace("[align=right]", "").replace("[/align]", "")
            description = bbcode.remove_sup(description)
            description = bbcode.remove_sub(description)
            description = description.replace("[alert]", "").replace("[/alert]", "")
            description = description.replace("[note]", "").replace("[/note]", "")
            description = description.replace("[hr]", "").replace("[/hr]", "")
            description = description.replace("[h1]", "[u][b]").replace("[/h1]", "[/b][/u]")
            description = description.replace("[h2]", "[u][b]").replace("[/h2]", "[/b][/u]")
            description = description.replace("[h3]", "[u][b]").replace("[/h3]", "[/b][/u]")
            description = description.replace("[ul]", "").replace("[/ul]", "")
            description = description.replace("[ol]", "").replace("[/ol]", "")
            description = description.replace("[*] ", "• ").replace("[*]", "• ")
            description = bbcode.convert_named_spoiler_to_normal_spoiler(description)
            description = bbcode.remove_list(description)
            description = description.strip()

        if tracker == "FUNFILE":
            description = description.replace("[user]", "").replace("[/user]", "")
            description = description.replace("[align=left]", "").replace("[/align]", "")
            description = description.replace("[right]", "").replace("[/right]", "")
            description = description.replace("[align=right]", "").replace("[/align]", "")
            description = bbcode.remove_sub(description)
            description = bbcode.remove_sup(description)
            description = description.replace("[alert]", "").replace("[/alert]", "")
            description = description.replace("[note]", "").replace("[/note]", "")
            description = description.replace("[hr]", "").replace("[/hr]", "")
            description = description.replace("[h1]", "[u][b]").replace("[/h1]", "[/b][/u]")
            description = description.replace("[h2]", "[u][b]").replace("[/h2]", "[/b][/u]")
            description = description.replace("[h3]", "[u][b]").replace("[/h3]", "[/b][/u]")
            description = description.replace("[ul]", "").replace("[/ul]", "")
            description = description.replace("[ol]", "").replace("[/ol]", "")
            description = description.replace("[hide]", "").replace("[/hide]", "")
            description = description.replace("•", "-").replace("“", '"').replace("”", '"')
            description = bbcode.convert_comparison_to_centered(description, 1000)
            description = bbcode.remove_spoiler(description)

            # [url][img=000]...[/img][/url]
            description = re.sub(
                r"\[url=(?P<href>[^\]]+)\]\[img=(?P<width>\d+)\](?P<src>[^\[]+)\[/img\]\[/url\]",
                r'<a href="\g<href>" target="_blank"><img src="\g<src>" width="\g<width>"></a>',
                description,
                flags=re.IGNORECASE,
            )

            # [url][img]...[/img][/url]
            description = re.sub(
                r"\[url=(?P<href>[^\]]+)\]\[img\](?P<src>[^\[]+)\[/img\]\[/url\]",
                r'<a href="\g<href>" target="_blank"><img src="\g<src>" width="220"></a>',
                description,
                flags=re.IGNORECASE,
            )

            # [img=200]...[/img] (no [url])
            description = re.sub(r"\[img=(?P<width>\d+)\](?P<src>[^\[]+)\[/img\]", r'<img src="\g<src>" width="\g<width>">', description, flags=re.IGNORECASE)

        if tracker == "GREATPOSTERWALL":
            description = bbcode.remove_sup(description)
            description = bbcode.remove_sub(description)
            description = bbcode.convert_to_align(description)
            description = bbcode.remove_list(description)
            description = description.replace("[code]", "[pre]").replace("[/code]", "[/pre]")
            description = re.sub(r"\[url=[^\]]+\]\[img(?:=[^\]]+)?\]([^\[]+)\[/img\]\[/url\]", r"[img]\1[/img]", description, flags=re.IGNORECASE)

        if tracker == "HDSPACE":
            description = description.replace("[user]", "").replace("[/user]", "")
            description = description.replace("[align=left]", "").replace("[/align]", "")
            description = description.replace("[right]", "").replace("[/right]", "")
            description = description.replace("[align=right]", "").replace("[/align]", "")
            description = bbcode.remove_sub(description)
            description = bbcode.remove_sup(description)
            description = description.replace("[alert]", "").replace("[/alert]", "")
            description = description.replace("[note]", "").replace("[/note]", "")
            description = description.replace("[hr]", "").replace("[/hr]", "")
            description = description.replace("[h1]", "[u][b]").replace("[/h1]", "[/b][/u]")
            description = description.replace("[h2]", "[u][b]").replace("[/h2]", "[/b][/u]")
            description = description.replace("[h3]", "[u][b]").replace("[/h3]", "[/b][/u]")
            description = description.replace("[ul]", "").replace("[/ul]", "")
            description = description.replace("[ol]", "").replace("[/ol]", "")
            description = bbcode.remove_hide(description)
            description = bbcode.remove_img_resize(description)
            description = bbcode.convert_comparison_to_centered(description, 1000)
            description = bbcode.remove_spoiler(description)
            description = bbcode.convert_hex_colors_to_named(description)

            # Apply custom image line breaks for HDSPACE: if "imgbox" is not in the web_url, place only one image per line.
            def hds_image_formatter(match) -> str:
                web_url = match.group(1)
                raw_url = match.group(2)
                if "imgbox" not in web_url:
                    return f"[url={web_url}][img]{raw_url}[/img][/url]\n"
                return f"[url={web_url}][img]{raw_url}[/img][/url]"

            pattern = r"\[url=([^\]]+)\]\[img(?:=[^\]]*)?\]([^\[]+)\[/img\]\[/url\]\s*"
            description = re.sub(pattern, hds_image_formatter, description)

        if tracker == "IPTORRENTS":
            description = description.replace("[user]", "").replace("[/user]", "")
            description = description.replace("[align=left]", "").replace("[/align]", "")
            description = description.replace("[right]", "").replace("[/right]", "")
            description = description.replace("[align=right]", "").replace("[/align]", "")
            description = bbcode.remove_sub(description)
            description = bbcode.remove_sup(description)
            description = description.replace("[alert]", "").replace("[/alert]", "")
            description = description.replace("[note]", "").replace("[/note]", "")
            description = description.replace("[hr]", "").replace("[/hr]", "")
            description = description.replace("[h1]", "[u][b]").replace("[/h1]", "[/b][/u]")
            description = description.replace("[h2]", "[u][b]").replace("[/h2]", "[/b][/u]")
            description = description.replace("[h3]", "[u][b]").replace("[/h3]", "[/b][/u]")
            description = description.replace("[ul]", "").replace("[/ul]", "")
            description = description.replace("[ol]", "").replace("[/ol]", "")
            description = bbcode.remove_hide(description)
            description = bbcode.remove_img_resize(description)
            description = bbcode.convert_comparison_to_centered(description, 1000)
            description = bbcode.remove_spoiler(description)

        if tracker == "HDTORRENTS":
            description = description.replace("[user]", "").replace("[/user]", "")
            description = description.replace("[align=left]", "").replace("[/align]", "")
            description = description.replace("[align=right]", "").replace("[/align]", "")
            description = bbcode.remove_sub(description)
            description = bbcode.remove_sup(description)
            description = description.replace("[alert]", "").replace("[/alert]", "")
            description = description.replace("[note]", "").replace("[/note]", "")
            description = description.replace("[hr]", "").replace("[/hr]", "")
            description = description.replace("[h1]", "[u][b]").replace("[/h1]", "[/b][/u]")
            description = description.replace("[h2]", "[u][b]").replace("[/h2]", "[/b][/u]")
            description = description.replace("[h3]", "[u][b]").replace("[/h3]", "[/b][/u]")
            description = description.replace("[ul]", "").replace("[/ul]", "")
            description = description.replace("[ol]", "").replace("[/ol]", "")
            description = bbcode.convert_spoiler_to_hide(description)
            description = bbcode.remove_img_resize(description)
            description = bbcode.convert_comparison_to_centered(description, 1000)
            description = bbcode.remove_spoiler(description)
            description = bbcode.remove_list(description)

        if get_tracker_framework(tracker) == "NEXUSPHP":
            description = description.replace("[user]", "").replace("[/user]", "")
            description = description.replace("[align=left]", "").replace("[/align]", "")
            description = description.replace("[right]", "").replace("[/right]", "")
            description = description.replace("[align=right]", "").replace("[/align]", "")
            description = description.replace("[sup]", "").replace("[/sup]", "")
            description = description.replace("[sub]", "").replace("[/sub]", "")
            description = description.replace("[alert]", "").replace("[/alert]", "")
            description = description.replace("[note]", "").replace("[/note]", "")
            description = description.replace("[hr]", "").replace("[/hr]", "")
            description = description.replace("[h1]", "[u][b]").replace("[/h1]", "[/b][/u]")
            description = description.replace("[h2]", "[u][b]").replace("[/h2]", "[/b][/u]")
            description = description.replace("[h3]", "[u][b]").replace("[/h3]", "[/b][/u]")
            description = description.replace("[ul]", "").replace("[/ul]", "")
            description = description.replace("[ol]", "").replace("[/ol]", "")
            description = description.replace("[hide]", "").replace("[/hide]", "")
            description = bbcode.remove_img_resize(description)
            description = re.sub(r"\[center\]\[spoiler=.*? NFO:\]\[code\](.*?)\[/code\]\[/spoiler\]\[/center\]", r"", description, flags=re.DOTALL)
            description = bbcode.convert_comparison_to_centered(description, 1000)
            description = bbcode.remove_spoiler(description)
            description = re.sub(r"\n{3,}", "\n\n", description)

        if tracker == "SPEEDAPP":
            description = bbcode.remove_img_resize(description)
            description = bbcode.convert_named_spoiler_to_normal_spoiler(description)
            description = description.replace("[note]", "Note: ").replace("[/note]", "").replace("[code]", "").replace("[/code]", "").replace("[*]", "• ")
            description = bbcode.remove_spoiler(description)
            description = bbcode.remove_list(description)

        if tracker == "TORRENTLEECH":
            description = description.replace("[center]", "<center>").replace("[/center]", "</center>")
            # TorrentLeech has no heading BBCode; render headings as bold text instead.
            description = re.sub(r"\[(/?)h[1-6]\]", r"[\1b]", description, flags=re.IGNORECASE)
            description = re.sub(r"\[\*\]", "\n[*]", description, flags=re.IGNORECASE)
            description = re.sub(r"\[c\](.*?)\[/c\]", r"[code]\1[/code]", description, flags=re.IGNORECASE | re.DOTALL)
            description = re.sub(r"\[hr\]", "---", description, flags=re.IGNORECASE)
            description = re.sub(r'\[img=[\d"x]+\]', "[img]", description, flags=re.IGNORECASE)
            description = description.replace("[*] ", "• ").replace("[*]", "• ").replace("[note]", "Note: ").replace("[/note]", "").replace("[code]", "").replace("[/code]", "")
            description = bbcode.remove_list(description)
            description = bbcode.convert_comparison_to_centered(description, 1000)
            description = bbcode.remove_spoiler(description)
            description = re.sub(r"\n{3,}", "\n\n", description)

        if tracker == "IMMORTALSEED":
            # all tags must be removed, this is a plain-text only description
            description = html.unescape(description)
            # Preserve text structure where markup normally separates content.
            description = re.sub(r"<br\s*/?\s*>", "\n", description, flags=re.IGNORECASE)
            description = re.sub(r"</(?:p|div|li|tr|h[1-6]|blockquote|pre)\s*>", "\n", description, flags=re.IGNORECASE)
            description = re.sub(r"<!--.*?-->|<![^>]*>|</?[a-z][^>]*>", "", description, flags=re.IGNORECASE | re.DOTALL)
            # Strip BBCode names and attributes while retaining their contents.
            description = re.sub(r"\[/?[a-z][a-z0-9_-]*(?:=[^\]]*|\s+[^\]]*)?\]|\[\*\]", "", description, flags=re.IGNORECASE)

        if get_tracker_framework(tracker) == "UNIT3D":
            description = bbcode.convert_hide_to_spoiler(description)
            description = description.replace("[user]", "").replace("[/user]", "")
            description = description.replace("[hr]", "").replace("[/hr]", "")
            description = description.replace("[ul]", "").replace("[/ul]", "")
            description = description.replace("[ol]", "").replace("[/ol]", "")
            description = bbcode.remove_extra_lines(description)
            for index, comparison in enumerate(comparisons):
                description = description.replace(f"\x00COMPARISON{index}\x00", comparison)
            return description

        return bbcode.remove_extra_lines(description)
