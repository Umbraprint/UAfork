# Upload Assistant © 2025 Audionut & wastaken7 — Licensed under UAPL v1.0
import asyncio
import contextlib
import gc
import json
import os
import platform
import random
import re
import secrets
import sys
import time
import traceback
import urllib.parse
import uuid
import xml.etree.ElementTree as ET
import zipfile
from collections import Counter
from collections.abc import Awaitable, Mapping
from pathlib import Path
from typing import Any, cast

import ffmpeg
from PIL import Image

from data import config as data_config
from src.artwork import is_public_http_url, is_valid_cover_image, is_valid_image_bytes
from src.binaries import configured_binary
from src.cleanup import cleanup_manager
from src.console import logger
from src.media_extensions import VIDEO_EXTENSIONS
from src.mediainfo import MediaInfo
from src.meta import Meta
from src.resource_coordinator import holds_slot
from src.screenshot_manifest import capture_pages as manifest_capture_pages
from src.screenshot_manifest import capture_timestamps
from src.screenshot_manifest import clear_group as clear_screenshot_group
from src.screenshot_manifest import files as manifest_files
from src.screenshot_manifest import forget_file as forget_screenshot_file
from src.screenshot_manifest import register as register_screenshots
from src.screenshot_overlays import overlay_filters, overlay_fontfile, overlay_options
from src.stats import record_event_async
from src.temp_paths import artwork_dir, screenshots_dir
from src.webui_progress import complete_progress, publish_progress

default_config: dict[str, Any] = {}
task_limit = 1
cutoff = 1
ffmpeg_limit = False
ffmpeg_is_good = False
use_libplacebo = True
tone_map = False
ffmpeg_compression = "6"
LOSTIMG_MIN_SIZE = 75_000
LOSTIMG_MAX_SIZE = 20_000_000


def is_valid_lostimg_image_size(image_size: int) -> bool:
    """Return whether an image meets Lostimg's accepted size range."""
    return LOSTIMG_MIN_SIZE < image_size <= LOSTIMG_MAX_SIZE


def _positive_config_int(key: str, default: int) -> int:
    try:
        return max(1, int(default_config.get(key, default) or default))
    except TypeError, ValueError:
        return default


def xxx_contact_sheet_settings() -> tuple[int, int, int]:
    """Return configured XXX contact-sheet rows, columns, and video limit."""
    return (
        _positive_config_int("xxx_contact_sheet_rows", 12),
        _positive_config_int("xxx_contact_sheet_columns", 5),
        _positive_config_int("xxx_contact_sheet_max_videos", 6),
    )


def xxx_contact_sheet_animation_settings() -> tuple[bool, float]:
    """Return whether XXX contact sheets are animated and their duration."""
    animated = _as_bool(default_config.get("xxx_contact_sheet_animated_webp"), default=False)
    try:
        duration = max(0.1, float(default_config.get("xxx_contact_sheet_animation_seconds", 5) or 5))
    except TypeError, ValueError:
        duration = 5.0
    return animated, duration


def xxx_single_file_screens() -> int:
    """Return the number of normal screenshots to add for a single XXX video."""
    try:
        return max(0, int(default_config.get("xxx_single_file_screens", 0) or 0))
    except TypeError, ValueError:
        return 0


def _xxx_contact_sheet_fontfile() -> str | None:
    return overlay_fontfile()


def _xxx_contact_sheet_title_filter(stream: Any, title: str, include_title: bool, fontfile: str | None) -> Any:
    if not include_title or fontfile is None:
        return stream
    escaped_title = title.replace("\\", r"\\\\").replace(":", r"\:").replace("'", r"\'").replace("%", r"\%")
    return stream.filter("pad", width="iw", height="ih+44", x=0, y=44, color="black").filter(
        "drawtext", text=escaped_title, x="(w-text_w)/2", y=10, fontsize=24, fontcolor="white", fontfile=fontfile
    )


def _xxx_contact_sheet_timestamp_filter(stream: Any, timestamp: str, fontfile: str | None) -> Any:
    if fontfile is None:
        return stream
    return stream.filter("drawtext", text=timestamp, x=8, y="h-text_h-8", fontsize=18, fontcolor="white", box=1, boxcolor="black@0.65", boxborderw=4, fontfile=fontfile)


def _format_contact_sheet_timestamp(seconds: float) -> str:
    whole_seconds = max(0, int(seconds))
    hours, remainder = divmod(whole_seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}"


def _xxx_contact_sheet_static_stream(video_path: Path, frame_count: int, duration: float, columns: int, rows: int, fontfile: str | None) -> Any:
    stream = ffmpeg.input(str(video_path))
    stream = _xxx_contact_sheet_timestamp_filter(stream, r"%{pts\\:hms}", fontfile)
    return stream.filter("fps", fps=f"{frame_count}/{duration:.6f}").filter("scale", 320, -2).filter("tile", layout=f"{columns}x{rows}", margin=2, padding=2)


def _xxx_contact_sheet_animated_stream(video_path: Path, frame_count: int, duration: float, columns: int, rows: int, animation_seconds: float, fontfile: str | None) -> Any:
    max_start = max(0.0, duration - animation_seconds)
    streams = []
    for index in range(frame_count):
        start_time = max_start * index / max(frame_count - 1, 1)
        stream = ffmpeg.input(str(video_path), ss=start_time, t=animation_seconds).filter("fps", fps=8).filter("scale", 320, -2)
        stream = _xxx_contact_sheet_timestamp_filter(stream, _format_contact_sheet_timestamp(start_time), fontfile).filter("setpts", "PTS-STARTPTS")
        streams.append(stream)
    rows_streams = [ffmpeg.filter(streams[row * columns : (row + 1) * columns], "hstack", inputs=columns) for row in range(rows)]
    return ffmpeg.filter(rows_streams, "vstack", inputs=rows)


async def xxx_contact_sheets(paths: list[str], folder_id: str, base_dir: str, meta: Meta, capture_group: str = "main") -> list[str]:
    """Create one evenly sampled contact sheet for each selected XXX video."""
    rows, columns, max_videos = xxx_contact_sheet_settings()
    animated_webp, animation_seconds = xxx_contact_sheet_animation_settings()
    video_paths = [Path(path) for path in paths if Path(path).is_file()][:max_videos]
    if not video_paths:
        meta.screens = 0
        return []

    existing = manifest_files(base_dir, folder_id, capture_group)
    if meta.retake or (existing and len(existing) < len(video_paths)):
        clear_screenshot_group(base_dir, folder_id, capture_group)
        existing = []
    sheets = [str(path) for path in existing[: len(video_paths)]] if not meta.retake and len(existing) >= len(video_paths) else []

    if not sheets:
        screenshot_dir = screenshots_dir(base_dir, folder_id)
        results: list[str] = []
        frame_count = rows * columns
        fontfile = _xxx_contact_sheet_fontfile()
        if fontfile is None:
            logger.warning("[yellow]No system font found for XXX contact-sheet labels; generating sheets without labels.[/yellow]")
        for index, video_path in enumerate(video_paths, start=1):
            output_path = screenshot_dir / f"xxx-contact-sheet-{index}.{'webp' if animated_webp else 'png'}"
            if output_path.exists() and not meta.retake:
                results.append(str(output_path))
                continue

            try:
                probe = await asyncio.to_thread(ffmpeg.probe, str(video_path))
                duration = float(probe["format"]["duration"])
                if duration <= 0:
                    raise ValueError("duration must be positive")
                if animated_webp:
                    stream = _xxx_contact_sheet_animated_stream(video_path, frame_count, duration, columns, rows, animation_seconds, fontfile)
                    output_options: dict[str, Any] = {"vcodec": "libwebp_anim", "loop": 0, "r": 8, "t": animation_seconds}
                else:
                    stream = _xxx_contact_sheet_static_stream(video_path, frame_count, duration, columns, rows, fontfile)
                    output_options = {"vframes": 1, "compression_level": ffmpeg_compression}
                stream = _xxx_contact_sheet_title_filter(stream, video_path.name, len(video_paths) > 1, fontfile)
                command = ffmpeg.output(stream, str(output_path), **output_options).global_args("-y", "-loglevel", "verbose" if meta.ffdebug else "quiet")
                return_code, _stdout, stderr = await run_ffmpeg(command)
                if return_code != 0 or not output_path.is_file():
                    logger.warning(f"[yellow]Unable to create XXX contact sheet for {video_path.name}: {stderr.decode(errors='replace')}[/yellow]")
                    continue
                results.append(str(output_path))
            except Exception as error:
                logger.warning(f"[yellow]Unable to create XXX contact sheet for {video_path.name}: {error}[/yellow]")

        registered = register_screenshots(base_dir, folder_id, results, capture_group) if results else []
        await record_event_async("artifact", service="screenshot", operation="created", category="standard", count=len(registered))
        sheets = [str(path) for path in registered]
    normal_screens = xxx_single_file_screens()
    if len(video_paths) == 1 and normal_screens:
        existing_in_group = len(manifest_files(base_dir, folder_id, capture_group))
        screens_to_request = max(0, normal_screens + existing_in_group)
        await screenshots(
            str(video_paths[0]), video_paths[0].name, folder_id, base_dir, meta, screens_to_request, False, cleanup_after_capture=False, capture_group=capture_group
        )
    meta.screens = len(manifest_files(base_dir, folder_id, capture_group))
    return sheets


async def xxx_fallback_cover(paths: list[str], folder_id: str, base_dir: str, meta: Meta, random_frame: bool = False) -> str | None:
    """Create a poster from a representative frame when XXX has no artwork."""
    if meta.category != "XXX" or (is_valid_cover_image(meta.artwork_path) and not random_frame):
        return meta.artwork_path if is_valid_cover_image(meta.artwork_path) else None

    video_path: Path | None = None
    duration = 0.0
    for candidate in paths:
        candidate_path = Path(candidate)
        if not candidate_path.is_file():
            continue
        if candidate_path.suffix and candidate_path.suffix.casefold() not in VIDEO_EXTENSIONS:
            continue
        try:
            probe = await asyncio.to_thread(ffmpeg.probe, str(candidate_path))
            candidate_duration = float(probe["format"]["duration"])
            streams = probe.get("streams", [])
            has_video_stream = isinstance(streams, list) and any(isinstance(stream, Mapping) and stream.get("codec_type") == "video" for stream in streams)
            if candidate_duration <= 0 or not has_video_stream:
                continue
        except OSError, KeyError, TypeError, ValueError, ffmpeg.Error:
            continue
        video_path = candidate_path
        duration = candidate_duration
        break

    if video_path is None:
        logger.warning("[yellow]XXX has no valid video available to generate a fallback cover.[/yellow]")
        return None

    output_path = artwork_dir(base_dir, folder_id) / "POSTER.png"
    try:
        # Avoid the opening frame, which is frequently black or only a logo.
        lower = min(max(duration * 0.10, 1.0), max(duration - 0.1, 0.0))
        upper = max(lower, min(duration * 0.85, max(duration - 0.1, 0.0)))
        timestamp = secrets.SystemRandom().uniform(lower, upper) if random_frame and upper > lower else lower
        stream = ffmpeg.input(str(video_path), ss=str(timestamp))
        command = ffmpeg.output(
            stream,
            str(output_path),
            vframes=1,
            vf="scale=1200:-2:force_original_aspect_ratio=decrease",
            compression_level=ffmpeg_compression,
        ).global_args("-y", "-loglevel", "verbose" if meta.ffdebug else "quiet")
        return_code, _stdout, stderr = await run_ffmpeg(command)
        if return_code != 0 or not is_valid_cover_image(output_path):
            raise RuntimeError(stderr.decode(errors="replace").strip() or "FFmpeg did not produce a valid image")
    except Exception as error:
        logger.warning(f"[yellow]Unable to generate the XXX fallback cover from {video_path.name}: {error}[/yellow]")
        return None

    meta.artwork_path = str(output_path)
    meta.artwork_url = ""
    logger.warning(
        "[yellow]No XXX cover was found after checking, in order: explicit --poster, "
        "a local artwork sidecar, and provider artwork. For the local search, place a valid "
        "GIF/JPG/JPEG/PNG/WEBP image beside the media (or inside the release folder) with a "
        "filename containing one of: poster, cover, front, folder, artwork. "
        f"Generated a fallback cover from a video frame: {output_path.name}.[/yellow]"
    )
    return str(output_path)


def compile_ffmpeg_command(command: Any) -> list[str]:
    """Compile an ffmpeg-python command into subprocess-safe string arguments."""
    return [str(argument) for argument in command.compile()]


def get_ffmpeg_output_path(command: Any, cmd_list: list[str]) -> str:
    """Return ffmpeg-python's output filename without relying on argument order."""
    nodes = [getattr(command, "node", None)]
    visited: set[int] = set()

    while nodes:
        node = nodes.pop()
        if node is None or id(node) in visited:
            continue
        visited.add(id(node))

        kwargs = getattr(node, "kwargs", {})
        filename = kwargs.get("filename") if isinstance(kwargs, dict) else None
        if filename is not None:
            return str(filename)

        incoming_edges = getattr(node, "incoming_edges", ())
        nodes.extend(edge.upstream_node for edge in incoming_edges if getattr(edge, "upstream_node", None) is not None)

    # Keep compatibility with lightweight command doubles used by callers.
    return cmd_list[-1] if cmd_list else ""


algorithm = "mobius"
desat = 10.0


def _apply_config(config: Mapping[str, Any]) -> None:
    global default_config, task_limit, cutoff
    global ffmpeg_limit, ffmpeg_is_good, use_libplacebo
    global tone_map, ffmpeg_compression, algorithm, desat

    default_section = config.get("DEFAULT", {})
    default_config = cast(dict[str, Any], default_section) if isinstance(default_section, Mapping) else {}

    try:
        task_limit = int(default_config.get("process_limit", 1) or 1)
    except TypeError, ValueError:
        task_limit = 1

    try:
        cutoff = int(default_config.get("cutoff_screens", 1) or 1)
    except TypeError, ValueError:
        cutoff = 1

    ffmpeg_limit = default_config.get("ffmpeg_limit", False)
    ffmpeg_is_good = default_config.get("ffmpeg_is_good", False)
    use_libplacebo = default_config.get("use_libplacebo", True)
    tone_map = default_config.get("tone_map", False)
    ffmpeg_compression = str(default_config.get("ffmpeg_compression", "6"))
    algorithm = str(default_config.get("algorithm", "mobius")).strip()
    try:
        desat = float(default_config.get("desat", 10.0))
    except TypeError, ValueError:
        desat = 10.0


def discard_smallest_capture_result(capture_results: list[str]) -> str | None:
    """Delete and remove the smallest image produced by this capture batch."""
    smallest: str | None = None
    smallest_size = float("inf")
    for image in capture_results:
        try:
            image_size = Path(image).stat().st_size
        except FileNotFoundError:
            logger.info(f"[red]File not found: {image}[/red]")
            continue
        if image_size < smallest_size:
            smallest = image
            smallest_size = image_size

    if smallest is None:
        return None

    logger.debug(f"[yellow]Removing smallest image: {smallest} ({smallest_size} bytes)[/yellow]")
    Path(smallest).unlink()
    capture_results.remove(smallest)
    return smallest


def dvd_screenshot_has_content(path: str | Path) -> bool:
    """Reject unusually small, unreadable, and near-uniform DVD frames."""
    try:
        if Path(path).stat().st_size < 20 * 1024:
            return False
        with Image.open(path) as image:
            low, high = image.convert("L").getextrema()
            return high >= 10 and high - low >= 10
    except OSError, ValueError:
        return False


async def run_ffmpeg(command: Any) -> tuple[int | None, bytes, bytes]:
    cmd_list = compile_ffmpeg_command(command)
    process_env = os.environ.copy()

    # FFREPORT defaults to a timestamped file in the current working
    # directory.  Keep each report beside its output, with a unique name so
    # concurrent or repeated runs do not overwrite an earlier report.
    output_path = get_ffmpeg_output_path(command, cmd_list)
    if output_path and output_path not in {"-", "pipe:"} and not output_path.startswith("pipe:"):
        report_path = Path(output_path).resolve().parent / f"ffmpeg-{uuid.uuid4().hex}.log"
        report_path.parent.mkdir(parents=True, exist_ok=True)
        # FFREPORT uses ':' as a field separator, so escape the drive-letter
        # colon in Windows paths after converting separators to '/'.
        report_path_value = report_path.as_posix().replace(":", r"\:")
        process_env["FFREPORT"] = f"file={report_path_value}:level=32"
    else:
        process_env.pop("FFREPORT", None)

    if configured := configured_binary("ffmpeg_path", {"DEFAULT": default_config}):
        cmd_list[0] = configured
    # On Linux prefer bundled amd/arm binary when present; otherwise fall back to system ffmpeg.
    elif platform.system() == "Linux":
        base_dir = str(Path(__file__).parent.parent)
        ff_bin_dir = Path(base_dir) / "bin" / "ffmpeg"

        machine = platform.machine().lower()
        if machine in ("x86_64", "amd64"):
            arch = "amd"
        elif machine in ("aarch64", "arm64"):
            arch = "arm"
        else:
            arch = None

        if arch:
            candidate = Path(ff_bin_dir) / arch / "ffmpeg"
            if Path(candidate).exists():
                cmd_list[0] = str(candidate)

    # Spawn the selected bundled binary or the system/default command.
    process = await asyncio.create_subprocess_exec(
        *cmd_list,
        stdin=asyncio.subprocess.DEVNULL,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        env=process_env,
    )
    try:
        stdout, stderr = await process.communicate()
    except asyncio.CancelledError:
        if process.returncode is None:
            with contextlib.suppress(ProcessLookupError):
                process.terminate()
            try:
                await asyncio.wait_for(process.wait(), timeout=3)
            except TimeoutError:
                with contextlib.suppress(ProcessLookupError):
                    process.kill()
                await process.wait()
        raise
    return process.returncode, stdout, stderr


async def sanitize_filename(filename: str) -> str:
    # Replace invalid characters like colons with an underscore
    return re.sub(r'[<>:"/\\|?*]', "_", filename)


def round_to_even(value: float) -> int:
    rounded = round(value)
    if rounded % 2 != 0:
        rounded += 1
    return rounded


def _as_bool(value: Any, default: bool = False) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"true", "1", "yes", "on"}:
            return True
        if normalized in {"false", "0", "no", "off"}:
            return False
    return default


def should_scale_screenshots_for_par(config: Mapping[str, Any] | None = None) -> bool:
    """Return whether screenshots should be converted to square-pixel dimensions."""
    settings = default_config if config is None else config
    return _as_bool(settings.get("scale_screenshots_for_par"), default=False)


def should_scale_dvd_screenshots_for_par(config: Mapping[str, Any] | None = None) -> bool:
    """Return whether DVD screenshots should use display-corrected dimensions."""
    settings = default_config if config is None else config
    return _as_bool(settings.get("scale_dvd_screenshots_for_par"), default=True)


def screenshot_par_scale_factors(
    width: float,
    height: float,
    pixel_aspect_ratio: float,
    display_aspect_ratio: float,
    apply_par_scaling: bool | None = None,
) -> tuple[float, float]:
    """Return the width and height scale factors for a screenshot.

    Screenshots retain their MediaInfo-reported coded dimensions by default.
    PAR correction remains available for non-square-pixel sources when a user
    explicitly enables ``scale_screenshots_for_par``.
    """
    if apply_par_scaling is None:
        apply_par_scaling = should_scale_screenshots_for_par()
    if not apply_par_scaling or pixel_aspect_ratio == 1:
        return 1.0, 1.0
    if pixel_aspect_ratio < 1:
        new_height = display_aspect_ratio * height
        return 1.0, width / new_height
    return pixel_aspect_ratio, 1.0


@holds_slot("screenshots", "screenshot capture")
async def disc_screenshots(
    meta: Meta,
    filename: str,
    bdinfo: dict[str, Any],
    folder_id: str,
    base_dir: str,
    use_vs: bool,
    image_list: list[dict[str, str]] | None = None,
    ffdebug: bool = False,
    num_screens: int = 0,
    force_screenshots: bool = False,
    cleanup_after_capture: bool = True,
    capture_group: str | None = None,
) -> list[Path]:
    img_host = await get_image_host(meta)
    capture_group = capture_group or "main"
    screens = meta.screens
    if capture_group == "main":
        from src.screenshot_review import target_count

        screens = target_count(Path(base_dir) / "tmp" / folder_id, screens)
        meta.screens = screens
    start_time = time.time() if meta.debug else 0.0
    if "image_list" not in meta:
        meta.image_list = []
    image_list_entries = meta.image_list
    existing_images: list[dict[str, Any]] = [img for img in image_list_entries if str(img.get("img_url", "")).startswith("http")]

    if len(existing_images) >= cutoff and not force_screenshots:
        logger.info(f"[yellow]There are already at least {cutoff} images in the image list. Skipping additional screenshots.")
        return []

    if not num_screens:
        num_screens = screens
    if num_screens == 0 or (image_list and len(image_list) >= num_screens):
        return []

    sanitized_filename = await sanitize_filename(filename)
    length: float = 0.0
    file_path: str = ""
    frame_rate: float | None = None
    bdinfo_files = cast(list[dict[str, Any]], bdinfo.get("files", []))
    bdinfo_path = cast(str, bdinfo.get("path", ""))
    for each in bdinfo_files:
        # Calculate total length in seconds, including fractional part
        length_str = str(each.get("length", "0"))
        int_length = sum(float(x) * 60**i for i, x in enumerate(reversed(length_str.split(":"))))

        if int_length > length:
            length = int_length
            for root, _dirs, files in os.walk(bdinfo_path):
                for name in files:
                    if name.lower() == str(each.get("file", "")).lower():
                        file_path = Path(root) / name
                        break  # Stop searching once the file is found

    if bdinfo.get("video"):
        fps_string = bdinfo["video"][0].get("fps", None)
        if fps_string:
            try:
                frame_rate = float(fps_string.split(" ")[0])  # Extract and convert to float
            except ValueError:
                logger.error("[red]Error: Unable to parse frame rate from bdinfo['video'][0]['fps']")

    if frame_rate is not None:
        meta.frame_rate = frame_rate

    file_path = file_path

    keyframe = "nokey" if "VC-1" in bdinfo["video"][0]["codec"] or bdinfo["video"][0]["hdr_dv"] != "" else "none"
    logger.debug(f"File: {file_path}, Length: {length}, Frame Rate: {frame_rate}", extra={"markup": False})
    screenshot_dir = screenshots_dir(base_dir, folder_id)
    existing_screens = [p.name for p in manifest_files(base_dir, folder_id, capture_group)]
    total_existing = len(existing_screens) + len(existing_images)
    num_screens = max(0, screens - total_existing) if not force_screenshots else num_screens
    is_hdr = any(marker in meta.hdr for marker in ("HDR", "DV", "HLG"))
    if (tone_map or meta.force_tonemap) and is_hdr:
        hdr_tonemap = True
        meta.tonemapped = True
    else:
        hdr_tonemap = False

    if num_screens == 0 and not force_screenshots:
        logger.info("[bold green]Reusing existing screenshots. No additional screenshots needed.")
        return []

    if meta.debug and not force_screenshots:
        logger.info(f"[bold yellow]Saving Screens... Total needed: {screens}, Existing: {total_existing}, To capture: {num_screens}")

    ss_times = await valid_ss_time([], num_screens, length, frame_rate or 24.0, meta, retake=force_screenshots)

    if meta.frame_overlay and any(overlay_options(default_config)[key] for key in ("overlay_frame_number", "overlay_frame_type")):
        logger.info("[yellow]Getting frame information for overlays...")
        # Build list of (original_index, task) to preserve index correspondence
        frame_info_tasks_with_idx = [
            (i, get_frame_info(file_path, ss_times[i], meta))
            for i in range(num_screens + 1)
            if not (screenshot_dir / f"{sanitized_filename}-{len(existing_screens) + i}.png").exists() or meta.retake
        ]
        frame_info_results = await asyncio.gather(*[task for _, task in frame_info_tasks_with_idx])
        meta.frame_info_map = {}

        # Create a mapping from time to frame info using preserved indices
        for (orig_idx, _), info in zip(frame_info_tasks_with_idx, frame_info_results, strict=False):
            meta.frame_info_map[ss_times[orig_idx]] = info

        logger.debug(f"[cyan]Collected frame information for {len(frame_info_results)} frames")

    num_workers = min(num_screens, task_limit)

    logger.debug(f"Using {num_workers} worker(s) for {num_screens} image(s)")

    capture_tasks: list[Awaitable[tuple[int, str] | None]] = []
    capture_results: list[str] = []
    valid_results: list[str] = []
    remaining_retakes: list[str] = []
    if use_vs:
        from src.vs import vs_screengn

        before = {path.resolve() for path in screenshot_dir.glob("*.png")}
        vs_screengn(source=file_path, encode=None, num=num_screens, dir=f"{screenshot_dir}/", config=default_config, overlays_enabled=meta.frame_overlay)
        for image_path in screenshot_dir.glob("*.png"):
            if image_path.resolve() in before:
                continue
            image_size = image_path.stat().st_size
            if img_host == "lostimg" and not is_valid_lostimg_image_size(image_size):
                logger.info(f"[red]Image {image_path} with size {image_size} bytes: does not meet size requirements for {img_host}, skipping.[/red]")
                continue
            valid_results.append(str(image_path))
    else:
        loglevel = "verbose" if ffdebug else "quiet"

        existing_indices = set(range(len(existing_screens)))

        # Create semaphore to limit concurrent tasks
        semaphore = asyncio.Semaphore(task_limit)

        async def capture_disc_with_semaphore(
            index: int, file: str, ss_time: str, image_path: str, keyframe: str, loglevel: str, hdr_tonemap: bool, meta: Meta
        ) -> tuple[int, str] | None:
            async with semaphore:
                return await capture_disc_task(index, file, ss_time, image_path, keyframe, loglevel, hdr_tonemap, meta)

        capture_tasks = [
            capture_disc_with_semaphore(
                i,
                file_path,
                ss_times[i],
                str((screenshot_dir / f"{sanitized_filename}-{len(existing_indices) + i}.png").resolve()),
                keyframe,
                loglevel,
                hdr_tonemap,
                meta,
            )
            for i in range(num_screens + 1)
        ]

        results = await asyncio.gather(*capture_tasks)
        filtered_results: list[tuple[int, str]] = [r for r in results if r is not None]

        if len(filtered_results) != len(results):
            logger.warning(f"[yellow]Warning: {len(results) - len(filtered_results)} capture tasks returned invalid results.")

        filtered_results.sort(key=lambda x: x[0])  # Ensure order is preserved
        capture_results = [r[1] for r in filtered_results]

        if capture_results and len(capture_results) > num_screens:
            try:
                smallest: str = min(capture_results, key=os.path.getsize)
                logger.debug(f"[yellow]Removing smallest image: {smallest} ({Path(smallest).stat().st_size} bytes)")
                Path(smallest).unlink()
                capture_results.remove(smallest)
            except Exception as e:
                logger.error(f"[red]Error removing smallest image: {e!s}")

        if not force_screenshots and meta.debug:
            logger.info(f"[green]Successfully captured {len(capture_results)} screenshots.")

        valid_results = []
        remaining_retakes = []
        for image_path in capture_results:
            if "Error" in image_path:
                logger.info(f"[red]{image_path}")
                continue

            retake = False
            image_size = Path(image_path).stat().st_size
            logger.debug(f"[yellow]Checking image {image_path} (size: {image_size} bytes) for image host: {img_host}[/yellow]")
            if image_size <= 75000:
                logger.info(f"[yellow]Image {image_path} is incredibly small, retaking.")
                retake = True
            else:
                if img_host and "imgbb" in img_host:
                    if image_size <= 31000000:
                        logger.debug(f"[green]Image {image_path} meets size requirements for imgbb.[/green]")
                    else:
                        logger.info(f"[red]Image {image_path} with size {image_size} bytes: does not meet size requirements for imgbb, retaking.")
                        retake = True
                elif img_host and img_host in ["imgbox", "pixhost"]:
                    if 75000 < image_size <= 10000000:
                        logger.debug(f"[green]Image {image_path} meets size requirements for {img_host}.[/green]")
                    else:
                        logger.info(f"[red]Image {image_path} with size {image_size} bytes: does not meet size requirements for {img_host}, retaking.")
                        retake = True
                elif img_host == "lostimg":
                    if is_valid_lostimg_image_size(image_size):
                        logger.debug(f"[green]Image {image_path} meets size requirements for {img_host}.[/green]")
                    else:
                        logger.info(f"[red]Image {image_path} with size {image_size} bytes: does not meet size requirements for {img_host}, retaking.")
                        retake = True
                elif img_host and img_host in [
                    "lensdump",
                    "ptscreens",
                    "onlyimage",
                    "dalexni",
                    "zipline",
                    "midnightscene",
                    "bioma",
                    "passtheimage",
                    "seedpool_cdn",
                    "sharex",
                    "thrimg",
                    "utppm",
                ]:
                    logger.debug(f"[green]Image {image_path} meets size requirements for {img_host}.[/green]")
                else:
                    logger.info(f"[red]Unknown image host or image doesn't meet requirements for host: {img_host}, retaking.")
                    retake = True

            if retake:
                retry_attempts = 3
                for attempt in range(1, retry_attempts + 1):
                    logger.info(f"[yellow]Retaking screenshot for: {image_path} (Attempt {attempt}/{retry_attempts})[/yellow]")
                    try:
                        index = int(image_path.rsplit("-", 1)[-1].split(".")[0])
                        if Path(image_path).exists():
                            Path(image_path).unlink()

                        random_time = random.uniform(0, length)  # nosec B311 - Random screenshot timing, not cryptographic  # noqa: S311
                        screenshot_response = await capture_disc_task(index, file_path, str(random_time), image_path, keyframe, loglevel, hdr_tonemap, meta)
                        new_size = Path(image_path).stat().st_size
                        valid_image = False

                        if img_host and "imgbb" in img_host:
                            if new_size > 75000 and new_size <= 31000000:
                                logger.info(f"[green]Successfully retaken screenshot for: {image_path} ({new_size} bytes)[/green]")
                                valid_image = True
                        elif img_host and img_host in ["imgbox", "pixhost"]:
                            if new_size > 75000 and new_size <= 10000000:
                                logger.info(f"[green]Successfully retaken screenshot for: {image_path} ({new_size} bytes)[/green]")
                                valid_image = True
                        elif img_host == "lostimg":
                            if is_valid_lostimg_image_size(new_size):
                                logger.info(f"[green]Successfully retaken screenshot for: {image_path} ({new_size} bytes)[/green]")
                                valid_image = True
                        elif (
                            img_host
                            and img_host
                            in [
                                "lensdump",
                                "ptscreens",
                                "onlyimage",
                                "dalexni",
                                "zipline",
                                "midnightscene",
                                "bioma",
                                "passtheimage",
                                "seedpool_cdn",
                                "sharex",
                                "thrimg",
                                "utppm",
                            ]
                            and new_size > 75000
                        ):
                            logger.info(f"[green]Successfully retaken screenshot for: {image_path} ({new_size} bytes)[/green]")
                            valid_image = True

                        if valid_image:
                            valid_results.append(image_path)
                            break
                        logger.info(f"[red]Retaken image {screenshot_response} does not meet the size requirements for {img_host}. Retrying...[/red]")
                    except Exception as e:
                        logger.error(f"[red]Error retaking screenshot for {image_path}: {e}[/red]")
                else:
                    logger.info(f"[red]All retry attempts failed for {image_path}. Skipping.[/red]")
                    remaining_retakes.append(image_path)
            else:
                valid_results.append(image_path)

        if remaining_retakes:
            logger.info(f"[red]The following images could not be retaken successfully: {remaining_retakes}[/red]")

    if not force_screenshots and meta.debug:
        logger.info(f"[green]Successfully captured {len(valid_results)} screenshots.")

    if meta.debug:
        finish_time = time.time()
        logger.debug(f"Screenshots processed in {finish_time - start_time:.4f} seconds")

    # The temporary descriptive names above are only used while capture is in
    # progress.  Publish completed frames under opaque UUID filenames.
    registered = register_screenshots(base_dir, folder_id, valid_results, capture_group) if valid_results else []
    await record_event_async("artifact", service="screenshot", operation="created", category="standard", count=len(registered))

    multi_screens = int(default_config.get("multiScreens", 2))
    discs = meta.discs
    one_disc = True
    if discs and len(discs) == 1:
        one_disc = True
    elif discs and len(discs) > 1:
        one_disc = False

    if cleanup_after_capture and ((not meta.tv_pack and one_disc) or multi_screens == 0):
        await cleanup_manager.cleanup()
    return registered


async def capture_disc_task(index: int, file: str, ss_time: str, image_path: str, keyframe: str, loglevel: str, hdr_tonemap: bool, meta: Meta) -> tuple[int, str] | None:
    try:
        # Build filter chain
        vf_filters: list[str] = []

        if hdr_tonemap:
            vf_filters.extend(["zscale=transfer=linear", f"tonemap=tonemap={algorithm}:desat={desat}", "zscale=transfer=bt709", "format=rgb24"])

        vf_filters.extend(overlay_filters(default_config, meta, ss_time, hdr_tonemap))

        # Build command
        # Always ensure at least format filter is present for PNG compression to work
        if not vf_filters:
            vf_filters.append("format=rgb24")
        vf_chain = ",".join(vf_filters)

        # Build ffmpeg-python command and run via run_ffmpeg
        info_command: Any = (
            cast(Any, ffmpeg)
            .input(file, ss=ss_time, skip_frame=keyframe)
            .output(image_path, vframes=1, vf=vf_chain, compression_level=ffmpeg_compression, pred="mixed")
            .global_args("-y", "-loglevel", loglevel, "-hide_banner")
        )

        if loglevel == "verbose" or (meta and meta.debug):
            logger.info(f"[cyan]FFmpeg command: {' '.join(compile_ffmpeg_command(info_command))}[/cyan]")

        returncode, stdout, stderr = await run_ffmpeg(info_command)

        # Print stdout and stderr if in verbose mode
        if loglevel == "verbose":
            if stdout:
                logger.info(f"[blue]FFmpeg stdout:[/blue]\n{stdout.decode('utf-8', errors='replace')}")
            if stderr:
                logger.info(f"[yellow]FFmpeg stderr:[/yellow]\n{stderr.decode('utf-8', errors='replace')}")

        if returncode == 0:
            return (index, image_path)
        logger.info(f"[red]FFmpeg error capturing screenshot: {stderr.decode(errors='replace')}")
        return None  # Ensure tuple format
    except Exception as e:
        logger.error(f"[red]Error capturing screenshot: {e}")
        return None


async def matching_dvd_title(disc_path: Path, expected_duration: float) -> int | None:
    """Find the DVD title whose playback duration matches the selected IFO."""
    if expected_duration <= 0 or not (disc_path / "VIDEO_TS.IFO").is_file():
        return None
    try:
        probe_binary = configured_binary("ffprobe_path", {"DEFAULT": default_config}) or "ffprobe"
    except FileNotFoundError:
        return None

    for title in range(1, 100):
        try:
            info = await asyncio.to_thread(ffmpeg.probe, str(disc_path), cmd=probe_binary, f="dvdvideo", title=title)
            duration = float(info["format"]["duration"])
        except ffmpeg.Error, FileNotFoundError, KeyError, TypeError, ValueError, OSError:
            continue
        if abs(duration - expected_duration) <= max(30.0, expected_duration * 0.02):
            return title
    return None


@holds_slot("screenshots", "screenshot capture")
async def dvd_screenshots(
    meta: Meta,
    disc_num: int,
    num_screens: int = 0,
    retry_cap: bool = False,
    cleanup_after_capture: bool = True,
) -> None:
    screens = meta.screens
    if "image_list" not in meta:
        meta.image_list = []
    image_list_entries = meta.image_list
    existing_images: list[dict[str, Any]] = [img for img in image_list_entries if str(img.get("img_url", "")).startswith("http")]

    if len(existing_images) >= cutoff and not retry_cap:
        logger.info(f"[yellow]There are already at least {cutoff} images in the image list. Skipping additional screenshots.")
        return
    screens = meta.screens if meta.screens is not None else 6
    if not num_screens:
        num_screens = screens - len(existing_images)
    if num_screens == 0 or (len(meta.image_list) >= screens and disc_num == 0):
        return

    capture_group = "main" if disc_num == 0 else f"FILE_{disc_num}"
    sanitized_disc_name = await sanitize_filename(meta.discs[disc_num]["name"])
    screenshot_dir = screenshots_dir(meta.base_dir, meta.uuid)
    existing_screens = [str(p) for p in manifest_files(meta.base_dir, meta.uuid, capture_group)]
    normal_screens = []
    for image in existing_screens:
        if dvd_screenshot_has_content(image):
            normal_screens.append(image)
            continue
        logger.info(f"[yellow]Removing blank or unreadable registered DVD screenshot: {image}[/yellow]")
        Path(image).unlink(missing_ok=True)
        forget_screenshot_file(meta.base_dir, meta.uuid, Path(image))
    num_screens = max(0, num_screens - len(normal_screens))
    if num_screens == 0:
        logger.info("[bold green]Reusing screenshots")
        return

    ifo_mi = MediaInfo.parse(f"{meta.discs[disc_num]['path']}/VTS_{meta.discs[disc_num]['main_set'][0][:2]}_0.IFO", mediainfo_options={"inform_version": "1"})
    w_sar = 1.0
    h_sar = 1.0
    par: float = 1.0
    dar: float = 1.0
    width: float = 0.0
    height: float = 0.0
    frame_rate: float = 24.0
    ifo_duration = 0.0
    tracks: list[Any] = []
    tracks.extend(cast(list[Any], getattr(ifo_mi, "tracks", [])))
    for track in tracks:
        if track.track_type == "Video":
            if isinstance(track.duration, str):
                durations = [float(d) for d in track.duration.split(" / ")]
                ifo_duration = max(durations) / 1000
            else:
                ifo_duration = float(track.duration) / 1000

            par = float(track.pixel_aspect_ratio)
            dar = float(track.display_aspect_ratio)
            width = float(track.width)
            height = float(track.height)
            frame_rate = float(track.frame_rate)
    meta.frame_rate = frame_rate
    w_sar, h_sar = screenshot_par_scale_factors(width, height, par, dar, should_scale_dvd_screenshots_for_par())

    main_set = meta.discs[disc_num]["main_set"]
    content_vobs = [vob for vob in main_set if not vob.upper().endswith("_0.VOB")] or main_set
    title_vobs = [str(Path(meta.discs[disc_num]["path"]) / f"VTS_{vob}") for vob in content_vobs]
    disc_path = Path(meta.discs[disc_num]["path"])
    dvd_title = await matching_dvd_title(disc_path, ifo_duration)
    input_file = title_vobs[0] if len(title_vobs) == 1 else f"concat:{'|'.join(title_vobs)}"
    voblength = 0.0
    for title_vob in title_vobs:
        try:
            vob_mi = json.loads(MediaInfo.parse(title_vob, output="JSON"))
            video_durations = [
                float(track.get("Duration", 0))
                for track in vob_mi.get("media", {}).get("track", [])
                if track.get("Width") and track.get("Height") and float(track.get("Duration", 0)) > 1
            ]
            if video_durations:
                voblength += max(video_durations)
        except Exception as e:
            logger.error(f"[red]Error parsing VOB {title_vob}: {e}")
    if not voblength:
        voblength = 300
    if ifo_duration:
        voblength = ifo_duration
    ss_times = await valid_ss_time([], num_screens, voblength, frame_rate, meta, retake=retry_cap)
    image_paths: list[str] = []
    input_files: list[str] = []

    for i in range(num_screens + 1):
        image = str(screenshot_dir / f"{sanitized_disc_name}-{i}.png")
        image_paths.append(image)
        input_files.append(input_file)

    if meta.frame_overlay and any(overlay_options(default_config)[key] for key in ("overlay_frame_number", "overlay_frame_type")):
        logger.debug("[yellow]Getting frame information for overlays...")
        frame_info_tasks = [get_frame_info(input_files[i], ss_times[i], meta, dvd_title=dvd_title) for i in range(num_screens + 1)]

        frame_info_results = await asyncio.gather(*frame_info_tasks)
        meta.frame_info_map = {}

        for i, info in enumerate(frame_info_results):
            meta.frame_info_map[ss_times[i]] = info

        logger.debug(f"[cyan]Collected frame information for {len(frame_info_results)} frames")

    num_workers = min(num_screens + 1, task_limit)

    logger.debug(f"Using {num_workers} worker(s) for {num_screens} image(s)")

    # Create semaphore to limit concurrent tasks
    semaphore = asyncio.Semaphore(task_limit)

    async def capture_dvd_with_semaphore(args: tuple[int, str, str, str, Meta, float, float, float, float, int | None]) -> tuple[int, str | None]:
        async with semaphore:
            return await capture_dvd_screenshot(args)

    capture_tasks = [capture_dvd_with_semaphore((i, input_files[i], image_paths[i], ss_times[i], meta, width, height, w_sar, h_sar, dvd_title)) for i in range(num_screens + 1)]

    capture_results: list[str] = []
    results = await asyncio.gather(*capture_tasks)
    filtered_results: list[tuple[int, str | None]] = list(results)

    if len(filtered_results) != len(results):
        logger.warning(f"[yellow]Warning: {len(results) - len(filtered_results)} capture tasks returned invalid results.")

    filtered_results.sort(key=lambda x: x[0])  # Ensure order is preserved
    capture_results = [r[1] for r in filtered_results if r[1] is not None]

    valid_results: list[str] = []
    remaining_retakes: list[str] = []

    for image in capture_results:
        if "Error" in image:
            logger.info(f"[red]{image}")
            continue

        if not dvd_screenshot_has_content(image):
            logger.info(f"[yellow]Image {image} is blank or unreadable, retaking.[/yellow]")
            retry_attempts = 8
            retry_times = [
                random.uniform(voblength * (0.05 + 0.85 * i / retry_attempts), voblength * (0.05 + 0.85 * (i + 1) / retry_attempts))  # nosec B311  # noqa: S311
                for i in range(retry_attempts)
            ]
            random.shuffle(retry_times)  # nosec B311 - Random screenshot timing, not cryptographic
            retry_image = str(Path(image).with_name(f"{Path(image).stem}-retry.png"))
            for attempt, adjusted_time in enumerate(retry_times, start=1):
                logger.info(f"[yellow]Retaking screenshot for: {image} (Attempt {attempt}/{retry_attempts})[/yellow]")

                index = int(image.rsplit("-", 1)[-1].split(".")[0])

                try:
                    Path(retry_image).unlink(missing_ok=True)
                    screenshot_response = await capture_dvd_screenshot((index, input_file, retry_image, str(adjusted_time), meta, width, height, w_sar, h_sar, dvd_title))

                    index, screenshot_result = screenshot_response  # Safe unpacking

                    if screenshot_result is None:
                        logger.error(f"[red]Failed to capture screenshot for {image}. Retrying...[/red]")
                        continue

                    if dvd_screenshot_has_content(screenshot_result):
                        retaken_size = Path(screenshot_result).stat().st_size
                        Path(screenshot_result).replace(image)
                        logger.info(f"[green]Successfully retaken screenshot for: {image} ({retaken_size} bytes)[/green]")
                        valid_results.append(image)
                        break
                    logger.info(f"[red]Retaken image {screenshot_result} is blank or unreadable. Retrying...[/red]")
                except Exception as e:
                    logger.error(f"[red]Error capturing screenshot for {input_file} at {adjusted_time}: {e}[/red]")
                finally:
                    Path(retry_image).unlink(missing_ok=True)

            else:
                logger.info(f"[red]All retry attempts failed for {image}. Skipping.[/red]")
                Path(image).unlink(missing_ok=True)
                remaining_retakes.append(image)
        else:
            valid_results.append(image)
    if len(valid_results) > num_screens:
        discard_smallest_capture_result(valid_results)
    if remaining_retakes:
        logger.info(f"[red]The following images could not be retaken successfully: {remaining_retakes}[/red]")

    if valid_results:
        registered = register_screenshots(meta.base_dir, meta.uuid, valid_results, capture_group)
        await record_event_async("artifact", service="screenshot", operation="created", category="standard", count=len(registered))

    if not retry_cap and meta.debug:
        logger.info(f"[green]Successfully captured {len(valid_results)} screenshots.")

    multi_screens = int(default_config.get("multiScreens", 2))
    discs = meta.discs
    one_disc = True
    if discs and len(discs) == 1:
        one_disc = True
    elif discs and len(discs) > 1:
        one_disc = False

    if cleanup_after_capture and ((not meta.tv_pack and one_disc) or multi_screens == 0):
        await cleanup_manager.cleanup()


async def capture_dvd_screenshot(
    task: tuple[int, str, str, str, Meta, float, float, float, float] | tuple[int, str, str, str, Meta, float, float, float, float, int | None],
) -> tuple[int, str | None]:
    index, input_file, image, seek_time_str, meta, width, height, w_sar, h_sar, *title_option = task
    dvd_title = title_option[0] if title_option else None
    seek_time = float(seek_time_str)

    try:
        loglevel = "verbose" if meta.ffdebug else "quiet"
        # Build filter chain
        vf_filters: list[str] = []
        if w_sar != 1 or h_sar != 1:
            scaled_w = round_to_even(width * w_sar)
            scaled_h = round_to_even(height * h_sar)
            vf_filters.append(f"scale={scaled_w}:{scaled_h}")

        vf_filters.extend(overlay_filters(default_config, meta, seek_time, False, dvd=True))

        # Build command
        # Always ensure at least format filter is present for PNG compression to work
        if not vf_filters:
            vf_filters.append("format=rgb24")
        vf_chain = ",".join(vf_filters)

        # Build ffmpeg-python command and run via run_ffmpeg
        input_options: dict[str, Any] = {}
        output_options: dict[str, Any] = {"ss": str(seek_time)}
        source = input_file
        if dvd_title is not None:
            input_options.update(format="dvdvideo", title=dvd_title, ss=str(seek_time))
            output_options.clear()
            source = str(Path(input_file.removeprefix("concat:").split("|", 1)[0]).parent)
        info_command: Any = (
            cast(Any, ffmpeg)
            .input(source, **input_options)
            .output(image, vframes=1, vf=vf_chain, compression_level=ffmpeg_compression, pred="mixed", update=1, **output_options)
            .global_args("-y", "-loglevel", loglevel, "-hide_banner")
        )

        if loglevel == "verbose" or (meta and meta.debug):
            logger.info(f"[cyan]FFmpeg command: {' '.join(compile_ffmpeg_command(info_command))}[/cyan]")

        returncode, _stdout, stderr = await run_ffmpeg(info_command)

        if returncode != 0 and dvd_title is not None:
            logger.warning(f"[yellow]DVD title capture failed at {seek_time}s; retrying with VOB decoding.[/yellow]")
            Path(image).unlink(missing_ok=True)
            fallback_command: Any = (
                cast(Any, ffmpeg)
                .input(input_file)
                .output(image, ss=str(seek_time), vframes=1, vf=vf_chain, compression_level=ffmpeg_compression, pred="mixed", update=1)
                .global_args("-y", "-loglevel", loglevel, "-hide_banner")
            )
            returncode, _stdout, stderr = await run_ffmpeg(fallback_command)

        if returncode != 0:
            logger.error(f"[red]Error capturing screenshot for {input_file} at {seek_time}s:[/red]\n{stderr.decode(errors='replace')}")
            return (index, None)

        if Path(image).exists():
            return (index, image)
        logger.info(f"[red]Screenshot creation failed for {image}[/red]")
        return (index, None)

    except Exception as e:
        logger.error(f"[red]Error capturing screenshot for {input_file} at {seek_time}s: {e}[/red]")
        return (index, None)


async def extract_embedded_cover_from_audiobook(meta: Meta, dest_path: str, confirmed_only: bool = False) -> bool:
    import mutagen

    def _extract():
        filelist = meta.filelist
        if not filelist:
            p = meta.path
            if p and Path(p).is_file():
                filelist = [p]
            else:
                return False

        audio_extensions = {".mp3", ".m4b", ".flac", ".aac", ".m4a", ".ogg", ".wav"}

        for audio_path in filelist:
            ext = Path(audio_path).suffix.lower()
            if ext not in audio_extensions:
                continue
            if not Path(audio_path).exists():
                continue

            try:
                audio = mutagen.File(audio_path)
                if audio is None:
                    continue

                # 1. FLAC / OGG pictures
                if hasattr(audio, "pictures") and audio.pictures:
                    pic = None
                    if confirmed_only:
                        for p in audio.pictures:
                            if getattr(p, "type", None) == 3:
                                pic = p
                                break
                    else:
                        pic = audio.pictures[0]

                    if pic is not None:
                        with Path(dest_path).open("wb") as f:
                            f.write(pic.data)
                        return True

                # 2. MP3 ID3 APIC
                if audio.tags:
                    apic_to_use = None
                    for key in audio.tags:
                        if key.startswith("APIC"):
                            apic = audio.tags[key]
                            if getattr(apic, "type", None) == 3:
                                apic_to_use = apic
                                break

                    if not apic_to_use and not confirmed_only:
                        for key in audio.tags:
                            if key.startswith("APIC"):
                                apic_to_use = audio.tags[key]
                                break

                    if apic_to_use is not None:
                        with Path(dest_path).open("wb") as f:
                            f.write(apic_to_use.data)
                        return True

                # 3. MP4 / M4A / M4B
                if "covr" in audio:
                    covr = audio["covr"]
                    if isinstance(covr, list) and len(covr) > 0:
                        item = covr[0]
                        with Path(dest_path).open("wb") as f:
                            f.write(bytes(item))
                        return True
            except Exception as e:
                logger.debug(f"[yellow]Error extracting from {audio_path}: {e}[/yellow]")
        return False

    try:
        return await asyncio.to_thread(_extract)
    except Exception as e:
        logger.info(f"[yellow]Error extracting embedded cover: {e}[/yellow]")
        return False


async def download_artwork_from_meta(meta: Meta, artwork_path: str, *, force: bool = False) -> bool:
    artwork_url = meta.artwork_url
    if not artwork_url:
        return False

    if not force and is_valid_cover_image(artwork_path):
        meta.artwork_path = artwork_path
        return True
    try:
        import httpx

        cookies = {}
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"}
        parsed_poster_url = urllib.parse.urlparse(artwork_url)
        poster_host = (parsed_poster_url.hostname or "").lower()
        if poster_host == "myanonamouse.net" or poster_host.endswith(".myanonamouse.net"):
            api_key = (
                default_config.get("mam_api_key", "").strip()
                or default_config.get("mam_id", "").strip()
                or os.environ.get("MAM_API_KEY", "").strip()
                or os.environ.get("MAM_ID", "").strip()
            )
            if api_key:
                cookies["mam_id"] = api_key

        current_url = artwork_url
        async with httpx.AsyncClient(timeout=30.0, follow_redirects=False) as client:
            for _ in range(4):
                if not is_public_http_url(current_url):
                    logger.warning("[yellow]Warning: Artwork download target is not a public HTTP(S) URL.[/yellow]")
                    return False
                response = await client.get(current_url, cookies=cookies, headers=headers)
                if response.is_redirect:
                    location = response.headers.get("Location")
                    if not location:
                        return False
                    current_url = urllib.parse.urljoin(current_url, location)
                    continue
                if response.status_code == 200:
                    if not is_valid_image_bytes(response.content):
                        logger.info("[yellow]Warning: Downloaded artwork is not a valid supported image and will be ignored.[/yellow]")
                        return False
                    await asyncio.to_thread(Path(artwork_path).write_bytes, response.content)
                    if not is_valid_cover_image(artwork_path):
                        return False
                    meta.artwork_path = artwork_path
                    logger.info(f"[green]Successfully downloaded artwork from {current_url}[/green]")
                    return True
                logger.warning(f"[yellow]Warning: Failed to download poster, status code {response.status_code}[/yellow]")
                return False
            logger.warning("[yellow]Warning: Artwork download exceeded the redirect limit.[/yellow]")
    except Exception as e:
        logger.warning(f"[yellow]Warning: Error downloading poster: {e}[/yellow]")
    return False


async def extract_epub_cover(epub_path: str, dest_path: str, confirmed_only: bool = False) -> bool:
    def _extract():
        if not Path(epub_path).is_file() or not zipfile.is_zipfile(epub_path):
            return False
        with contextlib.suppress(Exception), zipfile.ZipFile(epub_path, "r") as z:
            rootfile_path = None
            with contextlib.suppress(Exception):
                container_data = z.read("META-INF/container.xml")
                root = ET.fromstring(container_data)
                for elem in root.iter():
                    if elem.tag.endswith("rootfile"):
                        rootfile_path = elem.attrib.get("full-path")
                        if rootfile_path:
                            break

            if not rootfile_path:
                for name in z.namelist():
                    if name.endswith(".opf"):
                        rootfile_path = name
                        break

            if not rootfile_path:
                return False

            opf_data = z.read(rootfile_path)
            root = ET.fromstring(opf_data)

            manifest_items = {}
            cover_item_id = None
            cover_href_direct = None
            opf_dir = str(Path(rootfile_path).parent)

            for elem in root.iter():
                tag_local = elem.tag.split("}")[-1]
                if tag_local == "item":
                    item_id = elem.attrib.get("id")
                    href = elem.attrib.get("href")
                    properties = elem.attrib.get("properties", "")
                    media_type = elem.attrib.get("media-type", "").lower()
                    if item_id and href:
                        manifest_items[item_id] = {"href": href, "media-type": media_type, "properties": properties}
                        if "cover-image" in properties:
                            cover_href_direct = href
                elif tag_local == "meta":
                    name_attr = elem.attrib.get("name")
                    content_attr = elem.attrib.get("content")
                    if name_attr == "cover" and content_attr:
                        cover_item_id = content_attr

            def resolve_path(base_dir: str, rel_path: str) -> str:
                combined = Path(base_dir) / rel_path.replace("\\", "/") if base_dir else rel_path.replace("\\", "/")
                parts = []
                for part in combined.split("/"):
                    if part == "." or not part:
                        continue
                    if part == "..":
                        if parts:
                            parts.pop()
                    else:
                        parts.append(part)
                return "/".join(parts)

            def is_image_item(href: str, media_type: str) -> bool:
                if media_type.startswith("image/"):
                    return True
                return href.lower().endswith((".jpg", ".jpeg", ".png", ".gif", ".webp", ".svg"))

            def get_image_from_html(html_href: str) -> str | None:
                with contextlib.suppress(Exception):
                    html_zip_path = resolve_path(opf_dir, html_href)
                    zip_names = z.namelist()
                    matched_name = None
                    if html_zip_path in zip_names:
                        matched_name = html_zip_path
                    else:
                        for name in zip_names:
                            if name.lower() == html_zip_path.lower():
                                matched_name = name
                                break
                    if matched_name:
                        html_content = z.read(matched_name).decode("utf-8", errors="ignore")
                        img_match = re.search(r'<img[^>]+src=["\']([^"\']+)["\']', html_content, re.IGNORECASE)
                        if img_match:
                            img_src = urllib.parse.unquote(img_match.group(1))
                            html_dir = str(Path(html_zip_path).parent)
                            return resolve_path(html_dir, img_src)
                        svg_match = re.search(r'<image[^>]+(?:xlink:)?href=["\']([^"\']+)["\']', html_content, re.IGNORECASE)
                        if svg_match:
                            img_src = urllib.parse.unquote(svg_match.group(1))
                            html_dir = str(Path(html_zip_path).parent)
                            return resolve_path(html_dir, img_src)
                return None

            cover_zip_path = None

            # 1. Properties has "cover-image"
            if cover_href_direct:
                cover_zip_path = resolve_path(opf_dir, cover_href_direct)

            # 2. Meta cover tag points to an item ID
            if not cover_zip_path and cover_item_id and cover_item_id in manifest_items:
                item = manifest_items[cover_item_id]
                if is_image_item(item["href"], item["media-type"]):
                    cover_zip_path = resolve_path(opf_dir, item["href"])
                elif item["media-type"] in ("application/xhtml+xml", "text/html") or item["href"].lower().endswith((".xhtml", ".html", ".htm")):
                    cover_zip_path = get_image_from_html(item["href"])

            # 3. Item with standard IDs
            if not cover_zip_path:
                for item_id in ("cover", "cover-image", "coverimage"):
                    if item_id in manifest_items:
                        item = manifest_items[item_id]
                        if is_image_item(item["href"], item["media-type"]):
                            cover_zip_path = resolve_path(opf_dir, item["href"])
                            break
                        if item["media-type"] in ("application/xhtml+xml", "text/html") or item["href"].lower().endswith((".xhtml", ".html", ".htm")):
                            cover_zip_path = get_image_from_html(item["href"])
                            if cover_zip_path:
                                break

            if confirmed_only and not cover_zip_path:
                return False

            # 4. Any image item with "cover" in its ID or href
            if not cover_zip_path and not confirmed_only:
                for item_id, item in manifest_items.items():
                    if is_image_item(item["href"], item["media-type"]) and ("cover" in item_id.lower() or "cover" in item["href"].lower()):
                        cover_zip_path = resolve_path(opf_dir, item["href"])
                        break

            # 5. Search zip entries for names containing "cover" and ending with image extensions
            if not cover_zip_path and not confirmed_only:
                for name in z.namelist():
                    base = Path(name).name.lower()
                    if "cover" in base and base.endswith((".jpg", ".jpeg", ".png", ".webp", ".svg")):
                        cover_zip_path = name
                        break

            # 6. First image item in manifest
            if not cover_zip_path and not confirmed_only:
                for item in manifest_items.values():
                    if is_image_item(item["href"], item["media-type"]):
                        cover_zip_path = resolve_path(opf_dir, item["href"])
                        break

            if cover_zip_path:
                zip_names = z.namelist()
                matched_name = None
                if cover_zip_path in zip_names:
                    matched_name = cover_zip_path
                else:
                    cover_zip_path_lower = cover_zip_path.lower()
                    for name in zip_names:
                        if name.lower() == cover_zip_path_lower:
                            matched_name = name
                            break

                if matched_name:
                    with Path(dest_path).open("wb") as dest:
                        dest.write(z.read(matched_name))
                    return True
        return False

    return await asyncio.to_thread(_extract)


async def extract_document_cover(path: str, dest_path: str) -> Path | None:
    extension = Path(path).suffix.lower().lstrip(".")
    if extension not in {"pdf", "cbr", "cbz"}:
        return None

    output_path = Path(dest_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    if extension == "pdf":
        import fitz  # PyMuPDF

        def _render_pdf_cover() -> Path | None:
            with fitz.open(path) as doc:
                if len(doc) == 0:
                    return None
                page = doc[0]
                pix = page.get_pixmap(matrix=fitz.Matrix(2.0, 2.0))
                pix.save(output_path)
                return output_path

        try:
            return await asyncio.to_thread(_render_pdf_cover)
        except Exception as e:
            logger.debug(f"[yellow]Warning: PDF cover extraction failed: {e}[/yellow]")
            return None

    import shutil
    import zipfile

    from PIL import Image

    unrar_path = str(data_config.config.get("DEFAULT", {}).get("unrar_path", "") or "").strip()
    if unrar_path:
        import rarfile as _rarfile

        os.environ["UNRAR_TOOL"] = unrar_path
        _rarfile.CURRENT_SETUP = None
        from rarfile import RarFile
    else:
        from rarfile import RarFile

    temp_extract = output_path.parent / "temp_cover_extract"

    def natural_sort_key(s: str) -> list[int | str]:
        return [int(text) if text.isdigit() else text.lower() for text in re.split(r"(\d+)", s)]

    def _extract_comic_cover() -> Path | None:
        temp_extract.mkdir(parents=True, exist_ok=True)
        compressed_file = None
        try:
            if extension == "cbz":
                try:
                    compressed_file = zipfile.ZipFile(path, "r")
                except Exception:
                    compressed_file = RarFile(path, "r")
            else:
                try:
                    compressed_file = RarFile(path, "r")
                except Exception:
                    compressed_file = zipfile.ZipFile(path, "r")

            if not compressed_file:
                return None

            image_files = [f for f in compressed_file.namelist() if f.lower().endswith((".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp"))]
            if not image_files:
                return None

            image_files.sort(key=natural_sort_key)
            cover_name = image_files[0]
            compressed_file.extract(cover_name, temp_extract)
            extracted_path = temp_extract / cover_name

            suffix = extracted_path.suffix.lower()
            cover_path = output_path.with_suffix(suffix) if suffix in {".jpg", ".jpeg", ".png"} else output_path
            if suffix in {".jpg", ".jpeg", ".png"}:
                shutil.copy2(extracted_path, cover_path)
            else:
                with Image.open(extracted_path) as img:
                    img.save(cover_path, "PNG")
            if is_valid_cover_image(cover_path):
                for old_suffix in (".jpg", ".jpeg", ".png"):
                    old_cover = output_path.with_suffix(old_suffix)
                    if old_cover != cover_path:
                        old_cover.unlink(missing_ok=True)
                return cover_path
            cover_path.unlink(missing_ok=True)
            return None
        finally:
            if compressed_file is not None:
                compressed_file.close()
            shutil.rmtree(temp_extract, ignore_errors=True)

    try:
        return await asyncio.to_thread(_extract_comic_cover)
    except Exception as e:
        logger.debug(f"[yellow]Warning: Comic cover extraction failed: {e}[/yellow]")
        return None


async def prepare_book_cover(path: str, folder_id: str, base_dir: str, meta: Meta) -> str | None:
    if meta.artwork_path and is_valid_cover_image(meta.artwork_path) and not meta.retake:
        return meta.artwork_path

    output_dir = artwork_dir(base_dir, folder_id)
    artwork_path = output_dir / "POSTER.png"

    if not meta.retake:
        for suffix in (".jpg", ".jpeg", ".png"):
            cached = artwork_path.with_suffix(suffix)
            if is_valid_cover_image(cached):
                meta.artwork_path = str(cached)
                return meta.artwork_path

    if meta.audiobook:
        extracted_confirmed = await extract_embedded_cover_from_audiobook(meta, str(artwork_path), confirmed_only=True)
        if extracted_confirmed:
            meta.artwork_path = str(artwork_path)
            logger.debug("[green]Audiobook confirmed cover extracted. Skipping API download.[/green]")
            return str(artwork_path)

        downloaded_artwork = await download_artwork_from_meta(meta, str(artwork_path), force=meta.retake)
        if downloaded_artwork:
            meta.artwork_path = str(artwork_path)
            return str(artwork_path)

        extracted_unconfirmed = await extract_embedded_cover_from_audiobook(meta, str(artwork_path), confirmed_only=False)
        if extracted_unconfirmed:
            meta.artwork_path = str(artwork_path)
            return str(artwork_path)
        return None

    extension = Path(path).suffix.lower().lstrip(".")
    if extension == "epub":
        extracted_confirmed = await extract_epub_cover(path, str(artwork_path), confirmed_only=True)
        if extracted_confirmed:
            meta.artwork_path = str(artwork_path)
            logger.debug("[green]EPUB confirmed cover extracted. Skipping API download.[/green]")
            return str(artwork_path)

    downloaded_artwork = await download_artwork_from_meta(meta, str(artwork_path), force=meta.retake)
    if downloaded_artwork:
        meta.artwork_path = str(artwork_path)
        return str(artwork_path)

    if extension == "epub":
        extracted_unconfirmed = await extract_epub_cover(path, str(artwork_path), confirmed_only=False)
        if extracted_unconfirmed:
            meta.artwork_path = str(artwork_path)
            return str(artwork_path)
    elif extension in {"pdf", "cbr", "cbz"}:
        extracted_document_cover = await extract_document_cover(path, str(artwork_path))
        if extracted_document_cover:
            meta.artwork_path = str(extracted_document_cover)
            return meta.artwork_path

    return None


def select_ebook_pages(total_pages: int, num_screens: int, fixed_pages: list[int], exclude_pages: set[int] | None = None) -> list[int]:
    """Keep the fixed pages (in priority order) and fill the rest with random pages.

    Random pages avoid `exclude_pages` while enough other pages remain.
    """
    num_screens = min(num_screens, total_pages)
    selected = list(dict.fromkeys(p for p in fixed_pages if 0 <= p < total_pages))[:num_screens]
    remaining = [p for p in range(total_pages) if p not in selected]
    preferred = [p for p in remaining if p not in (exclude_pages or set())]
    if len(preferred) >= num_screens - len(selected):
        remaining = preferred
    selected += random.sample(remaining, num_screens - len(selected))
    return sorted(selected)


def find_ebook_info_page(doc: Any) -> int | None:
    """Copyright page with the ISBN, else any page with the ISBN, else the copyright page."""
    from src.book_extractors import find_copyright_page, find_isbn_page

    copyright_isbn_page = find_copyright_page(doc, with_isbn=True)
    if copyright_isbn_page is not None:
        logger.debug(f"[cyan]Using copyright/ISBN page {copyright_isbn_page} as an ebook screenshot[/cyan]")
        return copyright_isbn_page
    found = find_isbn_page(doc)
    if found:
        logger.debug(f"[cyan]Using ISBN page {found[0]} ({found[1]}) as an ebook screenshot[/cyan]")
        return found[0]
    copyright_page = find_copyright_page(doc)
    if copyright_page is not None:
        logger.debug(f"[cyan]Using copyright page {copyright_page} as an ebook screenshot[/cyan]")
    return copyright_page


COMIC_IMAGE_SUFFIXES = (".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp")


def _open_comic_archive(path: str) -> tuple[Any, list[str]] | None:
    """Open a CBZ/CBR (zip or rar, whatever the extension says) and list its pages in reading order."""
    unrar_path = str(data_config.config.get("DEFAULT", {}).get("unrar_path", "") or "").strip()
    if unrar_path:
        import rarfile as _rarfile

        os.environ["UNRAR_TOOL"] = unrar_path
        _rarfile.CURRENT_SETUP = None
    from rarfile import RarFile

    openers = (zipfile.ZipFile, RarFile) if path.lower().endswith(".cbz") else (RarFile, zipfile.ZipFile)
    archive = None
    for opener in openers:
        with contextlib.suppress(Exception):
            archive = opener(path, "r")
            break
    if archive is None:
        return None

    def natural_sort_key(s: str) -> list[int | str]:
        return [int(text) if text.isdigit() else text.lower() for text in re.split(r"(\d+)", s)]

    image_files = sorted((f for f in archive.namelist() if f.lower().endswith(COMIC_IMAGE_SUFFIXES)), key=natural_sort_key)
    return archive, image_files


def _write_comic_page(archive: Any, name: str, dest_stem: Path, force_suffix: str | None = None) -> Path:
    """Write one archive image next to `dest_stem`, keeping JPEG/PNG bytes and converting other formats to PNG."""
    import io

    def image_format(suffix: str) -> str | None:
        return "JPEG" if suffix in {".jpg", ".jpeg"} else "PNG" if suffix == ".png" else None

    source_suffix = Path(name).suffix.lower()
    suffix = force_suffix or (source_suffix if image_format(source_suffix) else ".png")
    dest_path = dest_stem.with_name(f"{dest_stem.name}{suffix}")
    data = archive.read(name)
    target_format = image_format(suffix) or "PNG"
    if image_format(source_suffix) == target_format:
        dest_path.write_bytes(data)
    else:
        with Image.open(io.BytesIO(data)) as img:
            (img.convert("RGB") if target_format == "JPEG" else img).save(dest_path, target_format)
    return dest_path


def _render_document_page(doc: Any, page_num: int, dest_stem: Path, suffix: str = ".png") -> Path:
    import fitz  # PyMuPDF

    dest_path = dest_stem.with_name(f"{dest_stem.name}{suffix}")
    pix = doc[page_num].get_pixmap(matrix=fitz.Matrix(2.0, 2.0))
    if suffix == ".png":
        pix.save(dest_path)
    else:
        pix.pil_save(dest_path, format="JPEG")
    return dest_path


def capture_ebook_page(path: str, dest_stem: Path, exclude_pages: set[int], force_suffix: str | None = None) -> tuple[Path, int]:
    """Write one random page of an ebook/comic that is not in `exclude_pages` (any page once all are used)."""
    import fitz  # PyMuPDF

    if Path(path).suffix.lower() in {".cbz", ".cbr"}:
        opened = _open_comic_archive(path)
        if opened is None:
            raise ValueError("Invalid CBR/CBZ file")
        archive, image_files = opened
        with archive:
            if not image_files:
                raise ValueError("CBR/CBZ does not contain images")
            page = select_ebook_pages(len(image_files), 1, [], exclude_pages)[0]
            return _write_comic_page(archive, image_files[page], dest_stem, force_suffix), page

    with contextlib.suppress(Exception):
        fitz.TOOLS.mupdf_display_errors(False)
    with fitz.open(path) as doc:
        if len(doc) == 0:
            raise ValueError("The book does not have pages")
        page = select_ebook_pages(len(doc), 1, [], exclude_pages)[0]
        return _render_document_page(doc, page, dest_stem, force_suffix or ".png"), page


async def generate_ebook_screenshots(
    path: str,
    filename: str,
    folder_id: str,
    base_dir: str,
    meta: Meta,
    num_screens: int = 5,
    artwork: bool = True,
) -> list[str]:
    """Capture book pages and, when `artwork` is set, the book cover and banner.

    Pages already registered (for example by the early background capture and
    then reviewed in the Web UI) are reused unless `meta.retake` is set.
    """
    import fitz  # PyMuPDF

    with contextlib.suppress(Exception):
        fitz.TOOLS.mupdf_display_errors(False)

    output_dir = screenshots_dir(base_dir, folder_id).resolve()
    sanitized_filename = await sanitize_filename(filename)

    extension = Path(path).suffix.lower().lstrip(".")
    existing = [] if meta.retake else manifest_files(base_dir, folder_id, "main")
    if existing and len(manifest_capture_pages(base_dir, folder_id, "main")) != len(existing):
        # Captures from older runs lack page numbers, which the review needs to avoid repeats.
        logger.debug("[yellow]Recapturing book screenshots without page numbers.[/yellow]")
        existing = []
    if existing and not artwork:
        logger.debug(f"[yellow]Reusing {len(existing)} registered book screenshots.[/yellow]")
        return [str(screen) for screen in existing]
    capture_pages = not existing
    screenshots: list[Path] = []
    pages: dict[str, int] = {}

    poster_dir = artwork_dir(base_dir, folder_id)
    cover_path = poster_dir / "POSTER.png"
    banner_path = next(
        (
            candidate
            for candidate in (Path(str(meta.artwork_banner_path or "")), *(poster_dir / f"POSTER_BANNER{suffix}" for suffix in (".jpg", ".jpeg", ".png")))
            if is_valid_cover_image(candidate)
        ),
        poster_dir / "POSTER_BANNER.png",
    )
    need_banner = artwork and not (is_valid_cover_image(banner_path) and not meta.retake)

    prepared_cover = await prepare_book_cover(path, folder_id, base_dir, meta) if artwork else None
    if prepared_cover:
        cover_path = Path(prepared_cover)
    need_cover = artwork and not prepared_cover

    if extension in ["cbr", "cbz"]:
        opened = _open_comic_archive(path)
        if opened is None:
            logger.info(f"[red]Invalid CBR/CBZ file: {path}[/red]")
            return []
        compressed_file, image_files = opened
        with compressed_file:
            if not image_files:
                logger.info("[yellow]CBR/CBZ does not contain images[/yellow]")
                return []

            async def process_compressed_image(img_idx: int, dest_stem: Path) -> Path:
                return await asyncio.to_thread(_write_comic_page, compressed_file, image_files[img_idx], dest_stem)

            if capture_pages:
                for i, img_idx in enumerate(select_ebook_pages(len(image_files), num_screens, [0])):
                    scr_path = await process_compressed_image(img_idx, output_dir / f"{sanitized_filename}-{i}")
                    screenshots.append(scr_path)
                    pages[str(scr_path)] = img_idx

            if need_cover:
                cover_path = await process_compressed_image(0, poster_dir / "POSTER")
            if need_banner:
                banner_path = await process_compressed_image(len(image_files) - 1, poster_dir / "POSTER_BANNER")
                for old_suffix in (".jpg", ".jpeg", ".png"):
                    old_banner = poster_dir / f"POSTER_BANNER{old_suffix}"
                    if old_banner != banner_path:
                        old_banner.unlink(missing_ok=True)

            if artwork:
                meta.artwork_path = str(cover_path)
                meta.artwork_banner_path = str(banner_path)

    elif extension in ["pdf", "mobi", "epub"]:
        try:
            if extension == "epub" and need_cover:
                try:
                    if await extract_epub_cover(path, str(cover_path), confirmed_only=False):
                        need_cover = False
                        meta.artwork_path = str(cover_path)
                except Exception as e:
                    logger.debug(f"[yellow]Warning: EPUB cover extraction failed: {e}[/yellow]")

            with fitz.open(path) as doc:
                total_pages = len(doc)
                if total_pages == 0:
                    logger.info(f"[yellow]{extension.upper()} does not have pages[/yellow]")
                    return []

                async def process_page(page_num: int, dest_stem: Path) -> Path:
                    return await asyncio.to_thread(_render_document_page, doc, page_num, dest_stem)

                if capture_pages:
                    info_page = await asyncio.to_thread(find_ebook_info_page, doc) if num_screens > 1 else None
                    selected_pages = select_ebook_pages(total_pages, num_screens, [0] if info_page is None else [0, info_page])
                    for i, page_num in enumerate(selected_pages):
                        scr_path = await process_page(page_num, output_dir / f"{sanitized_filename}-{i}")
                        screenshots.append(scr_path)
                        pages[str(scr_path)] = page_num

                if need_cover:
                    cover_path = await process_page(0, poster_dir / "POSTER")
                if need_banner:
                    banner_path = await process_page(total_pages - 1, poster_dir / "POSTER_BANNER")

            if artwork:
                meta.artwork_path = str(cover_path)
                meta.artwork_banner_path = str(banner_path)
        except Exception as e:
            logger.error(f"[red]Error while generating {extension.upper()} screenshots: {e}[/red]")
            logger.info(traceback.format_exc())

    if not capture_pages:
        logger.debug(f"[yellow]Reusing {len(existing)} registered book screenshots.[/yellow]")
        return [str(screen) for screen in existing]

    if screenshots:
        clear_screenshot_group(base_dir, folder_id, "main")
        screenshots = register_screenshots(base_dir, folder_id, screenshots, "main", pages=pages)
    await record_event_async("artifact", service="screenshot", operation="created", category="standard", count=len(screenshots))
    return [str(screen) for screen in screenshots]


@holds_slot("screenshots", "screenshot capture")
async def screenshots(
    path: str,
    filename: str,
    folder_id: str,
    base_dir: str,
    meta: Meta,
    num_screens: int = 0,
    force_screenshots: bool = False,
    manual_frames: str | list[int] | list[str] = "",
    cleanup_after_capture: bool = True,
    capture_group: str | None = None,
) -> list[str] | None:
    if meta.category == "GAME":
        return []

    if meta.category == "BOOK":
        if meta.audiobook:
            await prepare_book_cover(path, folder_id, base_dir, meta)
            return []
        return await generate_ebook_screenshots(path, filename, folder_id, base_dir, meta, num_screens if num_screens > 0 else meta.screens)

    img_host = await get_image_host(meta)
    screens = meta.screens
    # A Web UI review can remove frames while the run waits for confirmation.
    # Respect that persisted target when this later, normal capture pass runs.
    from src.screenshot_review import target_count

    screens = target_count(Path(base_dir) / "tmp" / folder_id, screens)
    meta.screens = screens
    start_time = time.time() if meta.debug else 0.0
    logger.debug(f"Image Host: {img_host}")
    if "image_list" not in meta:
        meta.image_list = []

    group = capture_group or "main"
    image_list_entries = meta.image_list if group == "main" else []
    existing_images: list[dict[str, Any]] = [img for img in image_list_entries if str(img.get("img_url", "")).startswith("http")]

    if len(existing_images) >= cutoff and not force_screenshots:
        logger.info(f"[yellow]There are already at least {cutoff} images in the image list. Skipping additional screenshots.")
        return None

    if num_screens:
        requested_screens = num_screens
    elif isinstance(manual_frames, str):
        requested_screens = len([frame for frame in manual_frames.split(",") if frame.strip()]) if manual_frames else screens
    elif manual_frames:
        requested_screens = len(manual_frames)
    else:
        requested_screens = screens
    if meta.retake:
        clear_screenshot_group(base_dir, folder_id, group)
    registered_screens = manifest_files(base_dir, folder_id, group)
    # Metadata enrichment can alter the display title (for example, by adding
    # punctuation). Reuse the logical capture group rather than deriving
    # identity from a display-derived filename. This must happen before reading
    # MediaInfo so an already-complete early capture is a true no-op.
    if not force_screenshots and not meta.retake and len(registered_screens) >= requested_screens:
        logger.debug(f"[yellow]Reusing {len(registered_screens)} registered screenshots from group '{group}'.[/yellow]")
        if tone_map and any(marker in meta.hdr for marker in ("HDR", "DV", "HLG")):
            meta.tonemapped = True
        return [str(screen) for screen in registered_screens[:requested_screens]]

    try:
        mi_text = await asyncio.to_thread(Path(f"{base_dir}{'/' + 'tmp' + '/'}{folder_id}/MediaInfo.json").read_text, encoding="utf-8")
        mi = json.loads(mi_text)
        video_track = mi["media"]["track"][1]

        def safe_float(value: Any, default: float = 0.0, field_name: str = "") -> float:
            if isinstance(value, (int, float)):
                return float(value)
            if isinstance(value, str):
                try:
                    return float(value)
                except ValueError:
                    logger.warning(f"[yellow]Warning: Could not convert string '{value}' to float for {field_name}, using default {default}[/yellow]")
                    return default
            elif isinstance(value, dict):
                for key in ["#value", "value", "duration", "Duration"]:
                    if key in value:
                        return safe_float(value[key], default, field_name)
                logger.warning(f"[yellow]Warning: {field_name} is a dict but no usable value found: {value}, using default {default}[/yellow]")
                return default
            else:
                logger.warning(f"[yellow]Warning: Unable to convert to float: {type(value)} {value} for {field_name}, using default {default}[/yellow]")
                return default

        length = safe_float(video_track.get("Duration"), safe_float(mi["media"]["track"][0].get("Duration"), 3600.0, "General Duration"), "Video Duration")

        width = safe_float(video_track.get("Width"), 1920.0, "Width")
        height = safe_float(video_track.get("Height"), 1080.0, "Height")
        par = safe_float(video_track.get("PixelAspectRatio"), 1.0, "PixelAspectRatio")
        dar = safe_float(video_track.get("DisplayAspectRatio"), 16.0 / 9.0, "DisplayAspectRatio")
        frame_rate = safe_float(video_track.get("FrameRate"), 24.0, "FrameRate")

        w_sar, h_sar = screenshot_par_scale_factors(width, height, par, dar)
    except Exception as e:
        logger.error(f"[red]Error processing MediaInfo.json: {e}")
        if meta.debug:
            import traceback

            logger.debug(traceback.format_exc())
        return None
    meta.frame_rate = frame_rate
    loglevel = "verbose" if meta.ffdebug else "quiet"
    if manual_frames and meta.debug:
        logger.info(f"[yellow]Using manual frames: {manual_frames}")
    ss_times: list[str] = []
    if manual_frames and not force_screenshots:
        try:
            manual_frames_list: list[int]
            if isinstance(manual_frames, str):
                manual_frames_list = [int(frame.strip()) for frame in manual_frames.split(",") if frame.strip()]
            else:
                manual_frames_list = [int(frame) for frame in manual_frames]
            num_screens = len(manual_frames_list)
            if num_screens > 0:
                ss_times = [str(frame / frame_rate) for frame in manual_frames_list]
        except (TypeError, ValueError) as e:
            if meta.debug and manual_frames:
                logger.error(f"[red]Error processing manual frames: {e}[/red]")
                sys.exit(1)

    if num_screens <= 0:
        num_screens = screens - len(existing_images)
    if not force_screenshots and not meta.retake:
        num_screens = max(0, num_screens - len(registered_screens))
    if num_screens <= 0:
        if tone_map and any(marker in meta.hdr for marker in ("HDR", "DV", "HLG")):
            meta.tonemapped = True
        return [str(screen) for screen in registered_screens] or None

    sanitized_filename = await sanitize_filename(filename)
    screenshot_dir = screenshots_dir(base_dir, folder_id)
    test_image_path = str((screenshot_dir / f"{sanitized_filename}-libplacebo-test.png").absolute())

    # Screenshot slots must be regular files within this release. Resolving a
    # symlink here would make recovery rename or overwrite its external target.
    if screenshot_dir.is_symlink() or (screenshot_dir / f"{sanitized_filename}-libplacebo-test.png").is_symlink():
        logger.error("[red]Refusing screenshot capture through a symlink.[/red]")
        return None

    existing_image_paths: list[str] = []
    capture_indices: list[int] = []
    for i in range(num_screens):
        slot = screenshot_dir / f"{sanitized_filename}-{i}.png"
        if slot.is_symlink():
            logger.error(f"[red]Refusing symlinked screenshot slot: {slot}[/red]")
            return None
        image_path = str(slot.absolute())
        if Path(image_path).exists() and not meta.retake:
            # A forced exit can leave incomplete PNGs as well as completed
            # frames that have not yet been published to the manifest.
            try:
                with Image.open(image_path) as image:
                    image.verify()
            except OSError, SyntaxError, ValueError:
                logger.debug(f"[yellow]Recapturing incomplete screenshot: {image_path}[/yellow]")
            else:
                existing_image_paths.append(image_path)
                continue
        capture_indices.append(i)

    # Concurrent captures can finish out of order. Fill the actual missing
    # indices instead of assuming every existing file forms a contiguous prefix.
    num_capture = len(capture_indices)

    progress_id = f"screenshots-{folder_id}"
    progress_label = "FFmpeg screenshots"
    completed_captures = 0
    publish_progress(
        progress_id,
        progress_label,
        current=completed_captures,
        total=num_capture,
        detail=f"0/{num_capture} frames completed",
        group="media",
        unit="frames",
    )

    if not ss_times:
        # Keep the original sampling grid when completing a partial capture.
        # Sampling only the missing count would select already captured frames.
        sampling_count = num_screens + len(registered_screens) if not force_screenshots and not meta.retake else num_screens
        ss_times = await valid_ss_time([], sampling_count, length, frame_rate, meta, retake=force_screenshots)
    if not force_screenshots and not meta.retake:
        used_times = capture_timestamps(base_dir, folder_id, group, original_slots=True)
        used_frames = Counter(round(timestamp * frame_rate) for timestamp in used_times)
        missing_times: list[str] = []
        for timestamp in ss_times:
            frame = round(float(timestamp) * frame_rate)
            # Each saved screenshot occupies one slot, even when the user
            # requests repeated frames or a short video's grid repeats them.
            if used_frames[frame] > 0:
                used_frames[frame] -= 1
            else:
                missing_times.append(timestamp)
        ss_times = missing_times
        # Older manifests have no capture times. Preserve their count-based
        # reuse while recording times for all new captures.
        unknown_count = max(0, len(registered_screens) - len(used_times))
        ss_times = ss_times[unknown_count:]
    # Keep one timestamp per unregistered file slot, including recovered files.
    # Only the capture task list is sparse; compacting times would shift gaps.
    ss_times = ss_times[:num_screens]
    captured_times: dict[str, float] = {}
    slot_times: dict[str, float] = {}

    if meta.frame_overlay and any(overlay_options(default_config)[key] for key in ("overlay_frame_number", "overlay_frame_type")):
        logger.debug("[yellow]Getting frame information for overlays...")
        # Build list of (original_index, task) to preserve index correspondence
        frame_info_tasks_with_idx = [(i, get_frame_info(path, ss_times[i], meta)) for i in capture_indices]
        frame_info_results = await asyncio.gather(*[task for _, task in frame_info_tasks_with_idx])
        meta.frame_info_map = {}

        # Create a mapping from time to frame info using preserved indices
        for (orig_idx, _), info in zip(frame_info_tasks_with_idx, frame_info_results, strict=False):
            meta.frame_info_map[ss_times[orig_idx]] = info

        logger.debug(f"[cyan]Collected frame information for {len(frame_info_results)} frames")

    num_tasks = num_capture
    num_workers = min(num_tasks, task_limit)

    test_time = str(ss_times[0] if ss_times else 0)
    hdr_tonemap = False
    tonemapping_checked = bool(capture_indices)
    if capture_indices:
        hdr_tonemap = await determine_tonemapping(w_sar, h_sar, width, height, path, test_time, test_image_path, loglevel, meta)
    elif tone_map and any(marker in meta.hdr for marker in ("HDR", "DV", "HLG")):
        meta.tonemapped = True
        hdr_tonemap = True

    logger.debug(f"Using {num_workers} worker(s) for {num_capture} image(s)")

    # Create semaphore to limit concurrent tasks
    semaphore = asyncio.Semaphore(num_workers)

    async def capture_with_semaphore(args: tuple[int, str, float, str, float, float, float, float, str, bool, Meta]) -> tuple[int, str | None] | None:
        nonlocal completed_captures
        async with semaphore:
            result = await capture_screenshot(args)
            completed_captures += 1
            publish_progress(
                progress_id,
                progress_label,
                current=completed_captures,
                total=num_capture,
                detail=f"{completed_captures}/{num_capture} frames completed",
                group="media",
                unit="frames",
            )
            return result

    capture_tasks: list[Awaitable[tuple[int, str | None] | None]] = []
    for i in range(num_screens):
        image_path = str((screenshot_dir / f"{sanitized_filename}-{i}.png").absolute())
        captured_times[image_path] = float(ss_times[i])
        # Recovered files occupy sampling slots just like new captures.
        slot_times[image_path] = float(ss_times[i])
    for i in capture_indices:
        image_path = str((screenshot_dir / f"{sanitized_filename}-{i}.png").resolve())
        capture_tasks.append(capture_with_semaphore((i, path, float(ss_times[i]), image_path, width, height, w_sar, h_sar, loglevel, hdr_tonemap, meta)))

    try:
        results = cast(list[object], await asyncio.gather(*capture_tasks, return_exceptions=True))
        # Log any error strings that were returned (these indicate exceptions in capture_screenshot)
        for r in results:
            if isinstance(r, Exception):
                logger.info(f"[red]Screenshot capture exception: {r}[/red]")
        capture_result_tuples: list[tuple[int, str | None]] = [cast(tuple[int, str | None], r) for r in results if isinstance(r, tuple)]
        capture_result_tuples.sort(key=lambda x: x[0])
        capture_results: list[str] = [r[1] for r in capture_result_tuples if r[1] is not None]

    except KeyboardInterrupt:
        logger.info("\n[red]CTRL+C detected. Cancelling capture tasks...[/red]")
        await asyncio.sleep(0.1)
        logger.info("[red]All tasks cancelled. Exiting.[/red]")
        gc.collect()
        cleanup_manager.reset_terminal()
        sys.exit(1)
    except asyncio.CancelledError:
        await asyncio.sleep(0.1)
        gc.collect()
        cleanup_manager.reset_terminal()
        sys.exit(1)
    except Exception:
        await asyncio.sleep(0.1)
        gc.collect()
        cleanup_manager.reset_terminal()
        sys.exit(1)
    finally:
        await asyncio.sleep(0.1)
        logger.debug("[yellow]All capture tasks finished. Cleaning up...[/yellow]")

    if not force_screenshots and meta.debug:
        logger.info(f"[green]Successfully captured {len(capture_results)} screenshots.")

    # Recovered frames need the same host validation and manifest registration
    # as new captures; upload selection only uses the manifest once it exists.
    capture_results = existing_image_paths + capture_results
    valid_results: list[str] = []
    remaining_retakes: list[str] = []
    for image_path in capture_results:
        retake = False
        image_size = Path(image_path).stat().st_size
        logger.debug(f"[yellow]Checking image {image_path} (size: {image_size} bytes) for image host: {img_host}[/yellow]")
        if manual_frames and img_host == "lostimg" and not is_valid_lostimg_image_size(image_size):
            logger.info(f"[red]Image {image_path} with size {image_size} bytes: does not meet size requirements for {img_host}, skipping.[/red]")
            continue
        if not manual_frames:
            if image_size <= 75000:
                logger.info(f"[yellow]Image {image_path} is incredibly small, retaking.")
                retake = True
            else:
                if img_host and "imgbb" in img_host:
                    if image_size <= 31000000:
                        logger.debug(f"[green]Image {image_path} meets size requirements for imgbb.[/green]")
                    else:
                        logger.info(f"[red]Image {image_path} with size {image_size} bytes: does not meet size requirements for imgbb, retaking.")
                        retake = True
                elif img_host and img_host in ["imgbox", "pixhost"]:
                    if 75000 < image_size <= 10000000:
                        logger.debug(f"[green]Image {image_path} meets size requirements for {img_host}.[/green]")
                    else:
                        logger.info(f"[red]Image {image_path} with size {image_size} bytes: does not meet size requirements for {img_host}, retaking.")
                        retake = True
                elif img_host == "lostimg":
                    if is_valid_lostimg_image_size(image_size):
                        logger.debug(f"[green]Image {image_path} meets size requirements for {img_host}.[/green]")
                    else:
                        logger.info(f"[red]Image {image_path} with size {image_size} bytes: does not meet size requirements for {img_host}, retaking.")
                        retake = True
                elif img_host and img_host in [
                    "lensdump",
                    "ptscreens",
                    "onlyimage",
                    "dalexni",
                    "zipline",
                    "midnightscene",
                    "bioma",
                    "passtheimage",
                    "seedpool_cdn",
                    "sharex",
                    "thrimg",
                    "utppm",
                ]:
                    logger.debug(f"[green]Image {image_path} meets size requirements for {img_host}.[/green]")
                else:
                    logger.info(f"[red]Unknown image host or image doesn't meet requirements for host: {img_host}, retaking.")
                    retake = True

        if retake:
            if not tonemapping_checked:
                hdr_tonemap = await determine_tonemapping(w_sar, h_sar, width, height, path, test_time, test_image_path, loglevel, meta)
                tonemapping_checked = True
            retry_attempts = 5
            retry_offsets = [5.0, 10.0, -10.0, 100.0, -100.0]
            retry_image = str(Path(image_path).with_name(f"{Path(image_path).stem}-retry.png"))
            frame_rate = meta.frame_rate if meta.frame_rate is not None else 24.0
            original_index = int(image_path.rsplit("-", 1)[-1].split(".")[0])
            original_time = ss_times[original_index] if original_index < len(ss_times) else None

            for attempt in range(1, retry_attempts + 1):
                if original_time is not None:
                    for offset in retry_offsets:
                        adjusted_time = max(0, float(original_time) + offset)
                        logger.info(
                            f"[yellow]Retaking screenshot for: {image_path} (Attempt {attempt}/{retry_attempts}) at {adjusted_time:.2f}s (offset {offset:+.2f}s)[/yellow]"
                        )
                        try:
                            Path(retry_image).unlink(missing_ok=True)

                            screenshot_response = await capture_screenshot(
                                (original_index, path, adjusted_time, retry_image, width, height, w_sar, h_sar, loglevel, hdr_tonemap, meta)
                            )

                            if not isinstance(screenshot_response, tuple) or len(screenshot_response) != 2:
                                continue

                            _, screenshot_path = screenshot_response

                            if not screenshot_path or not Path(screenshot_path).exists():
                                continue

                            new_size = Path(screenshot_path).stat().st_size
                            valid_image = False

                            if img_host and "imgbb" in img_host:
                                if 75000 < new_size <= 31000000:
                                    logger.info(f"[green]Successfully retaken screenshot for: {screenshot_path} ({new_size} bytes)[/green]")
                                    valid_image = True
                            elif img_host and img_host in ["imgbox", "pixhost"]:
                                if 75000 < new_size <= 10000000:
                                    logger.info(f"[green]Successfully retaken screenshot for: {screenshot_path} ({new_size} bytes)[/green]")
                                    valid_image = True
                            elif img_host == "lostimg":
                                if is_valid_lostimg_image_size(new_size):
                                    logger.info(f"[green]Successfully retaken screenshot for: {screenshot_path} ({new_size} bytes)[/green]")
                                    valid_image = True
                            elif (
                                img_host
                                and img_host
                                in [
                                    "lensdump",
                                    "ptscreens",
                                    "onlyimage",
                                    "dalexni",
                                    "zipline",
                                    "midnightscene",
                                    "bioma",
                                    "passtheimage",
                                    "seedpool_cdn",
                                    "sharex",
                                    "thrimg",
                                    "utppm",
                                ]
                                and new_size > 75000
                            ):
                                logger.info(f"[green]Successfully retaken screenshot for: {screenshot_path} ({new_size} bytes)[/green]")
                                valid_image = True

                            if valid_image:
                                Path(screenshot_path).replace(image_path)
                                captured_times[image_path] = adjusted_time
                                valid_results.append(image_path)
                                break
                        except Exception as e:
                            logger.error(f"[red]Error retaking screenshot for {image_path} at {adjusted_time:.2f}s: {e}[/red]")
                        finally:
                            Path(retry_image).unlink(missing_ok=True)
                    else:
                        continue
                    break
                # Fallback: use random time if original_time is not available
                random_time = random.uniform(0, length)  # nosec B311 - Random screenshot timing, not cryptographic  # noqa: S311
                logger.info(f"[yellow]Retaking screenshot for: {image_path} (Attempt {attempt}/{retry_attempts}) at random time {random_time:.2f}s[/yellow]")
                try:
                    Path(retry_image).unlink(missing_ok=True)

                    screenshot_response = await capture_screenshot((original_index, path, random_time, retry_image, width, height, w_sar, h_sar, loglevel, hdr_tonemap, meta))

                    if not isinstance(screenshot_response, tuple) or len(screenshot_response) != 2:
                        continue

                    _, screenshot_path = screenshot_response

                    if not screenshot_path or not Path(screenshot_path).exists():
                        continue

                    new_size = Path(screenshot_path).stat().st_size
                    valid_image = False

                    if img_host and "imgbb" in img_host:
                        if 75000 < new_size <= 31000000:
                            valid_image = True
                    elif img_host and img_host in ["imgbox", "pixhost"]:
                        if 75000 < new_size <= 10000000:
                            valid_image = True
                    elif img_host == "lostimg":
                        if is_valid_lostimg_image_size(new_size):
                            valid_image = True
                    elif (
                        img_host
                        and img_host
                        in ["lensdump", "ptscreens", "onlyimage", "dalexni", "zipline", "midnightscene", "bioma", "passtheimage", "seedpool_cdn", "sharex", "thrimg", "utppm"]
                        and new_size > 75000
                    ):
                        valid_image = True

                    if valid_image:
                        Path(screenshot_path).replace(image_path)
                        captured_times[image_path] = random_time
                        valid_results.append(image_path)
                        break
                except Exception as e:
                    logger.error(f"[red]Error retaking screenshot for {image_path} at random time {random_time:.2f}s: {e}[/red]")
                finally:
                    Path(retry_image).unlink(missing_ok=True)
            else:
                logger.info(f"[red]All retry attempts failed for {image_path}. Skipping.[/red]")
                remaining_retakes.append(image_path)
                gc.collect()

        else:
            valid_results.append(image_path)

    if remaining_retakes:
        logger.info(f"[red]The following images could not be retaken successfully: {remaining_retakes}[/red]")

    logger.debug(f"[green]Successfully processed {len(valid_results)} screenshots.")

    if meta.debug:
        finish_time = time.time()
        logger.debug(f"Screenshots processed in {finish_time - start_time:.4f} seconds")

    multi_screens = int(default_config.get("multiScreens", 2))
    discs = meta.discs
    one_disc = True
    if discs and len(discs) == 1:
        one_disc = True
    elif discs and len(discs) > 1:
        one_disc = False

    if cleanup_after_capture and ((not meta.tv_pack and one_disc) or multi_screens == 0):
        await cleanup_manager.cleanup()

    complete_progress(
        progress_id,
        progress_label,
        current=num_capture,
        total=num_capture,
        detail=f"{len(valid_results)}/{num_screens} frames processed",
        group="media",
        unit="frames",
    )

    if any(Path(image_path).is_symlink() for image_path in valid_results):
        logger.error("[red]Refusing to register a symlinked screenshot.[/red]")
        return None
    new_screens = register_screenshots(base_dir, folder_id, valid_results, group, timestamps=captured_times, slot_timestamps=slot_times) if valid_results else []
    await record_event_async("artifact", service="screenshot", operation="created", category="standard", count=len(new_screens))
    if not force_screenshots and not meta.retake:
        return [str(screen) for screen in manifest_files(base_dir, folder_id, group)[:requested_screens]]
    return [str(screen) for screen in new_screens] or None


async def capture_screenshot(args: tuple[int, str, float, str, float, float, float, float, str, bool, Meta]) -> tuple[int, str | None] | None:
    index, path, ss_time, image_path, width, height, w_sar, h_sar, loglevel, hdr_tonemap, meta = args

    try:

        def set_ffmpeg_threads() -> list[str]:
            threads_value = "1"
            return ["-threads", threads_value]

        if width <= 0 or height <= 0:
            return None

        if ss_time < 0:
            return None

        scaled_w = round_to_even(width * w_sar)
        scaled_h = round_to_even(height * h_sar)

        # Normalize path for cross-platform compatibility
        path = os.path.normpath(path)

        # If path is a directory and meta has a filelist, use the first file from the filelist
        if Path(path).is_dir():
            error_msg = f"Error: Path is a directory, not a file: {path}"
            logger.info(f"[yellow]{error_msg}[/yellow]")

            # Use meta that's passed directly to the function
            if "filelist" in meta and meta.filelist:
                video_file = meta.filelist[0]
                logger.info(f"[green]Using first file from filelist: {video_file}[/green]")
                path = video_file
            else:
                return None

        # After potential path correction, validate again
        if not Path(path).exists():
            error_msg = f"Error: Input file does not exist: {path}"
            logger.info(f"[red]{error_msg}[/red]")
            return None

        # Debug output showing the exact path being used
        if loglevel == "verbose" or (meta and meta.debug):
            logger.info(f"[cyan]Processing file: {path}[/cyan]")

        if not meta.frame_overlay:
            # Warm-up (only for first screenshot index or if not warmed)
            if use_libplacebo:
                warm_up = default_config.get("ffmpeg_warmup", False)
                if warm_up:
                    meta.libplacebo_warmed = False
                else:
                    meta.libplacebo_warmed = True
                if not meta.libplacebo_warmed:
                    meta.libplacebo_warmed = False
                if hdr_tonemap and meta.libplacebo and not meta.libplacebo_warmed:
                    await libplacebo_warmup(path, meta, loglevel)

            threads_value = set_ffmpeg_threads()
            threads_val = threads_value[1]
            vf_filters: list[str] = []

            if w_sar != 1 or h_sar != 1:
                scaled_w = round_to_even(width * w_sar)
                scaled_h = round_to_even(height * h_sar)
                vf_filters.append(f"scale={scaled_w}:{scaled_h}")
                if loglevel == "verbose" or (meta and meta.debug):
                    logger.info(f"[cyan]Applied PAR scale -> {scaled_w}x{scaled_h}[/cyan]")

            if hdr_tonemap:
                if meta.libplacebo:
                    vf_filters.append("libplacebo=tonemapping=hable:colorspace=bt709:color_primaries=bt709:color_trc=bt709:range=tv")
                    if loglevel == "verbose" or (meta and meta.debug):
                        logger.info("[cyan]Using libplacebo tonemapping[/cyan]")
                else:
                    vf_filters.extend(
                        [
                            "zscale=transfer=linear",
                            f"tonemap=tonemap={algorithm}:desat={desat}",
                            "zscale=transfer=bt709",
                            "format=rgb24",
                        ]
                    )
                    if loglevel == "verbose" or (meta and meta.debug):
                        logger.info(f"[cyan]Using zscale tonemap chain (algo={algorithm}, desat={desat})[/cyan]")

            vf_filters.append("format=rgb24")
            vf_chain = ",".join(vf_filters) if vf_filters else "format=rgb24"

            if loglevel == "verbose" or (meta and meta.debug):
                logger.info(f"[cyan]Final -vf chain: {vf_chain}[/cyan]")

            threads_value = ["-threads", "1"]
            threads_val = threads_value[1]

            def build_cmd(use_libplacebo: bool = True) -> Any:
                inp = cast(Any, ffmpeg).input(path, ss=str(ss_time))
                # Build output and global args
                out_kwargs = {"vframes": 1, "vf": vf_chain, "compression_level": ffmpeg_compression, "pred": "mixed"}
                info_cmd = inp.output(image_path, **out_kwargs)

                global_args = ["-y", "-loglevel", loglevel, "-hide_banner", "-map", "0:v:0", "-an", "-sn"]
                if use_libplacebo and meta.libplacebo:
                    global_args += ["-init_hw_device", "vulkan"]
                if ffmpeg_limit:
                    global_args += ["-threads", threads_val]

                return info_cmd.global_args(*global_args)

            cmd = build_cmd(use_libplacebo=True)

            if loglevel == "verbose" or (meta and meta.debug):
                # Disable emoji translation so 0:v:0 stays literal
                try:
                    compiled = compile_ffmpeg_command(cmd)
                    logger.info(f"[cyan]FFmpeg command: {' '.join(compiled)}[/cyan]")
                except Exception:
                    logger.info("[cyan]FFmpeg command: (unable to render command)[/cyan]")

            # --- Execute with retry/fallback if libplacebo fails ---
            async def run_cmd(info_command: Any, timeout_sec: float) -> tuple[int | None, bytes, bytes]:
                try:
                    return await asyncio.wait_for(run_ffmpeg(info_command), timeout=timeout_sec)
                except TimeoutError:
                    return -1, b"", b"Timeout"

            info_cmd = build_cmd(use_libplacebo=True)
            if loglevel == "verbose" or (meta and meta.debug):
                logger.info(f"[cyan]FFmpeg command: {' '.join(compile_ffmpeg_command(info_cmd))}[/cyan]")

            returncode, stdout, stderr = await run_cmd(info_cmd, 140)  # a bit longer for first pass
            if returncode != 0 and hdr_tonemap and meta.libplacebo:
                # Retry once (shader compile might have delayed first invocation)
                if loglevel == "verbose" or meta.debug:
                    logger.info("[yellow]First libplacebo attempt failed; retrying once...[/yellow]")
                await asyncio.sleep(1.0)
                returncode, stdout, stderr = await run_cmd(info_cmd, 160)

            if returncode != 0 and hdr_tonemap and meta.libplacebo:
                # Fallback: switch to zscale tonemap chain
                if loglevel == "verbose" or meta.debug:
                    logger.info("[red]libplacebo failed twice; falling back to zscale tonemap[/red]")
                meta.libplacebo = False
                # Rebuild chain with zscale
                z_vf_filters: list[str] = []
                if w_sar != 1 or h_sar != 1:
                    z_vf_filters.append(f"scale={scaled_w}:{scaled_h}")
                z_vf_filters.extend(["format=rgb24", "zscale=transfer=linear", f"tonemap=tonemap={algorithm}:desat={desat}", "zscale=transfer=bt709"])
                vf_chain = ",".join(z_vf_filters)
                info_cmd = build_cmd(use_libplacebo=False)
                if loglevel == "verbose" or meta.debug:
                    logger.info(f"[cyan]Fallback FFmpeg command: {' '.join(compile_ffmpeg_command(info_cmd))}[/cyan]")
                returncode, stdout, stderr = await run_cmd(info_cmd, 140)
                cmd = info_cmd  # for logging below

            if returncode == 0 and Path(image_path).exists():
                if loglevel == "verbose" or (meta and meta.debug):
                    logger.info(f"[green]Screenshot captured successfully: {image_path}[/green]")
                return (index, image_path)
            if loglevel == "verbose" or (meta and meta.debug):
                err_txt = (stderr or b"").decode(errors="replace").strip()
                logger.info(f"[red]FFmpeg process failed (final): {err_txt}[/red]")
            return (index, None)

        # Proceed with screenshot capture
        threads_value = set_ffmpeg_threads()
        threads_val = threads_value[1]

        # Build filter chain
        vf_filters: list[str] = []

        if w_sar != 1 or h_sar != 1:
            scaled_w = round_to_even(width * w_sar)
            scaled_h = round_to_even(height * h_sar)
            vf_filters.append(f"scale={scaled_w}:{scaled_h}")

        if hdr_tonemap:
            vf_filters.extend(
                [
                    "zscale=transfer=linear",
                    f"tonemap=tonemap={algorithm}:desat={desat}",
                    "zscale=transfer=bt709",
                    "format=rgb24",
                ]
            )

        vf_filters.extend(overlay_filters(default_config, meta, ss_time, hdr_tonemap))

        # Build command
        # Always ensure at least format filter is present for PNG compression to work
        vf_filters.append("format=rgb24")
        vf_chain = ",".join(vf_filters)

        try:
            info_cmd: Any = (
                cast(Any, ffmpeg)
                .input(path, ss=str(ss_time))
                .output(image_path, vframes=1, vf=vf_chain, compression_level=ffmpeg_compression, pred="mixed")
                .global_args("-y", "-loglevel", loglevel, "-hide_banner", "-map", "0:v:0", "-an", "-sn")
            )
            if ffmpeg_limit:
                info_cmd = info_cmd.global_args("-threads", threads_val)

            if loglevel == "verbose":
                logger.info(f"[cyan]FFmpeg command: {' '.join(compile_ffmpeg_command(info_cmd))}[/cyan]")

            returncode, stdout, stderr = await run_ffmpeg(info_cmd)
            # Print stdout and stderr if in verbose mode
            if loglevel == "verbose":
                if stdout:
                    logger.info(f"[blue]FFmpeg stdout:[/blue]\n{stdout.decode('utf-8', errors='replace')}")
                if stderr:
                    logger.info(f"[yellow]FFmpeg stderr:[/yellow]\n{stderr.decode('utf-8', errors='replace')}")

        except asyncio.CancelledError:
            logger.info(traceback.format_exc())
            raise

        if returncode == 0:
            return (index, image_path)
        stderr_text = (stderr or b"").decode("utf-8", errors="replace")
        if "Error initializing complex filters" in stderr_text:
            logger.info("[red]FFmpeg complex filters error: see https://github.com/wastaken7/Upload-Assistant/blob/development/docs/ffmpeg-max-workers-issues.md[/red]")
        else:
            logger.info(f"[red]FFmpeg error capturing screenshot: {stderr_text}[/red]")
        return (index, None)
    except Exception:
        logger.info(traceback.format_exc())
        return None


async def valid_ss_time(ss_times: list[str], num_screens: int, length: float, frame_rate: float, meta: Meta, retake: bool = False) -> list[str]:
    total_screens = num_screens + 1 if meta.is_disc else num_screens
    total_frames = int(length * frame_rate)

    # Track retake calls and adjust start frame accordingly
    retake_offset = 0
    if retake:
        if meta.retake_call_count is None:
            meta.retake_call_count = 0

        meta.retake_call_count += 1
        retake_offset = meta.retake_call_count * 0.01

        logger.debug(f"[cyan]Retake call #{meta.retake_call_count}, adding {retake_offset:.1%} offset[/cyan]")

    # Calculate usable portion (from 1% to 90% of video)
    if meta.category == "TV" and retake:
        start_frame = int(total_frames * (0.1 + retake_offset))
        end_frame = int(total_frames * 0.9)
    elif meta.category == "Movie" and retake:
        start_frame = int(total_frames * (0.05 + retake_offset))
        end_frame = int(total_frames * 0.9)
    else:
        start_frame = int(total_frames * (0.05 + retake_offset))
        end_frame = int(total_frames * 0.9)

    # Ensure start_frame doesn't exceed reasonable bounds
    max_start_frame = int(total_frames * 0.4)  # Don't start beyond 40%
    start_frame = min(start_frame, max_start_frame)

    usable_frames = end_frame - start_frame
    chosen_frames: list[int] = []

    frame_interval = usable_frames // total_screens if total_screens > 1 else usable_frames

    result_times: list[str] = ss_times.copy()

    for i in range(total_screens):
        frame = start_frame + (i * frame_interval)
        chosen_frames.append(frame)
        time = frame / frame_rate
        result_times.append(str(time))

    logger.debug(f"[purple]Screenshots information:[/purple] \n[slate_blue3]Screenshots: [gold3]{total_screens}[/gold3] \nTotal Frames: [gold3]{total_frames}[/gold3]")
    logger.debug(
        f"[slate_blue3]Start frame: [gold3]{start_frame}[/gold3] \nEnd frame: [gold3]{end_frame}[/gold3] \nUsable frames: [gold3]{usable_frames}[/gold3][/slate_blue3]"
    )
    logger.debug(f"[yellow]frame interval: {frame_interval} \n[purple]Chosen Frames[/purple]\n[gold3]{chosen_frames}[/gold3]\n")

    return sorted(result_times)


async def get_frame_info(path: str, ss_time: str | float, meta: Meta, dvd_title: int | None = None) -> dict[str, Any]:
    """Get frame information (type, exact timestamp) for a specific frame"""
    try:
        ss_time_value = float(ss_time)
        ffmpeg_module = cast(Any, ffmpeg)
        if dvd_title is not None:
            dvd_path = str(Path(path.removeprefix("concat:").split("|", 1)[0]).parent)
            info_ff = ffmpeg_module.input(dvd_path, ss=ss_time_value, format="dvdvideo", title=dvd_title)
        else:
            info_ff = ffmpeg_module.input(path, ss=ss_time_value)
        # Use video stream selector and apply showinfo filter
        filtered = info_ff["v:0"].filter("showinfo")
        info_command = filtered.output("-", format="null", vframes=1).global_args("-loglevel", "info")

        # Print the actual FFmpeg command for debugging
        cmd = compile_ffmpeg_command(info_command)
        logger.debug(f"[cyan]FFmpeg showinfo command: {' '.join(cmd)}[/cyan]")

        returncode, _, stderr = await run_ffmpeg(info_command)
        # Check if subprocess completed properly
        if returncode is None:
            cmd_str = " ".join(cmd)
            raise RuntimeError(f"FFmpeg subprocess did not complete properly. The process may have been terminated unexpectedly or failed to start. Command: {cmd_str}")
        stderr_text = stderr.decode("utf-8", errors="replace")

        # Calculate frame number based on timestamp and framerate
        frame_rate = meta.frame_rate if meta.frame_rate is not None else 24.0
        calculated_frame = int(ss_time_value * frame_rate)

        # Default values
        frame_info: dict[str, Any] = {"frame_type": "Unknown", "frame_number": calculated_frame}

        pict_type_match = re.search(r"pict_type:(\w)", stderr_text)
        if pict_type_match:
            frame_info["frame_type"] = pict_type_match.group(1)
        else:
            # Try alternative patterns that might appear in newer FFmpeg versions
            alt_match = re.search(r"type:(\w)\s", stderr_text)
            if alt_match:
                frame_info["frame_type"] = alt_match.group(1)

        pts_time_match = re.search(r"pts_time:(\d+\.\d+)", stderr_text)
        if pts_time_match:
            exact_time = float(pts_time_match.group(1))
            if dvd_title is not None and exact_time < ss_time_value:
                exact_time += ss_time_value
            frame_info["pts_time"] = exact_time
            # Recalculate frame number based on exact PTS time if available
            frame_info["frame_number"] = int(exact_time * frame_rate)

        return frame_info

    except Exception as e:
        logger.info(f"[yellow]Error getting frame info: {e}. Will use estimated values.[/yellow]")
        logger.debug(traceback.format_exc())
        return {"frame_type": "Unknown", "frame_number": int(float(ss_time) * (meta.frame_rate if meta.frame_rate is not None else 24.0))}


async def check_libplacebo_compatibility(
    w_sar: float, h_sar: float, width: float, height: float, path: str, ss_time: str, image_path: str, loglevel: str, meta: Meta
) -> tuple[bool, bool]:
    test_image_path = image_path.replace(".png", "_test.png")

    async def run_check(
        w_sar: float,
        h_sar: float,
        width: float,
        height: float,
        path: str,
        ss_time: str,
        _image_path: str,
        loglevel: str,
        meta: Meta,
        try_libplacebo: bool = False,
        test_image_path: str = "",
    ) -> bool:
        filter_parts: list[str] = []
        input_label = "[0:v]"
        output_map = "0:v"  # Default output mapping

        if w_sar != 1 or h_sar != 1:
            scaled_w = round_to_even(width * w_sar)
            scaled_h = round_to_even(height * h_sar)
            filter_parts.append(f"{input_label}scale={scaled_w}:{scaled_h}[scaled]")
            input_label = "[scaled]"
            output_map = "[scaled]"

        # Add libplacebo filter with output label
        if try_libplacebo:
            filter_parts.append(f"{input_label}libplacebo=tonemapping=auto:colorspace=bt709:color_primaries=bt709:color_trc=bt709:range=tv[out]")
            output_map = "[out]"
        else:
            # Use -vf for zscale/tonemap chain, no output label or -map needed
            vf_chain = f"zscale=transfer=linear,tonemap=tonemap={algorithm}:desat={desat},zscale=transfer=bt709,format=rgb24"

        # Build ffmpeg-python command and run
        if try_libplacebo:
            info_cmd: Any = (
                cast(Any, ffmpeg)
                .input(path, ss=ss_time)
                .output(test_image_path, vframes=1, pix_fmt="rgb24")
                .global_args("-y", "-loglevel", "quiet", "-init_hw_device", "vulkan", "-filter_complex", ",".join(filter_parts), "-map", output_map)
            )
        else:
            vf_chain = f"zscale=transfer=linear,tonemap=tonemap={algorithm}:desat={desat},zscale=transfer=bt709,format=rgb24"
            info_cmd: Any = cast(Any, ffmpeg).input(path, ss=ss_time).output(test_image_path, vframes=1, vf=vf_chain, pix_fmt="rgb24").global_args("-y", "-loglevel", "quiet")

        if loglevel == "verbose" or (meta and meta.debug):
            logger.info(f"[cyan]libplacebo compatibility test command: {' '.join(compile_ffmpeg_command(info_cmd))}[/cyan]")

        try:
            retcode, _stdout, _stderr = await run_ffmpeg(info_cmd)
            return retcode == 0
        except Exception:
            return False

    if not meta.is_disc:
        is_libplacebo_compatible = await run_check(w_sar, h_sar, width, height, path, ss_time, image_path, loglevel, meta, try_libplacebo=True, test_image_path=test_image_path)
        if is_libplacebo_compatible:
            logger.debug("[green]libplacebo compatibility test succeeded[/green]")
            with contextlib.suppress(Exception):
                if Path(test_image_path).exists():
                    Path(test_image_path).unlink()
            return True, True
        can_hdr = await run_check(w_sar, h_sar, width, height, path, ss_time, image_path, loglevel, meta, try_libplacebo=False, test_image_path=test_image_path)
        if can_hdr:
            logger.debug("[yellow]libplacebo compatibility test failed, but zscale HDR tonemapping is compatible[/yellow]")
            # Clean up the test image regardless of success/failure
            with contextlib.suppress(Exception):
                if Path(test_image_path).exists():
                    Path(test_image_path).unlink()
            return False, True
    return False, False


async def determine_tonemapping(w_sar: float, h_sar: float, width: float, height: float, path: str, ss_time: str, image_path: str, loglevel: str, meta: Meta) -> bool:
    """Select a verified tonemapping path and record its actual metadata state."""
    meta.libplacebo = False
    meta.tonemapped = False
    if not (tone_map or meta.force_tonemap) or not any(marker in meta.hdr for marker in ("HDR", "DV", "HLG")):
        return False

    if use_libplacebo and not meta.frame_overlay:
        if ffmpeg_is_good:
            meta.libplacebo = True
        else:
            libplacebo, compatible = await check_libplacebo_compatibility(w_sar, h_sar, width, height, path, ss_time, image_path, loglevel, meta)
            if not compatible:
                logger.info("[yellow]FFMPEG failed tonemap checking.[/yellow]")
                return False
            meta.libplacebo = libplacebo
        meta.tonemapped = True
        return True

    if any(marker in meta.hdr for marker in ("HDR", "DV", "HLG")):
        meta.tonemapped = True
        return True
    return False


async def libplacebo_warmup(path: str, meta: Meta, loglevel: str) -> None:
    if not meta.libplacebo or meta.libplacebo_warmed:
        return
    if not Path(path).exists():
        return
    # Use a very small seek (0.1s) to avoid issues at pts 0
    info_cmd: Any = (
        cast(Any, ffmpeg)
        .input(path, ss="0.1")
        .output("-", format="null", vframes=1)
        .global_args(
            "-map",
            "0:v:0",
            "-an",
            "-sn",
            "-init_hw_device",
            "vulkan",
            "-vf",
            "libplacebo=tonemapping=hable:colorspace=bt709:color_primaries=bt709:color_trc=bt709:range=tv,format=rgb24",
            "-loglevel",
            "error",
        )
    )
    if loglevel == "verbose" or meta.debug:
        logger.info("[cyan]Running libplacebo warm-up...[/cyan]")
    try:
        try:
            await run_ffmpeg(info_cmd)
        except Exception:
            # Warmup failures are non-fatal; continue
            if loglevel == "verbose" or meta.debug:
                logger.info("[yellow]libplacebo warm-up failed or errored (continuing anyway)[/yellow]")
        meta.libplacebo_warmed = True
    except Exception as e:
        if loglevel == "verbose" or meta.debug:
            logger.info(f"[yellow]libplacebo warm-up failed: {e} (continuing)[/yellow]")


async def get_image_host(meta: Meta) -> str | None:
    if meta.imghost is not None:
        host = meta.imghost

        if isinstance(host, str):
            return host.lower().strip()

        if isinstance(host, list):
            host_list = cast(list[Any], host)
            for item in host_list:
                if item and isinstance(item, str):
                    return item.lower().strip()
    else:
        img_host_config: list[str] = [str(default_config[key]).lower() for key in sorted(default_config.keys()) if key.startswith("img_host_1") and not key.endswith("0")]
        if img_host_config:
            return img_host_config[0]
    return None


class TakeScreensManager:
    def __init__(self, config: dict[str, Any]) -> None:
        self.config = config
        _apply_config(config)

    async def run_ffmpeg(self, command: Any) -> tuple[int | None, bytes, bytes]:
        return await run_ffmpeg(command)

    async def sanitize_filename(self, filename: str) -> str:
        return await sanitize_filename(filename)

    async def disc_screenshots(
        self,
        meta: Meta,
        filename: str,
        bdinfo: dict[str, Any],
        folder_id: str,
        base_dir: str,
        use_vs: bool,
        image_list: list[dict[str, str]] | None = None,
        ffdebug: bool = False,
        num_screens: int = 0,
        force_screenshots: bool = False,
        cleanup_after_capture: bool = True,
        capture_group: str | None = None,
    ) -> list[Path]:
        return await disc_screenshots(
            meta, filename, bdinfo, folder_id, base_dir, use_vs, image_list, ffdebug, num_screens, force_screenshots, cleanup_after_capture, capture_group
        )

    async def capture_disc_task(
        self, index: int, file: str, ss_time: str, image_path: str, keyframe: str, loglevel: str, hdr_tonemap: bool, meta: Meta
    ) -> tuple[int, str] | None:
        return await capture_disc_task(index, file, ss_time, image_path, keyframe, loglevel, hdr_tonemap, meta)

    async def dvd_screenshots(
        self,
        meta: Meta,
        disc_num: int,
        num_screens: int = 0,
        retry_cap: bool = False,
        cleanup_after_capture: bool = True,
    ) -> None:
        await dvd_screenshots(meta, disc_num, num_screens, retry_cap, cleanup_after_capture)

    async def capture_dvd_screenshot(
        self, task: tuple[int, str, str, str, Meta, float, float, float, float] | tuple[int, str, str, str, Meta, float, float, float, float, int | None]
    ) -> tuple[int, str | None]:
        return await capture_dvd_screenshot(task)

    async def screenshots(
        self,
        path: str,
        filename: str,
        folder_id: str,
        base_dir: str,
        meta: Meta,
        num_screens: int = 0,
        force_screenshots: bool = False,
        manual_frames: str | list[int] | list[str] = "",
        cleanup_after_capture: bool = True,
        capture_group: str | None = None,
    ) -> list[str] | None:
        return await screenshots(path, filename, folder_id, base_dir, meta, num_screens, force_screenshots, manual_frames, cleanup_after_capture, capture_group)

    def xxx_contact_sheet_settings(self) -> tuple[int, int, int]:
        return xxx_contact_sheet_settings()

    def xxx_contact_sheet_animation_settings(self) -> tuple[bool, float]:
        return xxx_contact_sheet_animation_settings()

    async def xxx_contact_sheets(self, paths: list[str], folder_id: str, base_dir: str, meta: Meta, capture_group: str = "main") -> list[str]:
        return await xxx_contact_sheets(paths, folder_id, base_dir, meta, capture_group)

    async def xxx_fallback_cover(self, paths: list[str], folder_id: str, base_dir: str, meta: Meta, random_frame: bool = False) -> str | None:
        return await xxx_fallback_cover(paths, folder_id, base_dir, meta, random_frame)

    async def prepare_book_cover(self, path: str, folder_id: str, base_dir: str, meta: Meta) -> str | None:
        return await prepare_book_cover(path, folder_id, base_dir, meta)

    async def ebook_page_screenshots(self, path: str, filename: str, folder_id: str, base_dir: str, meta: Meta) -> list[str]:
        """Capture only book pages, leaving cover and banner to the later upload stage."""
        return await generate_ebook_screenshots(path, filename, folder_id, base_dir, meta, meta.screens, artwork=False)

    async def capture_screenshot(self, args: tuple[int, str, float, str, float, float, float, float, str, bool, Meta]) -> tuple[int, str | None] | None:
        return await capture_screenshot(args)

    async def valid_ss_time(self, ss_times: list[str], num_screens: int, length: float, frame_rate: float, meta: Meta, retake: bool = False) -> list[str]:
        return await valid_ss_time(ss_times, num_screens, length, frame_rate, meta, retake)

    async def get_frame_info(self, path: str, ss_time: str, meta: Meta) -> dict[str, Any]:
        return await get_frame_info(path, ss_time, meta)

    async def check_libplacebo_compatibility(
        self, w_sar: float, h_sar: float, width: float, height: float, path: str, ss_time: str, image_path: str, loglevel: str, meta: Meta
    ) -> tuple[bool, bool]:
        return await check_libplacebo_compatibility(w_sar, h_sar, width, height, path, ss_time, image_path, loglevel, meta)

    async def libplacebo_warmup(self, path: str, meta: Meta, loglevel: str) -> None:
        await libplacebo_warmup(path, meta, loglevel)

    async def get_image_host(self, meta: Meta) -> str | None:
        return await get_image_host(meta)
