There is a docker image available for Upload-Assistant that is automatically built within a few minutes of each release.

> **Looking for the WebUI?** See [docker-gui.md](docker-gui.md) for the WebUI Docker setup (environment variables, persistent sessions, Compose examples, and Unraid notes).

See this video which covers many aspects of docker itself, and setting up for UA. Note that the video will be slightly out of date in a few minor aspects, particularly the webui if using that.
The video should be viewed in conjunction with the documentation here.

https://videos.badkitty.zone/ua

## Supported Architectures

The Docker images are built for multiple architectures:

| Architecture  | Platform         | Examples                                                          |
| ------------- | ---------------- | ----------------------------------------------------------------- |
| `linux/amd64` | Intel/AMD 64-bit | Most desktop PCs, Intel Macs, cloud VMs                           |
| `linux/arm64` | ARM 64-bit       | Apple Silicon Macs, Raspberry Pi 4/5, AWS Graviton, Oracle Ampere |

Docker will automatically pull the correct image for your system architecture.

## Usage?

```
docker run --rm -it --network=host \
-v /full/path/to/appdata:/state \
-v /full/path/to/downloads:/downloads \
ghcr.io/wastaken7/upload-assistant:latest /downloads/path/to/content --help
```

`/state` is the container's persistent, writable application-state root. It holds `data/config.py`, cookies, caches and temporary upload artifacts. Mount a directory, not a single `config.py` file. On the first Web UI or CLI upload run, the application creates `/state/data/config.py` from the bundled example. A first CLI run stops so you can edit the file before retrying; the Web UI continues to its configuration page. The paths in your config file need to refer to paths inside the docker image, same with path provided for file. May need to utilize remote path mapping for your client.

## What if I want to utilize re-using torrents and I use qbit?

Add another -v line to your command to expose your BT_Backup folder, and set the path in your config to /BT_Backup

```
docker run --rm -it --network=host \
-v /full/path/to/appdata:/state \
-v /full/path/to/downloads:/downloads \
-v /full/path/to/BT_backup:/BT_backup \
ghcr.io/wastaken7/upload-assistant:latest /downloads/path/to/content --help
```

## What if I want to utilize re-using torrents and I use rtorrent/rutorrent?

Add another -v line to your command to expose your session folder, and set the path in your config to /session

```
docker run --rm -it --network=host \
-v /full/path/to/appdata:/state \
-v /full/path/to/downloads:/downloads \
-v /full/path/to/session/folder:/session \
ghcr.io/wastaken7/upload-assistant:latest /downloads/path/to/content --help
```

## What is docker?

Google is your friend

## How do I update the docker image?

```bash
docker pull ghcr.io/wastaken7/upload-assistant:latest
# Recreate the container to run the pulled image.
# Docker Compose: docker compose up -d
```

## How do I use an image of a specific commit?

```
docker run --rm -it --network=host \
-v /full/path/to/appdata:/state \
-v /full/path/to/downloads:/downloads \
ghcr.io/wastaken7/upload-assistant:abc123 /downloads/path/to/content --help
```

Where abc123 is the first 6 digits of the hash of the commit

## Can I use this with Docker on Windows?

Yes, but this is a Linux container, so make sure you are running in that mode. Mount a directory such as `C:\\Upload-Assistant` to `/state`; do not mount a single configuration file. Windows paths with spaces still need careful Docker volume syntax.

## The command for running is really long and I dont want to type it.

Make an alias or a function or something. Will depend on OS. I use

```
function upload(){
        # save args as array and expand each element inside of ""
        args=("$@")
        args="${args[@]@Q}"
        echo $args
        docker pull ghcr.io/wastaken7/upload-assistant:latest
        eval "docker run --rm -it --network=host -v /full/path/to/appdata:/state -v /full/path/to/downloads:/downloads -v /full/path/to/BT_backup:/BT_backup ghcr.io/wastaken7/upload-assistant:latest ${args}"
}
```

This prints out the parameters passed as well so you can see for sure what is happening.

## Can I utilize the -vs/--vapoursynth parameter?

No. The base docker image does not include vapoursynth in its package manager and building it or downloading the portable version into the python directory and configuring was decided to not be worth the extra complexity for something that probably gets very little usage and would probably break regularly. If this is important to you let us know.
