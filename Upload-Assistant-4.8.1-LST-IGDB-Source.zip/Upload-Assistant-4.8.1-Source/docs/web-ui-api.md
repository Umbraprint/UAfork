# Upload Assistant — WebUI API Reference

This document summarizes the WebUI HTTP API implemented in `web_ui/server.py`. For each endpoint it lists HTTP methods, authentication and CSRF requirements, accepted payload or query parameters, special rules, and example response shapes. For normal browser usage, see the [WebUI guide](web-ui.md).

See the guide's [Request limits](web-ui.md#request-limits) table for all default limits, endpoint overrides, and exemptions. Routes without an override allow 50 requests per hour and 200 per day, counted separately per endpoint and client IP. Explicit endpoint limits replace those defaults.

---

### /api/health

- Methods: GET
- Auth: none
- Rate limit: exempt
- Description: basic health check
- Response: {"status": "healthy", "success": true, "message": "..."}

### /api/stats

- Methods: GET, DELETE
- Auth: authenticated browser session only; Bearer tokens are rejected
- CSRF: valid CSRF header and same-origin request required for both methods
- GET query: `range=today|this_month|last_month|7d|30d|90d|1y|all|custom`, `mode=real|debug`, and optional `tracker=<canonical ID>`. The default `timezone=utc` uses the server's current UTC date. `timezone=browser` requires the browser to send its current local date as `today=YYYY-MM-DD`; preset and custom-range validation then use that local date boundary. A custom range requires inclusive dates in `from=YYYY-MM-DD` and `to=YYYY-MM-DD`. Stored activity remains grouped into its original UTC calendar-day buckets in either mode.
- GET description: returns an `enabled` flag plus the stable overview, timeline, 365-day heatmap, previous-period comparison, Sankey route flow, upload destination/category, successful media time by category, category-specific media profile and resolution/profile matrix, streaming-service, personal/standard release-profile, artifact, cache, logical external-operation, execution-source, and filter shapes. Content aggregates honor `tracker`; cache and external-operation aggregates remain global. Volume fields contain media bytes rather than `.torrent` or `.nzb` file sizes. When collection is disabled, every aggregate is zero-filled and stored data is not read or returned.
- DELETE payload: `{"confirmation":"RESET"}`
- Read failures (including an unreadable database or unsupported schema version) return HTTP 500 with `success=false` and an error message, rather than an empty successful response. Unknown schema versions are preserved.
- DELETE description: clears real and debug statistics in one transaction; caches, configuration, torrents, and NZBs are unaffected

Statistics contain no per-release events, names, paths, release-group names or tags, external media IDs, URLs, or credentials. Tracker flow is stored as aggregate item×destination routes. The release profile stores only the aggregate `personal` or `standard` classification. `content_time` contains aggregate successful item counts and whole seconds by stable media category; an item is counted once globally regardless of its number of destinations. The `api` section counts logical adapter operations rather than transport retries. Its `bytes` values contain known payload bytes sent through NNTP and successful image uploads; zero means the payload size was unavailable or no measured bytes were sent.

### /api/execute

- Methods: POST, OPTIONS
- Auth: POST requires CSRF header for web session callers; Bearer tokens (API tokens) are accepted for programmatic use and bypass CSRF. Token must be valid.
- Rate limit: 100 per hour (keyed by \_rate_limit_key_func)
- POST payload: {"path": "`<file-or-folder>`", "args": "`<cmdline args>`", "session_id": "`<id>`"}
- Description: start an isolated `upload.py` subprocess. The endpoint returns a Server-Sent Events (SSE) stream — connect using `Accept: text/event-stream` and read events as they arrive. `OPTIONS` responds with 204 for CORS preflight.
- Notes on payload quoting and Windows paths:
  - JSON values must use double quotes. When sending Windows paths from shells that perform quoting/escaping (PowerShell, cmd.exe), backslashes need special handling (escape them or use forward slashes). To avoid brittle quoting, prefer one of the approaches in the examples below.
  - The server attempts tolerant parsing: it accepts JSON, form-encoded bodies, or will attempt conservative normalization of raw bodies to extract `path` and `session_id` if standard JSON parsing fails. However, relying on correct JSON or a file payload is recommended for reliability.
- Response: SSE stream on success. On immediate validation or parse errors the API returns JSON like {"error":"...","success":false} (HTTP 4xx/5xx as appropriate).
- Structured run events: besides `html` terminal output, the stream carries `{"type":"gui","data":{...}}` events, which the WebUI's GUI output mode uses. `data.kind` is one of:

  | `kind`         | Fields                                                                                                                                              |
  | -------------- | --------------------------------------------------------------------------------------------------------------------------------------------------- |
  | `item`         | `index`, `total`, `name`, optional `personal_release`, `run_options` — a queue item started or updated after metadata preparation                   |
  | `stage`        | `key` (`prep`, `confirm`, `dupes`, `screens`, `torrent`, `upload`, `requests`), `status` (`start`, `done`, `skip`, `fail`)                          |
  | `notice`       | `level` (`error`, `warning`, `attention`), `text`, optional `tracker`, `key`                                                                        |
  | `notice_group` | `group`, `notices` — replaces the earlier notices of that group                                                                                     |
  | `prompt`       | `action` (`open`, `close`), `id`; on open: `type` (`yes_no`, `choice`, `text`), `question`, optional `choices`, `default`, `context`                |
  | `dupes`        | `tracker`, `entries` (`name`, optional `link`, `size`, `diff_pct`, `color`: hex size-difference colour), `note`, `trumpable`                        |
  | `dupe_review`  | `trackers` needing manual review, `started` in actual review order, `checking` — unresolved checks in this item                                     |
  | `slot`         | `tracker`, `verdict` (`allow`, `review`, `block`), `title`, `reason`; optional `slot`, `why`, `conflicts` (entries as in `dupes`), `notes`, `rules` |
  | `tracker`      | `tracker`, `status` (`pending`, `success`, `failed`, `skipped`, `dupe`, `banned`), optional `link`, `torrent_id`, `message`, `duration`             |
  | `request`      | `tracker`, `name`, `exact`, optional `link`, `reward`, `status`                                                                                     |

  Every event has `ts` and, inside a queue, `item`. Text is plain (no markup) and redacted. Answers to prompts still go through `/api/input`.

  `item.run_options` carries resolved booleans `debug`, `no_seed`, `skip_imghost_upload`, `nohash`, `ffdebug`, `client_disabled`, plus plain-text `category` and `prep_directory`. It is published before preparation and refreshed at confirmation, including unattended runs. The Debug Run badge explains active skip flags; client addition and image-host uploads can still occur when their skip options are disabled.

  Tracker check prompts include `context.tracker` and `context.check_messages` when explanations are available. The GUI shows these messages before the upload decision; a declined check retains its explanation in the tracker's result `message`.

  During duplicate review, the GUI counts trackers requiring manual decisions, including slot-rule overrides and trumping. Several questions for one tracker count as one review. A `+` after the total and “Still checking trackers…” mean discovery is incomplete; the total becomes final once `checking` reaches zero. Review state is isolated to each queue item and upload session.

  The final `dupe_clear` confirmation includes `context.client_skipped_trackers`, a list of selected trackers actually removed because they were found in the torrent client. The upload question contains only the upload targets; a separate, always-expanded **Skipped** panel groups possible duplicates, tracker-rule skips and client skips. Empty groups and an empty panel are omitted. The client-skip list resets for each run item and stays empty in debug mode, where client matches are retained for checks.

Examples

- Simple streaming curl (Unix-like / WSL / Git Bash). Use forward slashes to avoid escaping backslashes in Windows paths:

```bash
curl -N \
  -H "Authorization: Bearer <API_TOKEN>" \
  -H "Content-Type: application/json" \
  -H "Accept: text/event-stream" \
  -X POST "http://127.0.0.1:5000/api/execute" \
  -d '{"path":"D:/Movies/My Movie.mkv","session_id":"{hash}"}'
```

- curl reading payload from a file (recommended to avoid quoting/escaping issues):

Create `payload.json` containing:

```json
{ "path": "D:/Movies/My Movie.mkv", "session_id": "{hash}" }
```

Then:

```bash
curl -N -H "Authorization: Bearer <API_TOKEN>" -H "Content-Type: application/json" -H "Accept: text/event-stream" --data-binary @payload.json http://127.0.0.1:5000/api/execute
```

- Windows (PowerShell / cmd) curl example — escape JSON double quotes or use a payload file. Example with escaped quotes:

```powershell
curl.exe -N -H "Authorization: Bearer <API_TOKEN>" -H "Content-Type: application/json" -H "Accept: text/event-stream" -X POST "http://127.0.0.1:5000/api/execute" -d "{\"path\":\"D:/Movies/My Movie.mkv\",\"session_id\":\"{hash}\"}"
```

If you run Qui (or any external program runner) that substitutes placeholders into arguments, prefer writing a small wrapper script on the Qui host that builds the JSON via a language-native serializer (PowerShell `ConvertTo-Json`, `jq`, Python, etc.) — this avoids brittle shell quoting and escaping.

### Arguments and validation

- `args` field: when provided, the endpoint expects `args` to be a single string containing the command-line arguments you want passed to `upload.py`.

```bash
curl -N \
  -H "Authorization: Bearer <API_TOKEN>" \
  -H "Content-Type: application/json" \
  -H "Accept: text/event-stream" \
  -X POST "http://127.0.0.1:5000/api/execute" \
  -d '{"path":"D:/Movies/My Movie.mkv","args":"--debug -season 01","session_id":"{hash}"}'
```

### Qui-specific PowerShell example

If you plan to run `curl.exe` from Qui on a Windows host using PowerShell, use `powershell.exe` as the program path and pass a single `-Command` string so placeholders are substituted by Qui before PowerShell runs. This example includes the Upload‑Assistant `-ua` argument via the `args` payload key and shows quoting that avoids PowerShell parsing issues:

Program Path (Qui):

```
powershell.exe
```

Arguments Template (Qui):

```
-NoProfile -NonInteractive -Command "curl.exe -sS -X POST -H 'Content-Type: application/json' -H 'Authorization: Bearer <API_TOKEN>' -d '{"path":"{content_path}","args":"-ua","session_id":"{hash}"}' http://127.0.0.1:5000/api/execute"
```

Notes:

- Qui will substitute `{content_path}` and `{hash}` into the arguments template before launching PowerShell. The JSON payload is wrapped as one argument to `curl.exe` and uses escaped double-quotes so PowerShell passes the literal JSON to `curl.exe`.
- If Upload‑Assistant is not on `127.0.0.1:5000` from the Qui host, replace the URL with the reachable service address.
- If you face quoting headaches, prefer the wrapper script approach (PowerShell `ConvertTo-Json` or a small `.ps1` file) which avoids manual JSON escaping.
- No terminal is required/terminal does not work with the above setup.

### /api/input

- Methods: POST
- Auth: requires either a valid Bearer API token (programmatic clients) OR a logged-in web session. Bearer tokens are allowed without CSRF; session callers must be authenticated. Rate-limited.
- Rate limit: 200 per hour
- POST payload: {"session_id": "default", "input": "..."}
- Description: send interactive input to a running execution subprocess through stdin
- Response: {"success": true} or error JSON

### /api/kill

- Methods: POST
- Auth: requires either a valid Bearer API token (programmatic clients) OR a logged-in web session. Bearer tokens are allowed without CSRF; session callers must be authenticated. Rate-limited.
- Rate limit: 50 per hour
- POST payload: {"session_id": "..."}
- Description: terminate a running execution session and perform cleanup
- Response: {"success": true, "message": "..."} or error JSON

### /api/browse

- Methods: GET
- Auth: requires either a valid Bearer API token (programmatic use) OR a logged-in web session + CSRF + Origin (same-origin). Bearer tokens are allowed without CSRF; session callers must provide `X-CSRF-Token` and same-origin headers.
- Rate limit: 600 per minute; replaces the default hourly and daily quotas
- Query params: path (filesystem path within configured browse roots)
- Description: lists non-hidden files and folders in the resolved path; `filter=desc` limits files to supported description formats
- Response: {"items": [...], "success": true, "path": "...", "count": N}

### /api/browse_search

- Methods: GET
- Auth: same Bearer-token or authenticated-session requirements as `/api/browse`
- Rate limit: 60 per minute; replaces the default hourly and daily quotas
- Query params: `q` (search text), optional `filter` and `max_results` (default 100, maximum 500)
- Description: recursively searches the configured browse roots for matching files and folders
- Response: {"items": [...], "success": true, "query": "...", "count": N, "truncated": true|false}

---

The following endpoints via a valid web session.

### /api/csrf_token

- Methods: GET
- Auth: requires web session (login/remember)
- Description: returns per-session CSRF token for use by the frontend
- Response: {"csrf_token": "`<token>`", "success": true}

### /api/2fa/status

- Methods: GET
- Auth: requires web session + CSRF + Origin (same-origin)
- Description: whether TOTP 2FA is enabled for the user
- Response: {"enabled": true|false, "success": true}

### /api/access_log/level

- Methods: GET, POST
- Auth: GET — requires web session + CSRF + Origin; POST — requires web session + CSRF + Origin
- POST payload: {"level": "access_denied"|"access"|"disabled"}
- Description: read or set access logging level
- Responses: GET -> {"success": true, "level": "..."}; POST -> {"success": true, "level": "..."}

### /api/access_log/entries

- Methods: GET
- Auth: requires web session + CSRF + Origin
- Query params: n (number of entries, default 50, max 200)
- Description: returns recent access log entries
- Response: {"success": true, "entries": [...]}

### /api/ip_control

- Methods: GET, POST
- Auth: requires web session + CSRF + Origin for both GET and POST
- POST payload: {"whitelist": ["1.2.3.4"], "blacklist": ["5.6.7.8"]}
- Description: read or update IP whitelist/blacklist (IP addresses validated)
- Response: GET -> {"success": true, "whitelist": [...], "blacklist": [...]}; POST -> {"success": true}

### /api/2fa/setup

- Methods: POST
- Auth: requires web session + CSRF + Origin (disallows API tokens or basic auth)
- Description: generate a temporary TOTP secret, provisioning URI and one-time recovery codes; stores temp values in session
- Response: {"secret": "`<base32>`", "uri": "otpauth://...", "recovery_codes": [...], "success": true}

### /api/2fa/enable

- Methods: POST
- Auth: requires web session + CSRF + Origin
- POST payload: {"code": "123456"}
- Description: verify temporary TOTP code and enable 2FA; persists hashed recovery codes
- Response: {"success": true, "recovery_codes": [...]} (returns the one-time recovery codes initially generated)

### /api/2fa/disable

- Methods: POST
- Auth: requires web session + CSRF + Origin
- Description: disable 2FA for the user; clears TOTP secret and recovery codes
- Response: {"success": true}

### /api/browse_roots

- Methods: GET
- Auth: requires an authenticated request; if a Bearer token is provided it must be valid
- Rate limit: exempt
- Description: returns configured browse root directories
- Response: {"items": [{"name":"...","path":"...","type":"folder"}], "success": true}

### /api/config_options

- Methods: GET
- Auth: requires web session + CSRF + Origin (disallows bearer/basic auth)
- Description: returns configuration options derived from example_config.py + user overrides
- Response: {"success": true, "sections": [...]}

### /api/torrent_clients

- Methods: GET
- Auth: requires web session + CSRF + Origin (disallows bearer token)
- Description: returns list of configured torrent client names
- Response: {"success": true, "clients": ["qbit", ...]}

### /api/trackers

- Methods: GET
- Auth: requires web session + CSRF + Origin (disallows bearer token)
- Description: returns the supported tracker catalogue, including display names, local icons, homepage URLs, and default/configured state
- Response: {"success": true, "default_trackers": ["AITHER", ...], "trackers": [...]}

### /api/tracker_status

- Methods: GET, POST
- Auth: requires web session + CSRF + Origin (disallows bearer token)
- Rate limit: POST allows 30 checks per hour; GET inherits the default 50 per hour and 200 per day
- POST payload: {"trackers": ["AITHER", "BLUTOPIA"]}
- Description: GET returns cached tracker website-reachability results. POST refreshes the named supported trackers concurrently without using credentials or downloading response bodies. Results expire after 15 minutes and are advisory only.
- Response: {"success": true, "cache_seconds": 900, "statuses": {"AITHER": {"state": "available", "message": "...", "checked_at": "...", "stale": false}}}. Issue and unavailable results can also include a machine-readable `reason`, such as `timeout`, `connection`, `rate_limit`, or `server_error`.

### /api/config_update

- Methods: POST
- Auth: requires web session + CSRF + Origin (disallows bearer/basic auth)
- POST payload: {"path": ["SECTION", "KEY"], "value": `<value>`} (path is array of path components)
- Description: updates data/config.py with a coerced Python literal of the provided value; special handling for certain client lists
- Response: {"success": true, "value": `<json-safe-value>`}

### /api/config_remove_subsection

- Methods: POST
- Auth: requires web session + CSRF + Origin
- POST payload: {"path": ["SECTION"]}
- Description: remove a top-level subsection from user config
- Response: {"success": true, "value": null}

### /api/tokens

- Methods: GET, POST, DELETE
- Auth: requires web session + CSRF + Origin; management disallowed via Basic/Bearer auth
- GET: lists token metadata (id, user, label, created, expiry) — does NOT return token secret values
  - Response: {"success": true, "tokens": [...], "read_only": false}
- POST: create or store a token
  - payload for generate: {"action": "generate", "label": "...", "persist": true|false}
  - payload for store: {"action": "store", "token": "`<token_string>`", "label": "..."}
  - Response (generate): {"success": true, "token": "`<token_or_null>`", "persisted": true|false}
- DELETE: revoke token
  - payload: {"id": "`<token_id>`"}
  - Response: {"success": true}

---

Notes & security model summary:

- Web session authentication (login + encrypted session cookie) is required for any endpoints that modify server state (config, tokens, IP lists, enabling/disabling 2FA). Bearer tokens are intended for programmatic calls and are accepted only on a subset of read/execute endpoints; tokens are validated as valid/invalid (no per-token scope enforcement).
- CSRF protection: state-changing endpoints invoked from the browser require a per-session CSRF token passed in a header (see `/api/csrf_token`). Token management endpoints explicitly disallow Basic/Bearer auth to ensure management is performed from the authenticated UI with CSRF protection.
- HTTP Basic auth is rejected while 2FA is enabled, because it cannot carry a second factor. Use a Bearer API token for programmatic access.
- Rate limits: defaults apply to routes without an override or exemption. Counters are separate per endpoint and client IP; most explicitly limited API routes also distinguish authenticated and unauthenticated requests. See [Request limits](web-ui.md#request-limits) for the full table and HTTP 429 behaviour.
