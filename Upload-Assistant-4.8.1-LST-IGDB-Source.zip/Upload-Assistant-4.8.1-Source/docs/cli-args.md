# Upload Assistant CLI arguments

This document describes the command-line arguments parsed in `src/args.py`.

The WebUI argument picker reads available flags and help text from that same parser. `web_ui/static/js/app.js` only defines their grouping, example placeholders, and command presets. CLI options without a dedicated group appear under **Other CLI options** automatically. CLI startup flags such as `--webui` and `--paths-from-stdin` are excluded from the picker.

## Help output

- `-h` shows a short/curated help (common options only).
- `--help` shows the full argparse help.

## Basic usage

```text
upload.py [path...] [options]
```

- `path` (positional): One or more paths to a file or directory.
  - Quoting is recommended (single or double quotes) especially when paths contain spaces.
  - The parser has a small recovery mechanism: if extra “unknown” tokens were provided and the joined `path` doesn’t exist, it will append those tokens into the path until it finds an existing path.

### Pasting multiple full paths

Use `--paths-from-stdin` when copying multiple full paths from a torrent client or another application. This keeps spaces, parentheses, and other shell-sensitive characters inside each path instead of letting the shell interpret them.

```console
python upload.py -ua -sda --paths-from-stdin
Paste one full path per line, then press Enter on an empty line to start.
/home/seedbox/data/torrents/sonarr/First.Release.mkv
/home/seedbox/data/torrents/sonarr/Release With Spaces (2026).mkv

```

After pasting the paths, press Enter on the empty line. For scripts and pipes, input is read until EOF instead:

```console
printf '%s\n' "/path/First.mkv" "/path/Release With Spaces (2026).mkv" | python upload.py -ua -sda --paths-from-stdin
```

This option is available in the CLI only. In the Web UI, select paths with the built-in browser or queue controls.

### Validation rules

- You must provide at least one `path`, paths through `--paths-from-stdin`, `--site-upload`, or `--webui`.
- If `--site-upload` is provided without a `path`, the parser injects a dummy path internally (so downstream code can continue).

## Modes / workflows

- `--queue QUEUE_NAME`: Process an entire folder (including files/subfolders) in a named queue.
- `-lq`, `--limit-queue N`: Limit the amount of sucessfull uploads processed when running the queue (default `0` unlimited).
- `-sc`, `--site-check`: Search trackers for suitable uploads and create a log file (no uploading).
- `-su`, `--site-upload TRACKER`: Process site searches and upload to a single tracker (the tracker identifier is normalized to uppercase).
- `--unit3d`: Parse a text output file from `UNIT3D-Upload-Checker`.

### Argument-Embedded Text Queue (.txt)

If you pass a `.txt` file as the main positional input path (without specifying `--unit3d`), Upload Assistant will treat it as a batch queue of independent upload tasks, where each line represents a separate command.

- **Format**: Each line contains the path to the directory/file to upload, followed by any custom arguments/flags you want to apply to that specific task:
  ```text
  "F:\Movies\Fun.Movie.2026.1080p.BluRay-Group" -tk AITHER -df "desc_filename.txt" -imdb tt00000000 --anon
  "D:\TV Shows\Fun.TV.Show.2026.1080p.WEB-DL-Group" -tk LST -df "desc_filename.txt" -tvdb 00000000 -pr
  ```
- **Comments and Empty Lines**: You can add comments starting with `#` or leave empty lines; they are automatically skipped.
- **Queue Progress & Resume**: Progress is isolated and tracked automatically based on the `.txt` filename (e.g., `my_queue.txt` uses `tmp/my_queue_processed_files.log`). If you stop and restart, Upload Assistant will skip already completed lines, allowing you to easily resume or append new items to the file.
- **Global Defaults & Overrides**: Any arguments passed to the initial command (e.g., `python upload.py my_queue.txt -debug --anon`) act as **global defaults** for all items in the queue. Line-specific arguments inside the `.txt` file will override these defaults for that specific task. For example, passing `-debug` globally is a great way to dry-run your entire queue!

## Screenshots / images

- `-s`, `--screens N`: Number of screenshots.
  - Default comes from config: `DEFAULT.screens`.
- `-mf`, `--manual_frames "1,250,500"`: Comma-separated frame numbers to use as screenshots.
  - Parsed into a list of integers; invalid format exits.
- `-comps`, `--comparison PATH`: Use comparison images from a folder.
- `-comps_index`, `--comparison_index N`: Which comparison index is the “main” images (required when using `--comparison`).
- `-menus`, `--disc-menus PATH`: Raw Disc only (Blu-ray/DVD). Folder containing disc menu screenshots (all images in folder are used).
- `-ih`, `--imghost HOST`: Select image host.
  - Choices: `catbox`, `imgbb`, `imgbox`, `pixhost`, `lensdump`, `ptscreens`, `onlyimage`, `dalexni`, `zipline`, `midnightscene`, `passtheimage`, `seedpool_cdn`, `utppm`, `lostimg`.
- `-siu`, `--skip-imagehost-upload`: Skip uploading images to an image host.

## Description inputs

- `-pb`, `--desclink URL`: Custom description link (hastebin/pastebin).
- `--description TEXT`: Inline custom description block (quote text containing spaces or BBCode).
- `-df`, `--descfile PATH`: Custom description file path (or filename in current working directory).
  - Stored as an absolute path.
- `-nfo`, `--nfo`: Use `.nfo` in directory for description.

## Metadata overrides (IDs, category/type/source, title shaping)

- These will override what Upload Assistant automatically decides. Recommend to only use overrides when needed to correct automatic detection.

### Category / type / source / resolution

- `-c`, `--category {movie,tv,sports,fanres,book,game,music,xxx}`: Override the category.
- `-t`, `--type {disc,remux,encode,webdl,web-dl,webrip,hdtv,dvdrip}`: Override release type.
  - Stored as uppercase with `-` removed (e.g. `web-dl` → `WEBDL`).
- `--source {Blu-ray,BluRay,DVD,DVD5,DVD9,HDDVD,WEB,HDTV,UHDTV,LaserDisc,DCP}`: Override the source string.
- `-res`, `--resolution {2160p,1080p,1080i,720p,576p,576i,480p,480i,8640p,4320p,other}`: Override the resolution.

### External IDs

- `-tmdb`, `--tmdb TMDB_ID`: TMDb id; supports `movie/123` or `tv/123` forms.
  - Also accepts TMDb URLs and extracts the id.
  - Sets category based on `movie` vs `tv` when provided in that form.
- `-imdb`, `--imdb IMDB_ID`: IMDb id.
- `-mal`, `--mal MAL_ID`: MAL id.
- `-tvmaze`, `--tvmaze TVMAZE_ID`: TVMaze id.
- `-tvdb`, `--tvdb TVDB_ID`: TVDB id.

Note: if a manual TMDb or IMDb id is present in the incoming `meta` before parsing, the parser clears `tmdb_manual`, `tmdb_id`, `tmdb`, `imdb_id`, `imdb` in `meta` so CLI values take precedence cleanly.

### Book and audiobook metadata

- `-asin`, `--asin ASIN`: Override the detected book or audiobook ASIN.
- `--audible-url URL`: Use an Audible product URL, derive its ASIN, and override the configured `DEFAULT.audible_domain` marketplace for this upload.
- `-isbn`, `--isbn ISBN`: Override the detected ISBN.
- `-author`, `--author NAME`: Override the detected author.
- `-btitle`, `--book-title TITLE`: Override the detected book title.
- `--book-narrator NAME`: Override the detected audiobook narrator.
- `--genres GENRE[,GENRE...]`: Override the detected genres for any category.
- `-ov`, `--overview TEXT`: Override the detected overview or synopsis for any category (`--book-overview` remains an alias).

### Game metadata

- `--game-title TITLE`: Override the detected game title.
- `--developer NAME`: Override the detected game developer.
- `-pub`, `--publisher NAME`: Override the game publisher.

### Tags / edition / language

- `--name RELEASE_NAME`: Override the generated release name, including XXX release titles.
- `--cast NAME[,NAME...]`: Override cast or XXX performers with a comma-separated list. This takes priority over detected metadata.
- `-pub`, `--publisher NAME`: Override the book/audiobook or game publisher, or XXX studio.
- `-g`, `--tag [GROUP ...]`: Group tag.
  - Stored with a leading dash, e.g. `-g NTb` → `-NTb`.
- `-serv`, `--service [SERVICE ...]`: Streaming service.
- `-dist`, `--distributor [NAME ...]`: Disc distributor (Criterion, BFI, etc.).
- `-edition`, `--edition`, `--repack [TEXT ...]`: Edition/repack string.
- `-ol`, `--original-language LANG`: Set original audio language.
- `-oil`, `--only-if-languages [LANG ...]`: Require at least one language to upload (comma-separated list in a single string is supported).

### TV fields

- `-season`, `--season N`: Season (string).
  - Stored as `manual_season` in `meta`.
- `-episode`, `--episode N`: Episode (string).
  - Stored as `manual_episode` in `meta`.
- `-met`, `--manual-episode-title [TITLE ...]`: Manual episode title.
  - Passing the option with no words sets an empty string.
- `-daily`, `--daily YYYY-MM-DD`: Air date (parsed via `datetime.date.fromisoformat`).

### Game fields

- `-plat`, `--platform`, `--platforms PLATFORM`: Game platform (e.g. PC, PS5, XBOX) (overrides auto-detected value).
  - Stored as `manual_platform` in `meta`.

### Title shaping toggles

- `--no-season`: Remove Season from title.
- `--no-year`: Remove Year from title.
- `--no-aka`: Remove AKA from title.
- `--no-dub`: Remove Dubbed from title.
- `--no-dual`: Remove Dual-Audio from title.
- `--no-tag`: Remove Group Tag from title.
- `--no-edition`: Remove Edition from title.
- `--dual-audio`: Add Dual-Audio to the title.

### Misc metadata flags

- `--not-anime`: Manually mark release as not anime. NOTE: invokes a quicker processing path for TV content when metadata ids (such as TMDB) are also provided.
- `-year`, `--year YYYY`: Override the year found.
- `-mc`, `--commentary`: Manually indicate commentary tracks are included.
- `-sfxs`, `--sfx-subtitles`: Manually indicate “SFX subtitles” are included.
- `-e`, `--extras`: Indicates extras are included (mainly Blu-ray discs).
- `-sort`, `--sorted-filelist`: Use the largest video file instead of the first video file found. NOTE: useful for anime content when additional content is present in a folder.
- `-kf`, `--keep-folder`: Keep the folder containing the single file (only when supplying a directory).
- `-knfo`, `--keep-nfo`: Keep nfo file where applicable for specific tracker/s. With single files, must be used in conjunction with `--keep-folder` above.
- `-reg`, `--region REGION`: Region for discs.

## Tracker-specific references (existing torrent ids/links)

These accept either an id or a full URL; when a URL is provided, the parser attempts to extract the id.
These will parse the torrent descriptions from supported sites, and grab metadata ids to assist with accuracy.

- `--tracker-id TRACKER=ID_OR_URL`: Generic tracker torrent ID; repeat for multiple trackers. Example: `--tracker-id AITHER=1234`. It also accepts a tracker torrent URL directly, for example `--tracker-id https://aither.cc/torrents/1234`.

Thise will use the specified hash to get tracker ids from qBitTorrent or rTorrent.

- `-th`, `--torrenthash HASH`: Torrent hash containing the torrent id in the comment field of the torrent.

## Upload selection / dupe / requests

- `-tk`, `--trackers LIST`: Upload only to these trackers (instead of a default torrent list from config).
  - Accepts comma-separated canonical tracker names or per-tracker `cli_alias` values from config, case-insensitively (e.g. `--trackers CBR,beyondhd` selects `CAPYBARABR` and `BEYONDHD`).
- `-rtk`, `--trackers-remove LIST`: Remove only these trackers when processing default trackers.
- `-tpc`, `--trackers-pass N`: How many trackers must pass checks (dupe/banned-group/etc) for the uploading process to complete.
- `-req`, `--search_requests`: Search for matching requests on supported trackers.
- `-sat`, `--skip_auto_torrent`: Skip automated qBittorrent client torrent searching.
- `-onlyID`, `--onlyID`: Only grab meta IDs from trackers (tmdb/imdb/etc), overriding `tracker_description_mode` to `ids` for this execution.
- `-sdc`, `--skip-dupe-check`: Ignore dupes and upload anyway (skips dupe check). NOTE: know what you are doing!
- `-sda`, `--skip-dupe-asking`: Don’t prompt about any dupes that Upload Assistant finds; just treat these dupes as actual dupes.
- `-ddc`, `--double-dupe-check`: Run a second dupe-check pass on trackers that previously passed checks, immediately before uploading. NOTE: mainly useful when racing as a preventive dupe upload catch.
- `-dr`, `--draft`: Send to drafts (BEYONDHD, LST).
- `-mq`, `--modq`: Send to modQ. NOTE: only for suppported UNIT3D type sites.
- `-fl`, `--freeleech N`: Freeleech percentage (1–100). Default `0`. NOTE: accepts any numeric value, although UNIT3D defaults to only allowing filtering of specific percentages.
- `-fl-until`, `--freeleech-until N`: Number of days the torrent should offer freeleech (supported UNIT3D trackers, internal/staff only).
- `-feat`, `--featured`: Mark upload as Featured (supported UNIT3D tracker, internal/staff only).
- `-dup`, `--double-upload`: Mark upload as Double Upload (supported UNIT3D trackers, internal/staff only).
- `-dupuntil`, `--double-upload-until N`: Number of days the torrent should offer double upload (supported UNIT3D trackers, internal/staff only).
- `-ref`, `--refundable`: Mark upload as Refundable (supported UNIT3D trackers, internal/staff only).
- `-stk`, `--sticky`: Mark upload as Sticky / pinned (supported UNIT3D trackers, internal/staff only).

## Anonymity / seeding / streaming flags

- `-a`, `--anon`: Upload anonymously.
- `-ns`, `--no-seed`: Do not add the torrent to the client.
- `-st`, `--stream`: Stream optimized upload.
- `-webdv`, `--webdv`: Indicates a Dolby Vision layer converted using `dovi_tool` (HYBRID).
- `--dynamic-hdr-plot`: Generate and upload Dolby Vision and HDR10+ dynamic metadata plots. Required third-party tools are installed automatically when first used.
- `-hc`, `--hardcoded-subs`: Contains hardcoded subs.
  - Note: stored in `meta` under key `hardcoded-subs` (with a hyphen).
- `-pr`, `--personalrelease`: Personal release.

## Torrent creation / hashing options

- `-mps`, `--max-piece-size {1,2,4,8,16,32,64,128}`: Max piece size in MiB.
- `-nh`, `--nohash`: Don’t hash `.torrent`.
- `-rh`, `--rehash`: Rehash `.torrent` even if it was not needed.
- `-mkbrr`, `--mkbrr`: Use mkbrr for torrent hashing.
- `-entropy`, `--entropy N`: Use entropy in created torrents (32 or 64 bits).

Reusable base torrents are recorded in `tmp/<release-id>/torrent_manifest.json`
and stored by piece size under `tmp/<release-id>/torrents/<piece-size-bytes>/`.
Tracker-ready `[TRACKER].torrent` files remain in the release directory. When
`--nohash` is used, a tracker is skipped if no stored base satisfies its torrent
policy.

- `-rt`, `--randomized N`: Create N extra torrents with random infohash (default `0`).
- `--infohash HASH`: V1 info hash to use as the base.
- `-frc`, `--force-recheck`: (qBittorrent only with auto torrent searching) Force recheck torrent before uploading. NOTE: will find the best seeded torrent file from a supported site, for the related content, and force a recheck before uploading.

## Torrent client integration

- `-client`, `--client NAME`: Use this torrent client instead of default.
- `-qbt`, `--qbit-tag TAG`: Add to qBittorrent with this tag.
- `-qbc`, `--qbit-cat CATEGORY`: Add to qBittorrent with this category.
- `-qbcon`, `--qbit-bw-control`: Enable all qBittorrent bandwidth checks for the upload workflow.
- `--qbit-bw-control-after-usenet`: Keep per-tracker checks enabled after the Usenet phase. Requires bandwidth control and `upload_order=usenet`.
- `-qbcrl`, `--qbit-bw-threshold KBPS`: Set the qBittorrent upload-speed threshold in KB/s.
- `-qbctime`, `--qbit-bw-time SECONDS`: Set the requested averaging period, evaluated in five-second samples; see the workflow guide for effective timing.
- `-uo`, `--upload-order {concurrent,usenet,tracker}`: Select the Usenet and torrent tracker phase order.
- `-rtl`, `--rtorrent-label LABEL`: Add to rTorrent with this label.

See [Upload Order and qBittorrent Bandwidth Control](upload-order-and-bandwidth-control.md) for workflow behavior and configuration requirements.

## Cleanup / temp directory

- `-dm`, `--delete-meta`: Delete only `meta.json` from tmp directory.
- `-dtmp`, `--delete-tmp`: Delete tmp directory for the working file/folder.
- `-cleanup`, `--cleanup`: Clean up the entire tmp directory.

## Debugging / output

- `-debug`, `--debug`: Debug mode; runs through motions without uploading.
- `-ffdebug`, `--ffdebug`: Show debugging info from ffmpeg while taking screenshots.
- `-uptimer`, `--upload-timer`: Print time to upload to each site.

## VapourSynth screenshots

- `-vs`, `--vapoursynth`: Use VapourSynth for screenshots (requires VS install). NOTE: probably broken.

## SPEEDAPP-only

- `-ch`, `--channel ID_OR_TAG`: SPEEDAPP: Channel id number or tag (without `@`).

## Usenet uploading

- `-u`, `--usenet`: Trigger Usenet upload.
- `--usenet-subject SUBJECT`: Custom subject line for the Usenet post.
- `--usenet-episodes-only INDEXER[,INDEXER...]`: With Pesto season mode, submit
  episode NZBs but skip the final season-pack NZB for the named Usenet
  indexers. Other selected indexers still receive both episodes and the pack.

## Unattended (hidden)

These are suppressed from help output:

- `-ua`, `--unattended`: Doesn't prompt for anything. Will default to skipping a tracker related upload, instead of prompting a question. Use only if you know what you are doing, and are familar with any Upload Assistant quirks.
- `-uac`, `--unattended_confirm`: Requires `-ua`. Unattended mode with some prompting.
